/** @type {import('next').NextConfig} */
const nextConfig = {
  // Python bot API'sine proxy — Railway'de BOT_API_URL env'den gelir
  async rewrites() {
    const botApi = process.env.BOT_API_URL || "http://localhost:8080";
    return [
      {
        source: "/api/bot/:path*",
        destination: `${botApi}/api/:path*`,
      },
    ];
  },
};

module.exports = nextConfig;
