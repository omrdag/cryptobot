"use client";

import { useEffect, useState } from "react";
import { Save, Play, Square, RefreshCw, AlertTriangle, CheckCircle, ChevronLeft } from "lucide-react";
import Link from "next/link";

const BOT_API = process.env.NEXT_PUBLIC_BOT_API_URL || "/api/bot";

interface Settings {
  trading_mode: string;
  leverage: number;
  max_open_positions: number;
  max_consecutive_losses: number;
  max_daily_loss_pct: number;
  large_lot_enabled: boolean;
  large_lot_min_quality: string;
  breakeven_trigger_pct: number;
  partial_tp1_pct: number;
  partial_tp1_size: number;
  partial_tp2_pct: number;
  partial_tp2_size: number;
  trailing_stop_pct: number;
  max_bars_in_trade: number;
  bot_running: boolean;
  exchange: string;
  trading_pairs: string[];
}

function Field({ label, hint, children }: { label: string; hint?: string; children: React.ReactNode }) {
  return (
    <div className="mb-4">
      <label className="block text-xs font-medium text-dim uppercase tracking-wider mb-1.5">{label}</label>
      {children}
      {hint && <p className="text-xs text-muted mt-1 opacity-60">{hint}</p>}
    </div>
  );
}

function Input({ value, onChange, type = "text", step, min, max }: {
  value: string | number; onChange: (v: string) => void;
  type?: string; step?: string; min?: number; max?: number;
}) {
  return (
    <input
      type={type} value={value} step={step} min={min} max={max}
      onChange={e => onChange(e.target.value)}
      className="w-full bg-surface border border-border rounded-lg px-3 py-2 text-text text-sm
                 font-mono focus:outline-none focus:border-accent/60 transition-colors"
    />
  );
}

function Toggle({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <div className="flex items-center justify-between py-2">
      <span className="text-sm text-text">{label}</span>
      <button
        onClick={() => onChange(!checked)}
        className={`relative w-11 h-6 rounded-full transition-colors ${checked ? "bg-accent" : "bg-border"}`}
      >
        <div className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-transform ${checked ? "left-6" : "left-1"}`} />
      </button>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-xl border border-border bg-card p-5 mb-4">
      <h3 className="text-xs font-medium uppercase tracking-wider text-dim mb-4">{title}</h3>
      {children}
    </div>
  );
}

export default function SettingsPage() {
  const [settings, setSettings] = useState<Partial<Settings>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [botAction, setBotAction] = useState(false);
  const [toast, setToast] = useState<{ msg: string; ok: boolean } | null>(null);

  const showToast = (msg: string, ok = true) => {
    setToast({ msg, ok });
    setTimeout(() => setToast(null), 3000);
  };

  const load = async () => {
    try {
      const r = await fetch(`${BOT_API}/settings`);
      if (r.ok) {
        const data = await r.json();
        setSettings({
          ...data,
          trading_pairs: Array.isArray(data.trading_pairs)
            ? data.trading_pairs
            : JSON.parse(data.trading_pairs || '["BTCUSDT","ETHUSDT"]'),
        });
      }
    } catch { showToast("Ayarlar yüklenemedi", false); }
    finally { setLoading(false); }
  };

  useEffect(() => { load(); }, []);

  const set = (key: keyof Settings, val: any) =>
    setSettings(prev => ({ ...prev, [key]: val }));

  const save = async () => {
    setSaving(true);
    try {
      const payload = {
        trading_mode:           settings.trading_mode,
        leverage:               Number(settings.leverage),
        max_open_positions:     Number(settings.max_open_positions),
        max_consecutive_losses: Number(settings.max_consecutive_losses),
        max_daily_loss_pct:     Number(settings.max_daily_loss_pct),
        large_lot_enabled:      settings.large_lot_enabled,
        large_lot_min_quality:  settings.large_lot_min_quality,
        breakeven_trigger_pct:  Number(settings.breakeven_trigger_pct),
        partial_tp1_pct:        Number(settings.partial_tp1_pct),
        partial_tp1_size:       Number(settings.partial_tp1_size),
        partial_tp2_pct:        Number(settings.partial_tp2_pct),
        partial_tp2_size:       Number(settings.partial_tp2_size),
        trailing_stop_pct:      Number(settings.trailing_stop_pct),
        max_bars_in_trade:      Number(settings.max_bars_in_trade),
        trading_pairs:          JSON.stringify(settings.trading_pairs ?? []),
      };
      const r = await fetch(`${BOT_API}/settings`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      r.ok ? showToast("Ayarlar kaydedildi ✓") : showToast("Kayıt hatası", false);
    } catch { showToast("Kayıt hatası", false); }
    finally { setSaving(false); }
  };

  const toggleBot = async () => {
    setBotAction(true);
    const running = settings.bot_running;
    try {
      const r = await fetch(`${BOT_API}/bot/${running ? "stop" : "start"}`, { method: "POST" });
      if (r.ok) {
        set("bot_running", !running);
        showToast(running ? "Bot durduruldu" : "Bot başlatıldı");
      } else {
        showToast("İşlem başarısız", false);
      }
    } catch { showToast("Bağlantı hatası", false); }
    finally { setBotAction(false); }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-bg flex items-center justify-center">
        <RefreshCw size={20} className="text-accent animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-bg p-4 md:p-6 max-w-2xl mx-auto">
      {/* Toast */}
      {toast && (
        <div className={`fixed top-4 right-4 z-50 flex items-center gap-2 px-4 py-2.5 rounded-xl border text-sm font-medium animate-slide-up
          ${toast.ok ? "bg-accent/10 border-accent/30 text-accent" : "bg-danger/10 border-danger/30 text-danger"}`}>
          {toast.ok ? <CheckCircle size={14} /> : <AlertTriangle size={14} />}
          {toast.msg}
        </div>
      )}

      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <Link href="/" className="text-dim hover:text-text transition-colors">
          <ChevronLeft size={20} />
        </Link>
        <h1 className="font-mono font-semibold text-text">Bot Ayarları</h1>
      </div>

      {/* Bot Control */}
      <Section title="Bot Kontrolü">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-sm text-text font-medium">
              {settings.bot_running ? "Bot Çalışıyor" : "Bot Durduruldu"}
            </div>
            <div className="text-xs text-dim mt-0.5">
              {settings.exchange?.toUpperCase()} · {settings.trading_mode?.toUpperCase()}
            </div>
          </div>
          <button
            onClick={toggleBot}
            disabled={botAction}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all
              ${settings.bot_running
                ? "bg-danger/10 border border-danger/30 text-danger hover:bg-danger/20"
                : "bg-accent/10 border border-accent/30 text-accent hover:bg-accent/20"
              } disabled:opacity-50`}
          >
            {botAction ? <RefreshCw size={14} className="animate-spin" /> :
              settings.bot_running ? <Square size={14} /> : <Play size={14} />}
            {settings.bot_running ? "Durdur" : "Başlat"}
          </button>
        </div>
        <div className="mt-3 pt-3 border-t border-border">
          <Toggle
            label="Live Mod (Gerçek Para)"
            checked={settings.trading_mode === "live"}
            onChange={v => set("trading_mode", v ? "live" : "paper")}
          />
          {settings.trading_mode === "live" && (
            <div className="mt-2 flex items-center gap-2 text-xs text-gold bg-gold/10 border border-gold/20 rounded-lg px-3 py-2">
              <AlertTriangle size={12} />
              Gerçek para modu aktif — işlemleri dikkatli takip et
            </div>
          )}
        </div>
      </Section>

      {/* Risk */}
      <Section title="Risk Yönetimi">
        <div className="grid grid-cols-2 gap-3">
          <Field label="Kaldıraç" hint="OKX hesabınla uyumlu olmalı">
            <Input type="number" min={1} max={20} value={settings.leverage ?? 10}
              onChange={v => set("leverage", v)} />
          </Field>
          <Field label="Max Açık Pozisyon">
            <Input type="number" min={1} max={10} value={settings.max_open_positions ?? 5}
              onChange={v => set("max_open_positions", v)} />
          </Field>
          <Field label="Art Arda Max Kayıp">
            <Input type="number" min={1} max={10} value={settings.max_consecutive_losses ?? 5}
              onChange={v => set("max_consecutive_losses", v)} />
          </Field>
          <Field label="Günlük Max Kayıp %" hint="Bakiyenin yüzdesi">
            <Input type="number" step="0.5" min={1} max={20} value={settings.max_daily_loss_pct ?? 6}
              onChange={v => set("max_daily_loss_pct", v)} />
          </Field>
        </div>
      </Section>

      {/* Smart Exit */}
      <Section title="Smart Exit Parametreleri">
        <div className="grid grid-cols-2 gap-3">
          <Field label="BE Tetikleyici %" hint="Bu kârda SL=giriş">
            <Input type="number" step="0.1" value={settings.breakeven_trigger_pct ?? 1.2}
              onChange={v => set("breakeven_trigger_pct", v)} />
          </Field>
          <Field label="Max Bar (iterasyon)">
            <Input type="number" min={4} max={24} value={settings.max_bars_in_trade ?? 8}
              onChange={v => set("max_bars_in_trade", v)} />
          </Field>
          <Field label="TP1 Seviyesi %">
            <Input type="number" step="0.1" value={settings.partial_tp1_pct ?? 1.5}
              onChange={v => set("partial_tp1_pct", v)} />
          </Field>
          <Field label="TP1 Kapatma %">
            <Input type="number" min={10} max={100} value={settings.partial_tp1_size ?? 50}
              onChange={v => set("partial_tp1_size", v)} />
          </Field>
          <Field label="TP2 Seviyesi %">
            <Input type="number" step="0.1" value={settings.partial_tp2_pct ?? 2.5}
              onChange={v => set("partial_tp2_pct", v)} />
          </Field>
          <Field label="TP2 Kapatma %">
            <Input type="number" min={0} max={100} value={settings.partial_tp2_size ?? 50}
              onChange={v => set("partial_tp2_size", v)} />
          </Field>
          <Field label="Trailing Stop %">
            <Input type="number" step="0.1" value={settings.trailing_stop_pct ?? 1.0}
              onChange={v => set("trailing_stop_pct", v)} />
          </Field>
        </div>
      </Section>

      {/* Large Lot */}
      <Section title="Large Lot Modu">
        <Toggle
          label="Large Lot Aktif"
          checked={settings.large_lot_enabled ?? true}
          onChange={v => set("large_lot_enabled", v)}
        />
        {settings.large_lot_enabled && (
          <div className="mt-3">
            <Field label="Minimum Kalite" hint="A = skor≥85 | A+ = skor≥90">
              <select
                value={settings.large_lot_min_quality ?? "A"}
                onChange={e => set("large_lot_min_quality", e.target.value)}
                className="w-full bg-surface border border-border rounded-lg px-3 py-2 text-text text-sm
                           font-mono focus:outline-none focus:border-accent/60 transition-colors"
              >
                <option value="A">A (skor ≥ 85)</option>
                <option value="A+">A+ (skor ≥ 90)</option>
              </select>
            </Field>
          </div>
        )}
      </Section>

      {/* Trading Pairs */}
      <Section title="İzleme Listesi">
        <Field label="Coin Listesi" hint="Virgülle ayır: BTCUSDT,ETHUSDT,SOLUSDT">
          <Input
            value={(settings.trading_pairs ?? []).join(",")}
            onChange={v => set("trading_pairs", v.split(",").map(s => s.trim().toUpperCase()).filter(Boolean))}
          />
        </Field>
        <div className="flex flex-wrap gap-1.5 mt-2">
          {(settings.trading_pairs ?? []).map(p => (
            <span key={p} className="text-xs px-2 py-0.5 rounded bg-accent/10 text-accent border border-accent/20 font-mono">
              {p}
            </span>
          ))}
        </div>
      </Section>

      {/* Save */}
      <button
        onClick={save}
        disabled={saving}
        className="w-full flex items-center justify-center gap-2 py-3 rounded-xl
                   bg-accent/10 border border-accent/30 text-accent font-medium text-sm
                   hover:bg-accent/20 transition-all disabled:opacity-50"
      >
        {saving ? <RefreshCw size={14} className="animate-spin" /> : <Save size={14} />}
        {saving ? "Kaydediliyor…" : "Kaydet"}
      </button>

      <p className="text-center text-xs text-dim mt-4">
        Ayarlar kaydedildikten sonra bot bir sonraki döngüde okur
      </p>
    </div>
  );
}
