"use client";

import { useEffect, useRef, useState, useCallback } from "react";
import {
  TrendingUp, TrendingDown, Activity, DollarSign,
  Zap, AlertTriangle, BarChart2, Clock, RefreshCw,
  ChevronUp, ChevronDown, Minus, Shield, Target,
} from "lucide-react";
import { LineChart, Line, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";

// ─── Types ────────────────────────────────────────────────────────────────────

interface Position {
  id: number;
  symbol: string;
  side: "long" | "short";
  entryPrice: number;
  currentPrice: number;
  quantity: number;
  leverage: number;
  pnl: number;
  pnlPercent: number;
  stopLoss?: number;
  takeProfit?: number;
  candlesHeld: number;
  maxBars: number;
  barsRemaining: number;
  lotType?: string;
  isAdopted?: boolean;
  distanceToSLPct?: number;
  distanceToTPPct?: number;
  distanceToBEPct?: number;
  distanceToTP1Pct?: number;
  strategyName?: string;
  openedAt: string;
}

interface Stats {
  totalBalance: number;
  availableBalance: number;
  totalPnl: number;
  dailyPnl: number;
  winRate: number;
  profitFactor: number;
  totalTrades: number;
  winningTrades: number;
  losingTrades: number;
  unrealizedPnl: number;
  consecutiveLosses: number;
}

interface Trade {
  id: number;
  symbol: string;
  side: string;
  pnl: number;
  pnlPercent: number;
  exitReason: string;
  strategyName: string;
  closedAt: string;
  openedAt: string;
}

interface BotStatus {
  running: boolean;
  mode: string;
  exchange: string;
}

interface SSEPayload {
  positions: Position[];
  stats: Stats;
  recentTrades: Trade[];
  botStatus: BotStatus;
  timestamp: string;
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

const fmt = (n: number, d = 2) => n?.toFixed(d) ?? "—";
const fmtUsd = (n: number) => `$${Math.abs(n).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
const pnlColor = (n: number) => n > 0 ? "text-accent" : n < 0 ? "text-danger" : "text-dim";
const pnlBg    = (n: number) => n > 0 ? "bg-accent/10 border-accent/20" : n < 0 ? "bg-danger/10 border-danger/20" : "bg-border/30 border-border";

const BOT_API = process.env.NEXT_PUBLIC_BOT_API_URL || "/api/bot";

// ─── Stat Card ────────────────────────────────────────────────────────────────

function StatCard({ label, value, sub, icon: Icon, accent = false, danger = false }: {
  label: string; value: string; sub?: string;
  icon: any; accent?: boolean; danger?: boolean;
}) {
  return (
    <div className={`rounded-xl border p-4 flex flex-col gap-2 animate-fade-in ${
      accent ? "border-accent/30 bg-accent/5" :
      danger ? "border-danger/30 bg-danger/5" :
      "border-border bg-card"
    }`}>
      <div className="flex items-center justify-between">
        <span className="text-dim text-xs font-medium uppercase tracking-wider">{label}</span>
        <Icon size={14} className={accent ? "text-accent" : danger ? "text-danger" : "text-dim"} />
      </div>
      <div className={`text-xl font-mono font-semibold ${accent ? "text-accent" : danger ? "text-danger" : "text-text"}`}>
        {value}
      </div>
      {sub && <div className="text-xs text-dim">{sub}</div>}
    </div>
  );
}

// ─── Position Card ────────────────────────────────────────────────────────────

function PositionCard({ pos }: { pos: Position }) {
  const isLong = pos.side === "long";
  const barPct = Math.min(100, Math.max(0, ((pos.candlesHeld) / Math.max(1, pos.maxBars)) * 100));
  const priceToTPPct = pos.distanceToTPPct ?? null;
  const distSL = pos.distanceToSLPct;
  const isLargeLot = pos.lotType === "large";

  return (
    <div className={`rounded-xl border p-4 animate-slide-up transition-all ${pnlBg(pos.pnl)}`}>
      {/* Header */}
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-2">
          <div className={`w-2 h-2 rounded-full ${isLong ? "bg-accent" : "bg-danger"}`} />
          <span className="font-mono font-semibold text-text">{pos.symbol.replace("USDT", "")}/USDT</span>
          <span className={`text-xs px-1.5 py-0.5 rounded font-medium ${
            isLong ? "bg-accent/20 text-accent" : "bg-danger/20 text-danger"
          }`}>
            {isLong ? "LONG" : "SHORT"} {pos.leverage}x
          </span>
          {isLargeLot && (
            <span className="text-xs px-1.5 py-0.5 rounded bg-gold/20 text-gold font-medium">LARGE</span>
          )}
          {pos.isAdopted && (
            <span className="text-xs px-1.5 py-0.5 rounded bg-muted/20 text-dim">SYNC</span>
          )}
        </div>
        <div className={`text-right font-mono font-semibold ${pnlColor(pos.pnl)}`}>
          <div>{pos.pnl >= 0 ? "+" : ""}{fmtUsd(pos.pnl)}</div>
          <div className="text-xs">{pos.pnl >= 0 ? "+" : ""}{fmt(pos.pnlPercent)}%</div>
        </div>
      </div>

      {/* Prices */}
      <div className="grid grid-cols-3 gap-2 mb-3 text-xs">
        <div>
          <div className="text-dim mb-0.5">Giriş</div>
          <div className="font-mono text-text">${fmt(pos.entryPrice, 4)}</div>
        </div>
        <div>
          <div className="text-dim mb-0.5">Güncel</div>
          <div className="font-mono text-text font-medium">${fmt(pos.currentPrice, 4)}</div>
        </div>
        <div>
          <div className="text-dim mb-0.5">Stop Loss</div>
          <div className="font-mono text-danger">{pos.stopLoss ? `$${fmt(pos.stopLoss, 4)}` : "—"}</div>
        </div>
      </div>

      {/* Distance badges */}
      <div className="flex flex-wrap gap-1.5 mb-3">
        {distSL != null && (
          <span className="text-xs px-2 py-0.5 rounded bg-danger/10 text-danger border border-danger/20">
            SL {fmt(distSL)}%
          </span>
        )}
        {pos.distanceToBEPct != null && (
          <span className="text-xs px-2 py-0.5 rounded bg-gold/10 text-gold border border-gold/20">
            BE {fmt(pos.distanceToBEPct)}%
          </span>
        )}
        {pos.distanceToTP1Pct != null && (
          <span className="text-xs px-2 py-0.5 rounded bg-accent/10 text-accent border border-accent/20">
            TP1 {fmt(pos.distanceToTP1Pct)}%
          </span>
        )}
        {priceToTPPct != null && (
          <span className="text-xs px-2 py-0.5 rounded bg-accent/10 text-accent border border-accent/20">
            TP {fmt(priceToTPPct)}%
          </span>
        )}
      </div>

      {/* Time bar */}
      <div className="mb-1 flex items-center justify-between text-xs text-dim">
        <span>Mum {pos.candlesHeld}/{pos.maxBars}</span>
        <span>{pos.barsRemaining} bar kaldı</span>
      </div>
      <div className="progress-bar">
        <div
          className="progress-bar-fill"
          style={{
            width: `${barPct}%`,
            background: barPct > 80 ? "var(--danger)" : barPct > 60 ? "var(--gold)" : "var(--accent)",
          }}
        />
      </div>

      {/* Strategy */}
      {pos.strategyName && (
        <div className="mt-2 text-xs text-dim">{pos.strategyName}</div>
      )}
    </div>
  );
}

// ─── Trade Row ────────────────────────────────────────────────────────────────

function TradeRow({ trade }: { trade: Trade }) {
  const isWin = (trade.pnl ?? 0) > 0;
  const dur = (() => {
    if (!trade.openedAt || !trade.closedAt) return "";
    const diff = new Date(trade.closedAt).getTime() - new Date(trade.openedAt).getTime();
    const mins = Math.floor(diff / 60000);
    return mins < 60 ? `${mins}dk` : `${Math.floor(mins / 60)}s`;
  })();

  return (
    <div className={`flex items-center justify-between py-2.5 px-3 rounded-lg border mb-1 ${pnlBg(trade.pnl)}`}>
      <div className="flex items-center gap-2">
        <div className={`w-1.5 h-1.5 rounded-full ${isWin ? "bg-accent" : "bg-danger"}`} />
        <span className="font-mono text-sm text-text">{trade.symbol?.replace("USDT", "")}</span>
        <span className={`text-xs ${trade.side === "long" ? "text-accent" : "text-danger"}`}>
          {trade.side?.toUpperCase()}
        </span>
      </div>
      <div className="flex items-center gap-3 text-xs">
        {dur && <span className="text-dim">{dur}</span>}
        <span className="text-dim truncate max-w-20 hidden sm:block">{trade.exitReason?.split("_").join(" ")}</span>
        <span className={`font-mono font-medium ${pnlColor(trade.pnl)}`}>
          {trade.pnl >= 0 ? "+" : ""}{fmtUsd(trade.pnl)}
        </span>
      </div>
    </div>
  );
}

// ─── Main Dashboard ───────────────────────────────────────────────────────────

export default function Dashboard() {
  const [data, setData] = useState<SSEPayload | null>(null);
  const [connected, setConnected] = useState(false);
  const [pnlHistory, setPnlHistory] = useState<{ t: string; v: number }[]>([]);
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);
  const esRef = useRef<EventSource | null>(null);

  // SSE connection
  const connect = useCallback(() => {
    if (esRef.current) {
      esRef.current.close();
    }
    const url = `${BOT_API}/stream`;
    const es = new EventSource(url);
    esRef.current = es;

    es.onopen = () => setConnected(true);

    es.onmessage = (e) => {
      try {
        const payload: SSEPayload = JSON.parse(e.data);
        setData(payload);
        setLastUpdate(new Date());
        // PnL history (son 60 nokta)
        setPnlHistory(prev => {
          const next = [
            ...prev.slice(-59),
            { t: new Date().toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" }), v: payload.stats?.totalPnl ?? 0 },
          ];
          return next;
        });
      } catch {}
    };

    es.onerror = () => {
      setConnected(false);
      es.close();
      // 5 saniye sonra yeniden bağlan
      setTimeout(connect, 5000);
    };
  }, []);

  useEffect(() => {
    connect();
    return () => esRef.current?.close();
  }, [connect]);

  const stats  = data?.stats;
  const positions = data?.positions ?? [];
  const trades    = data?.recentTrades ?? [];
  const bot       = data?.botStatus;

  const openCount  = positions.length;
  const longCount  = positions.filter(p => p.side === "long").length;
  const shortCount = positions.filter(p => p.side === "short").length;

  return (
    <div className="min-h-screen bg-bg p-4 md:p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-accent/20 flex items-center justify-center">
            <Zap size={16} className="text-accent" />
          </div>
          <div>
            <h1 className="font-mono font-semibold text-text text-base">CryptoBot</h1>
            <div className="flex items-center gap-2 text-xs text-dim">
              <span className={`live-dot ${connected ? "" : "bg-danger"}`} style={{ background: connected ? undefined : "var(--danger)" }} />
              <span>{connected ? "Bağlı" : "Bağlantı yok"}</span>
              {bot && (
                <>
                  <span>·</span>
                  <span className={bot.running ? "text-accent" : "text-dim"}>{bot.running ? "Çalışıyor" : "Durduruldu"}</span>
                  <span>·</span>
                  <span className="uppercase">{bot.mode}</span>
                  <span>·</span>
                  <span className="uppercase">{bot.exchange}</span>
                </>
              )}
            </div>
          </div>
        </div>
        <div className="text-xs text-dim font-mono">
          {lastUpdate ? lastUpdate.toLocaleTimeString("tr-TR") : "—"}
        </div>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
        <StatCard
          label="Toplam Bakiye"
          value={stats ? fmtUsd(stats.totalBalance) : "—"}
          sub={stats ? `Serbest: ${fmtUsd(stats.availableBalance)}` : undefined}
          icon={DollarSign}
          accent
        />
        <StatCard
          label="Gerçekleşen PnL"
          value={stats ? `${stats.totalPnl >= 0 ? "+" : ""}${fmtUsd(stats.totalPnl)}` : "—"}
          sub={stats ? `Bugün: ${stats.dailyPnl >= 0 ? "+" : ""}${fmtUsd(stats.dailyPnl)}` : undefined}
          icon={TrendingUp}
          accent={!!stats && stats.totalPnl > 0}
          danger={!!stats && stats.totalPnl < 0}
        />
        <StatCard
          label="Kazanma Oranı"
          value={stats ? `%${fmt(stats.winRate, 1)}` : "—"}
          sub={stats ? `${stats.winningTrades}W / ${stats.losingTrades}L — PF: ${fmt(stats.profitFactor, 2)}` : undefined}
          icon={BarChart2}
        />
        <StatCard
          label="Açık Pozisyon"
          value={String(openCount)}
          sub={`${longCount} Long · ${shortCount} Short`}
          icon={Activity}
          accent={openCount > 0}
        />
      </div>

      {/* Unrealized PnL + Consecutive losses */}
      {stats && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
          <StatCard
            label="Gerçekleşmemiş PnL"
            value={`${stats.unrealizedPnl >= 0 ? "+" : ""}${fmtUsd(stats.unrealizedPnl)}`}
            icon={Target}
            accent={stats.unrealizedPnl > 0}
            danger={stats.unrealizedPnl < 0}
          />
          <StatCard
            label="Art Arda Kayıp"
            value={String(stats.consecutiveLosses)}
            icon={Shield}
            danger={stats.consecutiveLosses >= 3}
          />
          <StatCard
            label="Toplam İşlem"
            value={String(stats.totalTrades)}
            icon={Clock}
          />
          <div className="col-span-1 row-span-1" />
        </div>
      )}

      {/* PnL Chart */}
      {pnlHistory.length > 2 && (
        <div className="rounded-xl border border-border bg-card p-4 mb-6">
          <div className="text-xs text-dim font-medium mb-3 uppercase tracking-wider">PnL Grafiği</div>
          <ResponsiveContainer width="100%" height={100}>
            <LineChart data={pnlHistory}>
              <XAxis dataKey="t" hide />
              <YAxis hide domain={["auto", "auto"]} />
              <Tooltip
                contentStyle={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: 8, fontSize: 11 }}
                formatter={(v: number) => [`$${v.toFixed(2)}`, "PnL"]}
              />
              <Line
                type="monotone"
                dataKey="v"
                stroke="var(--accent)"
                strokeWidth={1.5}
                dot={false}
                isAnimationActive={false}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Open Positions */}
        <div>
          <div className="flex items-center gap-2 mb-3">
            <Activity size={14} className="text-accent" />
            <span className="text-xs font-medium uppercase tracking-wider text-dim">Açık Pozisyonlar</span>
            <span className="text-xs bg-accent/20 text-accent px-1.5 py-0.5 rounded font-mono">{openCount}</span>
          </div>

          {positions.length === 0 ? (
            <div className="rounded-xl border border-border bg-card p-8 text-center text-dim text-sm">
              Açık pozisyon yok
            </div>
          ) : (
            <div className="flex flex-col gap-3">
              {positions.map(pos => <PositionCard key={pos.id} pos={pos} />)}
            </div>
          )}
        </div>

        {/* Recent Trades */}
        <div>
          <div className="flex items-center gap-2 mb-3">
            <BarChart2 size={14} className="text-accent" />
            <span className="text-xs font-medium uppercase tracking-wider text-dim">Son İşlemler</span>
          </div>

          <div className="rounded-xl border border-border bg-card p-3 max-h-[600px] overflow-y-auto">
            {trades.length === 0 ? (
              <div className="text-center text-dim text-sm py-8">Henüz işlem yok</div>
            ) : (
              trades.slice(0, 30).map(t => <TradeRow key={t.id} trade={t} />)
            )}
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="mt-8 text-center text-xs text-dim">
        OKX Pullback Bot · Railway Deploy · SSE gerçek zamanlı
      </div>
    </div>
  );
}
