"""
Signal Scorer v2 — Zorunlu Kapı + Ağırlıklı Puan Sistemi
==========================================================
v1 SORUNU: Ağırlıklı ortalama, kötü koşulları maskeliyordu.
  TRENDING_DOWN'da BUY: EMA crossover(100) + RSI oversold(100) + Volume(60)
  = skor 74 → işlem açılıyor.  Bu yanlış.

v2 ÇÖZÜMÜ:
  1. ZORUNLU KAPILARI (hard gates) geçemeyen sinyal direkt REDDEDİLİR.
     Bu kapılar 0 puan değil, tam blok verir.
  2. Kalan bileşenler 10 üzerinden puanlanır (7/10 gerekli).
  3. Her koşul VEYA değil VE mantığıyla çalışır.

BUY için Zorunlu Kapılar (hepsi gerekli):
  [1] Rejim: TRENDING_UP veya RANGING (TRENDING_DOWN → tam blok)
  [2] EMA tam hizalama: price > EMA9 > EMA21 > EMA50
  [3] RSI < 55 (RSI ≥ 55 → aşırı alım bölgesi, BUY riskli)
  [4] Fiyat > EMA200 (makro trend desteği)
  [5] ADX > 18 (trend var, ranging değil için)
  [6] BB üst bandına çok yakın değil (price < BB_upper × 0.995)

BUY için Ağırlıklı Puan Katmanları (7/10 gerekli):
  [A] EMA spread gücü       (1 puan)
  [B] RSI seviyesi          (1 puan)
  [C] Hacim onayı           (1 puan)
  [D] Momentum (ROC-5)      (1 puan)
  [E] Mum onayı             (1 puan)
  [F] ADX gücü              (1 puan)
  [G] BB pozisyonu          (1 puan)
  [H] Volatilite kalitesi   (1 puan)
  [I] Trend ivmesi          (1 puan)
  [J] Hacim artışı          (1 puan)

Toplam: max 10 puan. 7+ → işlem açılabilir.
"""

import pandas as pd
import numpy as np
from dataclasses import dataclass, field
from typing import List, Optional, Dict
from utils.logger import get_logger

logger = get_logger()


def _ema(s: pd.Series, p: int) -> pd.Series:
    return s.ewm(span=p, adjust=False).mean()

def _rsi(s: pd.Series, p: int = 14) -> pd.Series:
    delta = s.diff()
    gain  = delta.clip(lower=0).ewm(span=p, adjust=False).mean()
    loss  = (-delta.clip(upper=0)).ewm(span=p, adjust=False).mean()
    rs    = gain / (loss + 1e-9)
    return 100 - 100 / (1 + rs)

def _atr(df: pd.DataFrame, p: int = 14) -> pd.Series:
    prev = df["close"].shift(1)
    tr   = pd.concat([
        df["high"] - df["low"],
        (df["high"] - prev).abs(),
        (df["low"]  - prev).abs(),
    ], axis=1).max(axis=1)
    return tr.ewm(span=p, adjust=False).mean()

def _adx(df: pd.DataFrame, period: int = 14) -> float:
    if len(df) < period + 5:
        return 0.0
    high, low, close = df["high"], df["low"], df["close"]
    dm_plus  = (high - high.shift(1)).clip(lower=0)
    dm_minus = (low.shift(1) - low).clip(lower=0)
    dm_plus_c  = dm_plus.where(dm_plus > dm_minus, 0)
    dm_minus_c = dm_minus.where(dm_minus > dm_plus, 0)
    prev_c = close.shift(1)
    tr = pd.concat([high-low, (high-prev_c).abs(), (low-prev_c).abs()], axis=1).max(axis=1)
    atr_s = tr.ewm(span=period, adjust=False).mean()
    di_p = (dm_plus_c.ewm(span=period, adjust=False).mean() / atr_s * 100).fillna(0)
    di_m = (dm_minus_c.ewm(span=period, adjust=False).mean() / atr_s * 100).fillna(0)
    dx   = (abs(di_p - di_m) / (di_p + di_m + 1e-9) * 100).fillna(0)
    return float(dx.ewm(span=period, adjust=False).mean().iloc[-1])


@dataclass
class SignalScore:
    direction:    str
    score:        float            # 0-100 normalize edilmiş
    gate_score:   int              # 10 üzerinden kapı puanı
    passed:       bool
    hard_blocked: bool             # Zorunlu kapı reddettiyse True
    components:   Dict[str, float] = field(default_factory=dict)
    reasons:      List[str]        = field(default_factory=list)
    rejections:   List[str]        = field(default_factory=list)


class SignalScorer:
    """
    v2: Zorunlu Kapı + 10-üzeri Puanlama Sistemi.
    Bir zorunlu kapı başarısız olursa sinyal direkt REDDEDİLİR.
    """

    def __init__(
        self,
        min_score:           float = 72.0,
        weight_ema:          float = 25.0,
        weight_rsi:          float = 20.0,
        weight_volume:       float = 15.0,
        weight_momentum:     float = 15.0,
        weight_candle:       float = 15.0,
        weight_regime:       float = 10.0,
        ema_fast:            int   = 9,
        ema_slow:            int   = 21,
        ema_trend:           int   = 50,
        rsi_period:          int   = 14,
        rsi_buy_max:         float = 55.0,
        rsi_sell_min:        float = 45.0,
        rsi_oversold:        float = 35.0,
        rsi_overbought:      float = 65.0,
        vol_min_ratio:       float = 1.0,
        atr_period:          int   = 14,
        min_atr_ratio:       float = 0.002,
        candle_confirm_bars: int   = 2,
        # Yeni v2 parametreler
        adx_min:             float = 18.0,
        gate_min_score:      int   = 7,     # 10 üzerinden minimum kapı puanı
    ):
        self.min_score          = min_score
        self.weight_ema         = weight_ema
        self.weight_rsi         = weight_rsi
        self.weight_volume      = weight_volume
        self.weight_momentum    = weight_momentum
        self.weight_candle      = weight_candle
        self.weight_regime      = weight_regime
        self.ema_fast           = ema_fast
        self.ema_slow           = ema_slow
        self.ema_trend          = ema_trend
        self.rsi_period         = rsi_period
        self.rsi_buy_max        = rsi_buy_max
        self.rsi_sell_min       = rsi_sell_min
        self.rsi_oversold       = rsi_oversold
        self.rsi_overbought     = rsi_overbought
        self.vol_min_ratio      = vol_min_ratio
        self.atr_period         = atr_period
        self.min_atr_ratio      = min_atr_ratio
        self.candle_confirm_bars = candle_confirm_bars
        self.adx_min            = adx_min
        self.gate_min_score     = gate_min_score

    def score(
        self,
        df: pd.DataFrame,
        direction: str,
        regime=None,
    ) -> SignalScore:
        reasons    = []
        rejections = []
        components = {}

        min_bars = max(self.ema_trend, 200) + 5
        if df is None or len(df) < min_bars:
            return SignalScore(direction, 0, 0, False, True, {}, [], ["Yetersiz veri (min 205 bar)"])

        close  = df["close"]
        price  = float(close.iloc[-1])

        # ── İndikatör Hesapları ──────────────────────────────────────────────────
        ema9   = float(_ema(close, self.ema_fast).iloc[-1])
        ema21  = float(_ema(close, self.ema_slow).iloc[-1])
        ema50  = float(_ema(close, self.ema_trend).iloc[-1])
        ema200 = float(_ema(close, 200).iloc[-1])
        ema9_prev  = float(_ema(close, self.ema_fast).iloc[-2])
        ema21_prev = float(_ema(close, self.ema_slow).iloc[-2])

        rsi_s  = _rsi(close, self.rsi_period)
        rsi    = float(rsi_s.iloc[-1])

        atr_s  = _atr(df, self.atr_period)
        atr    = float(atr_s.iloc[-1])
        atr_ratio = atr / price if price > 0 else 0

        adx = _adx(df, 14)

        bb_mid   = float(close.rolling(20).mean().iloc[-1])
        bb_std   = float(close.rolling(20).std().iloc[-1])
        bb_upper = bb_mid + 2 * bb_std
        bb_lower = bb_mid - 2 * bb_std
        bb_width = (bb_upper - bb_lower) / bb_mid if bb_mid > 0 else 0

        if "volume" in df.columns:
            last_vol = float(df["volume"].tail(3).mean())
            avg_vol  = float(df["volume"].tail(20).mean())
            vol_ratio = last_vol / avg_vol if avg_vol > 0 else 0
        else:
            vol_ratio = 1.0

        from filters.market_regime import Regime
        regime_str = regime.regime if regime else None

        # ════════════════════════════════════════════════════════════════════════
        # AŞAMA 1: ZORUNLU KAPILAR — Herhangi biri başarısız = REDDEDİLDİ
        # ════════════════════════════════════════════════════════════════════════
        hard_blocks = []

        if direction == "BUY":
            # Kapi 1: Rejim
            if regime_str == Regime.TRENDING_DOWN:
                hard_blocks.append(f"❌ KAPI[1] Makro düşen trend — BUY yasak")
            elif regime_str == Regime.HIGH_VOLATILITY and adx < 25:
                hard_blocks.append(f"❌ KAPI[1] Yüksek volatilite + ADX düşük ({adx:.1f}) — kaotik piyasa")
            else:
                reasons.append(f"✅ KAPI[1] Rejim uygun: {regime_str}")

            # Kapi 2: Fiyat > EMA200 (makro trend)
            if price < ema200:
                hard_blocks.append(f"❌ KAPI[2] Fiyat EMA200 altında ({price:.4f} < {ema200:.4f})")
            else:
                reasons.append(f"✅ KAPI[2] Fiyat EMA200 üzerinde (+{(price/ema200-1)*100:.2f}%)")

            # Kapi 3: EMA hizalaması (price > EMA9 > EMA21 — EMA50 kontrolü opsiyonel)
            if not (ema9 > ema21):
                hard_blocks.append(f"❌ KAPI[3] EMA hizasız: EMA9({ema9:.4f}) < EMA21({ema21:.4f})")
            else:
                reasons.append(f"✅ KAPI[3] EMA9>EMA21 hizalı")

            # Kapi 4: RSI aşırı alım değil
            if rsi >= self.rsi_buy_max:
                hard_blocks.append(f"❌ KAPI[4] RSI aşırı alım bölgesi ({rsi:.1f} ≥ {self.rsi_buy_max})")
            else:
                reasons.append(f"✅ KAPI[4] RSI uygun: {rsi:.1f}")

            # Kapi 5: Fiyat BB üst bandına yapışık değil
            bb_position = (price - bb_lower) / (bb_upper - bb_lower + 1e-9)
            if bb_position > 0.90:
                hard_blocks.append(f"❌ KAPI[5] Fiyat BB üst banda çok yakın ({bb_position*100:.0f}%)")
            else:
                reasons.append(f"✅ KAPI[5] BB pozisyon normal ({bb_position*100:.0f}%)")

        else:  # SELL
            # Kapi 1: Rejim
            if regime_str == Regime.TRENDING_UP:
                hard_blocks.append(f"❌ KAPI[1] Makro yükselen trend — SELL yasak")
            elif regime_str == Regime.HIGH_VOLATILITY and adx < 25:
                hard_blocks.append(f"❌ KAPI[1] Yüksek volatilite + ADX düşük ({adx:.1f})")
            else:
                reasons.append(f"✅ KAPI[1] Rejim uygun: {regime_str}")

            # Kapi 2: Fiyat < EMA200
            if price > ema200:
                hard_blocks.append(f"❌ KAPI[2] Fiyat EMA200 üzerinde — SELL riski")
            else:
                reasons.append(f"✅ KAPI[2] Fiyat EMA200 altında")

            # Kapi 3: EMA hizalama
            if not (ema9 < ema21):
                hard_blocks.append(f"❌ KAPI[3] EMA hizasız SELL için: EMA9 > EMA21")
            else:
                reasons.append(f"✅ KAPI[3] EMA9<EMA21 hizalı (SELL)")

            # Kapi 4: RSI aşırı satış değil
            if rsi <= self.rsi_sell_min:
                hard_blocks.append(f"❌ KAPI[4] RSI aşırı satış bölgesi ({rsi:.1f} ≤ {self.rsi_sell_min})")
            else:
                reasons.append(f"✅ KAPI[4] RSI uygun SELL: {rsi:.1f}")

            # Kapi 5: Fiyat BB alt bandına yapışık değil
            bb_position = (price - bb_lower) / (bb_upper - bb_lower + 1e-9)
            if bb_position < 0.10:
                hard_blocks.append(f"❌ KAPI[5] Fiyat BB alt banda çok yakın ({bb_position*100:.0f}%)")
            else:
                reasons.append(f"✅ KAPI[5] BB pozisyon normal SELL ({bb_position*100:.0f}%)")

        if hard_blocks:
            for b in hard_blocks:
                rejections.append(b)
            logger.debug(
                f"SignalScorer KAPI REDDİ [{direction}]: {hard_blocks[0]}"
            )
            return SignalScore(
                direction=direction,
                score=0.0,
                gate_score=0,
                passed=False,
                hard_blocked=True,
                components={},
                reasons=reasons,
                rejections=rejections,
            )

        # ════════════════════════════════════════════════════════════════════════
        # AŞAMA 2: 10 PUANLIK KALITE KAPI SİSTEMİ
        # ════════════════════════════════════════════════════════════════════════
        gate_points = 0
        gate_details = {}

        if direction == "BUY":
            # [A] EMA spread gücü — ne kadar hizalı
            ema_spread = (ema9 - ema21) / ema21 * 100 if ema21 > 0 else 0
            crossover  = (ema9_prev <= ema21_prev) and (ema9 > ema21)
            ema50_ok   = price > ema50
            if crossover:
                gate_points += 1
                gate_details["A_ema"] = "Crossover ✓"
                reasons.append(f"[A] EMA crossover taze")
            elif ema_spread > 0.1 and ema50_ok:
                gate_points += 1
                gate_details["A_ema"] = f"Spread+50 ✓ ({ema_spread:.2f}%)"
                reasons.append(f"[A] EMA hizalı+spread ({ema_spread:.2f}%) + fiyat>EMA50")
            elif ema_spread > 0.05:
                gate_details["A_ema"] = f"Zayıf spread ({ema_spread:.2f}%)"
                rejections.append(f"[A] EMA spread zayıf ({ema_spread:.2f}%)")
            else:
                gate_details["A_ema"] = "Yok"
                rejections.append(f"[A] EMA spread çok dar")

            # [B] RSI kalite seviyesi
            if rsi < 35:
                gate_points += 1
                gate_details["B_rsi"] = f"Aşırı satış ({rsi:.1f})"
                reasons.append(f"[B] RSI aşırı satış bölgesi ({rsi:.1f})")
            elif rsi < 45:
                gate_points += 1
                gate_details["B_rsi"] = f"Güçlü zone ({rsi:.1f})"
                reasons.append(f"[B] RSI güçlü alım zonu ({rsi:.1f})")
            elif rsi < 50:
                gate_points += 1
                gate_details["B_rsi"] = f"Nötr-iyi ({rsi:.1f})"
                reasons.append(f"[B] RSI nötr-düşük ({rsi:.1f})")
            else:
                gate_details["B_rsi"] = f"Nötr-yüksek ({rsi:.1f})"
                rejections.append(f"[B] RSI yüksek ({rsi:.1f}) — yaklaşan direnç")

            # [C] Hacim onayı
            if vol_ratio >= 1.5:
                gate_points += 1
                gate_details["C_vol"] = f"Güçlü ({vol_ratio:.2f}x)"
                reasons.append(f"[C] Hacim güçlü ({vol_ratio:.2f}x ortalama)")
            elif vol_ratio >= self.vol_min_ratio:
                gate_points += 1
                gate_details["C_vol"] = f"Yeterli ({vol_ratio:.2f}x)"
                reasons.append(f"[C] Hacim yeterli ({vol_ratio:.2f}x)")
            else:
                gate_details["C_vol"] = f"Düşük ({vol_ratio:.2f}x)"
                rejections.append(f"[C] Hacim zayıf ({vol_ratio:.2f}x < {self.vol_min_ratio}x)")

            # [D] Momentum (5-bar ROC)
            roc5  = (float(close.iloc[-1]) - float(close.iloc[-6])) / float(close.iloc[-6]) * 100
            roc10 = (float(close.iloc[-1]) - float(close.iloc[-11])) / float(close.iloc[-11]) * 100
            if roc5 > 0.5 and roc10 > 0:
                gate_points += 1
                gate_details["D_mom"] = f"Güçlü +{roc5:.2f}%"
                reasons.append(f"[D] Güçlü pozitif momentum (+{roc5:.2f}% / 5bar)")
            elif roc5 > 0.1:
                gate_points += 1
                gate_details["D_mom"] = f"Pozitif +{roc5:.2f}%"
                reasons.append(f"[D] Pozitif momentum (+{roc5:.2f}%)")
            elif roc5 > -0.1:
                gate_details["D_mom"] = f"Nötr ({roc5:+.2f}%)"
                rejections.append(f"[D] Momentum nötr ({roc5:+.2f}%)")
            else:
                gate_details["D_mom"] = f"Negatif {roc5:.2f}%"
                rejections.append(f"[D] Negatif momentum ({roc5:+.2f}%)")

            # [E] Mum onayı
            bulls = sum(
                1 for i in range(1, self.candle_confirm_bars + 1)
                if float(df["close"].iloc[-i]) > float(df["open"].iloc[-i])
            )
            if bulls >= self.candle_confirm_bars:
                gate_points += 1
                gate_details["E_candle"] = f"Tam onay {bulls}/{self.candle_confirm_bars}"
                reasons.append(f"[E] Mum onayı tam ({bulls}/{self.candle_confirm_bars})")
            elif bulls >= 1:
                gate_points += 1
                gate_details["E_candle"] = f"Kısmi {bulls}/{self.candle_confirm_bars}"
                reasons.append(f"[E] Mum onayı kısmi ({bulls}/{self.candle_confirm_bars})")
            else:
                gate_details["E_candle"] = "Yok"
                rejections.append(f"[E] Mum onayı yok (0/{self.candle_confirm_bars})")

            # [F] ADX — trend gücü
            if adx >= 30:
                gate_points += 1
                gate_details["F_adx"] = f"Güçlü trend ({adx:.1f})"
                reasons.append(f"[F] ADX güçlü trend ({adx:.1f})")
            elif adx >= self.adx_min:
                gate_points += 1
                gate_details["F_adx"] = f"Trend var ({adx:.1f})"
                reasons.append(f"[F] ADX trend mevcut ({adx:.1f})")
            else:
                gate_details["F_adx"] = f"Zayıf ({adx:.1f})"
                rejections.append(f"[F] ADX trend zayıf ({adx:.1f} < {self.adx_min})")

            # [G] BB pozisyonu — orta-alt bandı tercih et
            bb_pos = (price - bb_lower) / (bb_upper - bb_lower + 1e-9)
            if bb_pos < 0.35:
                gate_points += 1
                gate_details["G_bb"] = f"Alt bant ({bb_pos*100:.0f}%) — ideal"
                reasons.append(f"[G] Fiyat BB alt bölgesinde ({bb_pos*100:.0f}%) — iyi giriş")
            elif bb_pos < 0.60:
                gate_points += 1
                gate_details["G_bb"] = f"Orta bant ({bb_pos*100:.0f}%)"
                reasons.append(f"[G] Fiyat BB orta bölgesinde ({bb_pos*100:.0f}%)")
            else:
                gate_details["G_bb"] = f"Üst bant ({bb_pos*100:.0f}%) — riskli"
                rejections.append(f"[G] Fiyat BB üst bölgesine yakın ({bb_pos*100:.0f}%)")

            # [H] ATR kalitesi — volatilite karlılık için yeterli mi
            if atr_ratio >= 0.005:
                gate_points += 1
                gate_details["H_atr"] = f"Yüksek vol ({atr_ratio*100:.2f}%)"
                reasons.append(f"[H] ATR volatilite güçlü ({atr_ratio*100:.2f}%)")
            elif atr_ratio >= 0.003:
                gate_points += 1
                gate_details["H_atr"] = f"Yeterli vol ({atr_ratio*100:.2f}%)"
                reasons.append(f"[H] ATR volatilite yeterli ({atr_ratio*100:.2f}%)")
            else:
                gate_details["H_atr"] = f"Düşük vol ({atr_ratio*100:.2f}%)"
                rejections.append(f"[H] ATR volatilite düşük ({atr_ratio*100:.2f}%) — TP güç")

            # [I] Trend ivmesi — son 3 EMA kapanış hizalaması
            ema9_3  = float(_ema(close, self.ema_fast).iloc[-3])
            ema21_3 = float(_ema(close, self.ema_slow).iloc[-3])
            spread_now  = ema9 - ema21
            spread_3ago = ema9_3 - ema21_3
            if spread_now > spread_3ago and spread_now > 0:
                gate_points += 1
                gate_details["I_accel"] = "EMA ivme +"
                reasons.append(f"[I] EMA spread genişliyor — trend ivmesi")
            else:
                gate_details["I_accel"] = "İvme yok"
                rejections.append(f"[I] EMA spread daralıyor — zayıflayen trend")

            # [J] Hacim artışı trendi
            vol_5avg  = float(df["volume"].tail(5).mean()) if "volume" in df.columns else 1.0
            vol_20avg = float(df["volume"].tail(20).mean()) if "volume" in df.columns else 1.0
            if vol_5avg > vol_20avg * 1.1:
                gate_points += 1
                gate_details["J_vol_trend"] = f"Hacim artışta ({vol_5avg/vol_20avg:.2f}x)"
                reasons.append(f"[J] Son 5 bar hacim ortalamanın üzerinde")
            else:
                gate_details["J_vol_trend"] = f"Hacim normal/düşüş ({vol_5avg/vol_20avg:.2f}x)"
                rejections.append(f"[J] Hacim artış trendi yok")

        else:  # SELL
            # [A] EMA spread gücü
            ema_spread = (ema21 - ema9) / ema21 * 100 if ema21 > 0 else 0
            crossover  = (ema9_prev >= ema21_prev) and (ema9 < ema21)
            ema50_ok   = price < ema50
            if crossover:
                gate_points += 1
                gate_details["A_ema"] = "Crossover ✓ (SELL)"
                reasons.append(f"[A] Ölüm kesişimi taze")
            elif ema_spread > 0.1 and ema50_ok:
                gate_points += 1
                gate_details["A_ema"] = f"Hizalı+50 ({ema_spread:.2f}%)"
                reasons.append(f"[A] EMA hizalı SELL + fiyat<EMA50")
            else:
                gate_details["A_ema"] = "Zayıf"
                rejections.append(f"[A] SELL için EMA hizalaması zayıf")

            # [B] RSI
            if rsi > 65:
                gate_points += 1; gate_details["B_rsi"] = f"Aşırı alım ({rsi:.1f})"
                reasons.append(f"[B] RSI aşırı alım ({rsi:.1f})")
            elif rsi > 55:
                gate_points += 1; gate_details["B_rsi"] = f"Yüksek ({rsi:.1f})"
                reasons.append(f"[B] RSI yüksek bölge ({rsi:.1f})")
            elif rsi > 50:
                gate_points += 1; gate_details["B_rsi"] = f"Nötr-yüksek ({rsi:.1f})"
                reasons.append(f"[B] RSI nötr-yüksek ({rsi:.1f})")
            else:
                gate_details["B_rsi"] = f"Düşük ({rsi:.1f})"
                rejections.append(f"[B] RSI düşük SELL için ({rsi:.1f})")

            # [C] Hacim
            if vol_ratio >= 1.5:
                gate_points += 1; gate_details["C_vol"] = f"Güçlü ({vol_ratio:.2f}x)"
                reasons.append(f"[C] Güçlü hacim SELL ({vol_ratio:.2f}x)")
            elif vol_ratio >= self.vol_min_ratio:
                gate_points += 1; gate_details["C_vol"] = f"Yeterli ({vol_ratio:.2f}x)"
                reasons.append(f"[C] Yeterli hacim ({vol_ratio:.2f}x)")
            else:
                gate_details["C_vol"] = f"Düşük ({vol_ratio:.2f}x)"
                rejections.append(f"[C] Hacim düşük ({vol_ratio:.2f}x)")

            # [D] Momentum
            roc5  = (float(close.iloc[-1]) - float(close.iloc[-6])) / float(close.iloc[-6]) * 100
            roc10 = (float(close.iloc[-1]) - float(close.iloc[-11])) / float(close.iloc[-11]) * 100
            if roc5 < -0.5 and roc10 < 0:
                gate_points += 1; gate_details["D_mom"] = f"Güçlü neg {roc5:.2f}%"
                reasons.append(f"[D] Güçlü negatif momentum ({roc5:.2f}%)")
            elif roc5 < -0.1:
                gate_points += 1; gate_details["D_mom"] = f"Negatif {roc5:.2f}%"
                reasons.append(f"[D] Negatif momentum ({roc5:.2f}%)")
            else:
                gate_details["D_mom"] = f"Pozitif/nötr {roc5:.2f}%"
                rejections.append(f"[D] Momentum SELL için uygun değil ({roc5:+.2f}%)")

            # [E] Mum onayı (kırmızı mumlar)
            bears = sum(
                1 for i in range(1, self.candle_confirm_bars + 1)
                if float(df["close"].iloc[-i]) < float(df["open"].iloc[-i])
            )
            if bears >= self.candle_confirm_bars:
                gate_points += 1; gate_details["E_candle"] = f"Tam {bears}/{self.candle_confirm_bars}"
                reasons.append(f"[E] Mum onayı SELL tam")
            elif bears >= 1:
                gate_points += 1; gate_details["E_candle"] = f"Kısmi {bears}/{self.candle_confirm_bars}"
                reasons.append(f"[E] Mum onayı kısmi")
            else:
                gate_details["E_candle"] = "Yok"; rejections.append("[E] Mum onayı yok")

            # [F] ADX
            if adx >= 30:
                gate_points += 1; gate_details["F_adx"] = f"Güçlü ({adx:.1f})"
                reasons.append(f"[F] ADX güçlü ({adx:.1f})")
            elif adx >= self.adx_min:
                gate_points += 1; gate_details["F_adx"] = f"Var ({adx:.1f})"
                reasons.append(f"[F] ADX trend var ({adx:.1f})")
            else:
                gate_details["F_adx"] = f"Zayıf ({adx:.1f})"
                rejections.append(f"[F] ADX zayıf ({adx:.1f})")

            # [G] BB pozisyonu (SELL için üst band ideal)
            bb_pos = (price - bb_lower) / (bb_upper - bb_lower + 1e-9)
            if bb_pos > 0.65:
                gate_points += 1; gate_details["G_bb"] = f"Üst bant ({bb_pos*100:.0f}%)"
                reasons.append(f"[G] Fiyat BB üst bölgesinde — SELL ideal")
            elif bb_pos > 0.40:
                gate_points += 1; gate_details["G_bb"] = f"Orta ({bb_pos*100:.0f}%)"
                reasons.append(f"[G] BB orta bölge SELL")
            else:
                gate_details["G_bb"] = f"Alt ({bb_pos*100:.0f}%) — SELL riski"
                rejections.append(f"[G] Fiyat BB alt bölgesinde — SELL riski")

            # [H] ATR
            if atr_ratio >= 0.005:
                gate_points += 1; gate_details["H_atr"] = f"Yüksek ({atr_ratio*100:.2f}%)"
                reasons.append(f"[H] ATR volatilite güçlü")
            elif atr_ratio >= 0.003:
                gate_points += 1; gate_details["H_atr"] = f"Yeterli ({atr_ratio*100:.2f}%)"
                reasons.append(f"[H] ATR yeterli")
            else:
                gate_details["H_atr"] = f"Düşük ({atr_ratio*100:.2f}%)"
                rejections.append(f"[H] ATR düşük")

            # [I] Trend ivmesi SELL
            ema9_3  = float(_ema(close, self.ema_fast).iloc[-3])
            ema21_3 = float(_ema(close, self.ema_slow).iloc[-3])
            spread_now  = ema21 - ema9
            spread_3ago = ema21_3 - ema9_3
            if spread_now > spread_3ago and spread_now > 0:
                gate_points += 1; gate_details["I_accel"] = "EMA negatif ivme +"
                reasons.append(f"[I] Negatif EMA spread genişliyor")
            else:
                gate_details["I_accel"] = "İvme yok"
                rejections.append(f"[I] SELL EMA ivmesi yok")

            # [J] Hacim artışı
            vol_5avg  = float(df["volume"].tail(5).mean()) if "volume" in df.columns else 1.0
            vol_20avg = float(df["volume"].tail(20).mean()) if "volume" in df.columns else 1.0
            if vol_5avg > vol_20avg * 1.1:
                gate_points += 1; gate_details["J_vol_trend"] = f"Artışta"
                reasons.append(f"[J] Hacim artış trendi (SELL)")
            else:
                gate_details["J_vol_trend"] = "Normal"
                rejections.append(f"[J] Hacim artış trendi yok")

        # ── Sonuç ───────────────────────────────────────────────────────────────
        passed = gate_points >= self.gate_min_score

        # 100 tabanlı skor hesapla (uyumluluk için)
        normalized_score = (gate_points / 10.0) * 100

        components.update(gate_details)
        components["gate_points"] = gate_points
        components["gate_min"] = self.gate_min_score

        if passed:
            reasons.append(f"🎯 Kapı skoru: {gate_points}/10 (min {self.gate_min_score})")
        else:
            rejections.append(f"⛔ Kapı skoru yetersiz: {gate_points}/10 (min {self.gate_min_score})")

        return SignalScore(
            direction=direction,
            score=round(normalized_score, 1),
            gate_score=gate_points,
            passed=passed,
            hard_blocked=False,
            components=components,
            reasons=reasons,
            rejections=rejections,
        )
