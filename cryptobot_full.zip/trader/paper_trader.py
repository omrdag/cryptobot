"""
Kağıt (Paper) İşlem Motoru — Geliştirilmiş v2
===============================================
Gerçek piyasa koşullarını simüle eder:
  - Slippage (piyasa emrinde fiyat kayması)
  - Komisyon (giriş + çıkış)
  - Maksimum tutma süresi (max_holding_candles)
  - ATR tabanlı SL/TP desteği
  - Triple-barrier exit: SL | TP | Max Holding Time
  - LONG ve SHORT pozisyon desteği
"""

import time
from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, List, Optional
from utils.logger import get_logger

logger = get_logger()


@dataclass
class Position:
    symbol:         str
    quantity:       float
    entry_price:    float            # Slippage dahil gerçek giriş fiyatı
    raw_price:      float            # Slippage öncesi fiyat
    side:           str  = "long"    # "long" veya "short"
    entry_time:     datetime = field(default_factory=datetime.now)
    stop_loss:      float    = 0.0
    take_profit:    float    = 0.0
    candles_held:   int      = 0     # Kaç mum tutuldu (max holding için)
    entry_fee:      float    = 0.0   # Giriş komisyonu
    strategy_name:  str      = ""
    trade_id:       Optional[int] = None

    # Kaldıraç desteği
    leverage:            float = 1.0      # 1 = kaldıraçsız, 3 = 3x kaldıraç
    margin:              float = 0.0      # Gerçek marjin (bakiyeden düşülen)
    liquidation_price:   float = 0.0     # Tasfiye fiyatı (marjin = 0 olunca)

    # Trailing Stop desteği
    trailing_stop_pct:   float = 0.0      # 0 = kapalı; örn 0.015 = %1.5 trailing
    trailing_stop_price: float = 0.0      # Dinamik SL seviyesi (0 = henüz hesaplanmadı)
    highest_price:       float = 0.0      # LONG için en yüksek fiyat
    lowest_price:        float = 9e18     # SHORT için en düşük fiyat

    # Break-Even desteği
    break_even_pct:       float = 0.0     # Kârın bu oranını gördüğünde SL = giriş
    break_even_triggered: bool  = False

    # Smart Exit — Kısmi TP
    tp1_pct:          float = 0.0    # +%1.0 → 1. kısmi çıkış (%50 kapat)
    tp1_size_pct:     float = 0.0    # Pozisyonun %50'sini kapat
    tp1_triggered:    bool  = False
    tp2_pct:          float = 0.0    # +%2.0 → 2. kısmi çıkış — runner nihai hedef
    tp2_size_pct:     float = 0.0    # Kalan %50'yi kapat
    tp2_triggered:    bool  = False

    # Stage2 — Mutlak USDT kâr tetikleyici (% TP1'den önce veya sonra ateşlenir)
    usdt_tp1_trigger:   float = 0.0   # 0=kapalı; >0 → bu USDT kârda kısmi çıkış
    usdt_tp1_size:      float = 0.50  # Tetik anında kapatılacak oran (%50)
    usdt_tp1_triggered: bool  = False

    # Zaman bazlı çıkış
    min_profit_pct:   float = 0.0    # 4. mumdan sonra min kâr eşiği (%0.8)
    min_profit_bar:   int   = 4      # Kaçıncı mumda kontrol
    max_bars:         int   = 0      # 6 → 6 mum sonrası zayıf momentumda kapat (0 = kapalı)

    # Minimum hold koruması (yeni)
    entry_timestamp_unix:      float = 0.0   # time.time() ile set edilir
    min_hold_seconds:          int   = 0     # 0 = kapalı; 1800 = 30 dk (pullback)

    # Break-Even fiyat bazlı (yeni — mevcut break_even_pct'ye ek)
    break_even_trigger_price:  float = 0.0   # Bu fiyata ulaşınca SL=giriş; 0=kapalı
    break_even_activated:      bool  = False  # break_even_trigger_price tetiklendi mi?

    # Akıllı Zaman Bazlı Çıkış (Smart Time Exit) — runtime flag'ler, DB'ye yazılmaz
    trend_is_strong: bool  = False  # Ana döngüden her mumda güncellenir (EMA+ADX)
    is_large_lot:    bool  = False  # Large lot modu aktifse True (açılışta set edilir)
    is_manual:       bool  = False  # OKX SYNC ile tanınan manuel pozisyon — bot yönetmez

    # Live OKX takibi — bu pozisyon OKX'ten sync edildi, portfolio_value'ya ekleme
    live_tracking:             bool  = False


@dataclass
class Trade:
    symbol:       str
    side:         str        # BUY / SELL
    quantity:     float
    price:        float
    timestamp:    datetime
    pnl:          float      = 0.0
    fee:          float      = 0.0
    exit_reason:  str        = ""    # "SELL sinyal", "stop_loss", "take_profit", "max_holding"


class PaperTrader:
    """
    Gerçekçi kağıt işlem simülatörü.
    Slippage, komisyon ve zaman bazlı çıkış kurallarını uygular.
    LONG ve SHORT pozisyon desteği + kaldıraç desteği içerir.

    Kaldıraç (leverage) mantığı:
      - Marjin = bakiyenin trade_amount_pct kadarı (bakiyeden düşülür)
      - Notional = marjin × leverage (gerçek pozisyon büyüklüğü)
      - Miktar = notional / fiyat (3x daha fazla coin)
      - PnL = (çıkış - giriş) × miktar (leverage otomatik dahil)
      - Tasfiye = entry × (1 - 1/leverage) [LONG] / entry × (1 + 1/leverage) [SHORT]
    """

    def __init__(
        self,
        initial_balance:    float,
        trade_amount_pct:   float = 0.10,  # Sabit mod için
        stop_loss_pct:      float = 0.02,
        take_profit_pct:    float = 0.04,
        fee_rate:           float = 0.001,   # %0.1 komisyon
        slippage_pct:       float = 0.0005,  # %0.05 slippage
        max_holding_candles: int  = 48,      # Maksimum tutma süresi (mum)
        leverage:           float = 1.0,     # 1 = kaldıraçsız, 3 = 3x kaldıraç
    ):
        self.initial_balance     = initial_balance
        self.balance             = initial_balance
        self.available_usdt      = initial_balance  # Canlı modda OKX serbest bakiyesi
        self.trade_amount_pct    = trade_amount_pct
        self.stop_loss_pct       = stop_loss_pct
        self.take_profit_pct     = take_profit_pct
        self.fee_rate            = fee_rate
        self.slippage_pct        = slippage_pct
        self.max_holding_candles = max_holding_candles
        self.leverage            = max(1.0, leverage)

        self.positions:      Dict[str, Position] = {}
        self.trade_history:  List[Trade]         = []

        # İstatistikler
        self.total_fees_paid: float = 0.0

        if self.leverage > 1.0:
            logger.info(
                f"Kaldıraç modu aktif: {self.leverage:.0f}x | "
                f"Tasfiye mesafesi: ±%{100/self.leverage:.1f}"
            )

    # ─── LONG Pozisyon Açma ───────────────────────────────────────────────────

    def open_position(
        self,
        symbol:       str,
        price:        float,
        stop_loss:    float = 0.0,
        take_profit:  float = 0.0,
        strategy_name: str = "",
        quantity_override: Optional[float] = None,
        trade_value_override: Optional[float] = None,
        is_live_tracking: bool = False,
    ) -> bool:
        """
        LONG pozisyon aç. Slippage ve komisyon dahil.
        is_live_tracking: True ise OKX'te zaten açılan emir için bakiye kontrolü
                          yapma — sadece pozisyonu izlemeye al.
        Returns: True/False
        """
        if symbol in self.positions:
            logger.debug(f"{symbol}: Zaten açık pozisyon var")
            return False

        if price <= 0:
            logger.warning(f"{symbol}: open_position — fiyat sıfır, atlandı")
            return False

        # Slippage uygula (market emir = biraz daha pahalı al)
        effective_price = price * (1 + self.slippage_pct)

        # ── Marjin ve Notional Hesapla ────────────────────────────────────────
        # Marjin: bakiyeden düşülen gerçek para
        # Notional: marjin × kaldıraç = gerçek pozisyon büyüklüğü
        if quantity_override is not None:
            quantity  = quantity_override
            margin    = quantity * effective_price / max(self.leverage, 1)
            notional  = quantity * effective_price
        elif trade_value_override is not None:
            margin    = min(trade_value_override, self.balance) if not is_live_tracking else trade_value_override
            notional  = margin * self.leverage
            quantity  = notional / effective_price
        else:
            margin    = self.balance * self.trade_amount_pct
            notional  = margin * self.leverage
            quantity  = notional / effective_price

        # Canlı izleme modunda bakiye kontrolü yapma
        if not is_live_tracking:
            if margin < 1:
                logger.warning(f"{symbol}: Yetersiz bakiye (${self.balance:.2f})")
                return False

        # Komisyon notional üzerinden hesaplanır
        fee        = notional * self.fee_rate
        total_cost = margin + fee   # Bakiyeden düşülen gerçek tutar

        if not is_live_tracking:
            if total_cost > self.balance:
                margin    = (self.balance - fee) / (1 + self.fee_rate)
                notional  = margin * self.leverage
                quantity  = notional / effective_price
                fee       = notional * self.fee_rate
                total_cost = margin + fee

            if margin < 1:
                logger.warning(f"{symbol}: Komisyon sonrası yetersiz marjin")
                return False

        # SL/TP hesapla (verilmemişse) — LONG için
        # Kaldıraçla SL mesafesi daraltılır (tasfiye öncesi çıkış)
        if stop_loss == 0:
            sl_pct = min(self.stop_loss_pct, 0.8 / self.leverage)  # Max %80 marjin kaybı
            stop_loss = effective_price * (1 - sl_pct)
        if take_profit == 0:
            take_profit = effective_price * (1 + self.take_profit_pct)

        # Tasfiye fiyatı: marjinin tamamının eriduğu seviye
        # LONG: fiyat (1 - 1/leverage) oranında düşerse tasfiye
        liquidation = effective_price * (1 - 1 / self.leverage) if self.leverage > 1 else 0

        # Canlı izlemede bakiyeyi değiştirme — gerçek marjin OKX'te
        if not is_live_tracking:
            self.balance -= total_cost
            self.total_fees_paid += fee
        else:
            self.total_fees_paid += fee

        self.positions[symbol] = Position(
            symbol                = symbol,
            quantity              = quantity,
            entry_price           = effective_price,
            raw_price             = price,
            side                  = "long",
            stop_loss             = stop_loss,
            take_profit           = take_profit,
            entry_fee             = fee,
            strategy_name         = strategy_name,
            leverage              = self.leverage,
            margin                = margin,
            liquidation_price     = liquidation,
            entry_timestamp_unix  = time.time(),   # Minimum hold için
            live_tracking         = is_live_tracking,
        )

        self.trade_history.append(Trade(
            symbol    = symbol,
            side      = "BUY",
            quantity  = quantity,
            price     = effective_price,
            timestamp = datetime.now(),
            fee       = fee,
        ))

        lev_tag = f" [{self.leverage:.0f}x]" if self.leverage > 1 else ""
        liq_tag = f" | Tasfiye: ${liquidation:,.4f}" if liquidation > 0 else ""
        logger.info(
            f"[KAĞIT] LONG{lev_tag}  {symbol:10s} | "
            f"Piyasa: ${price:>12,.4f} | Giriş: ${effective_price:>12,.4f} | "
            f"Miktar: {quantity:.6f} | Marjin: ${margin:>9,.2f} | Notional: ${notional:>9,.2f} | "
            f"SL: ${stop_loss:>12,.4f} | TP: ${take_profit:>12,.4f}{liq_tag} | Komisyon: ${fee:.3f}"
        )
        return True

    # ─── SHORT Pozisyon Açma ──────────────────────────────────────────────────

    def open_short_position(
        self,
        symbol:       str,
        price:        float,
        stop_loss:    float = 0.0,
        take_profit:  float = 0.0,
        strategy_name: str = "",
        quantity_override: Optional[float] = None,
        trade_value_override: Optional[float] = None,
        is_live_tracking: bool = False,
    ) -> bool:
        """
        SHORT pozisyon aç. Fiyat düştükçe kâr eder.
        Slippage ve komisyon dahil.
        is_live_tracking: True ise OKX'te zaten açılan emir için bakiye kontrolü
                          yapma — sadece pozisyonu izlemeye al.
        Returns: True/False
        """
        if symbol in self.positions:
            logger.debug(f"{symbol}: Zaten açık pozisyon var")
            return False

        # Fiyat sıfırsa geçerli bir değer kullan
        if price <= 0:
            logger.warning(f"{symbol}: open_short_position — fiyat sıfır, atlandı")
            return False

        # Slippage uygula (short açarken biraz daha düşük fiyattan sat)
        effective_price = price * (1 - self.slippage_pct)

        # ── Marjin ve Notional Hesapla ────────────────────────────────────────
        if quantity_override is not None:
            quantity  = quantity_override
            margin    = quantity * effective_price / max(self.leverage, 1)
            notional  = quantity * effective_price
        elif trade_value_override is not None:
            margin    = min(trade_value_override, self.balance) if not is_live_tracking else trade_value_override
            notional  = margin * self.leverage
            quantity  = notional / effective_price
        else:
            margin    = self.balance * self.trade_amount_pct
            notional  = margin * self.leverage
            quantity  = notional / effective_price

        # Canlı izleme modunda bakiye kontrolü yapma (OKX zaten kabul etti)
        if not is_live_tracking:
            if margin < 1:
                logger.warning(f"{symbol}: Short için yetersiz bakiye (${self.balance:.2f})")
                return False

        # Komisyon notional üzerinden
        fee        = notional * self.fee_rate
        total_cost = margin + fee   # Bakiyeden düşülen gerçek tutar

        if not is_live_tracking:
            if total_cost > self.balance:
                margin    = (self.balance - fee) / (1 + self.fee_rate)
                notional  = margin * self.leverage
                quantity  = notional / effective_price
                fee       = notional * self.fee_rate
                total_cost = margin + fee

            if margin < 1:
                logger.warning(f"{symbol}: Komisyon sonrası yetersiz marjin")
                return False

        # SL/TP — SHORT için TERSİNE: SL yukarıda, TP aşağıda
        if stop_loss == 0:
            sl_pct    = min(self.stop_loss_pct, 0.8 / self.leverage)
            stop_loss = effective_price * (1 + sl_pct)     # Short SL = giriş üstü
        if take_profit == 0:
            take_profit = effective_price * (1 - self.take_profit_pct)  # Short TP = giriş altı

        # SHORT tasfiye: fiyat (1 + 1/leverage) oranında yükselirse
        liquidation = effective_price * (1 + 1 / self.leverage) if self.leverage > 1 else 0

        # Canlı izlemede bakiyeyi değiştirme — gerçek marjin OKX'te
        if not is_live_tracking:
            self.balance -= total_cost
            self.total_fees_paid += fee
        else:
            self.total_fees_paid += fee

        self.positions[symbol] = Position(
            symbol                = symbol,
            quantity              = quantity,
            entry_price           = effective_price,
            raw_price             = price,
            side                  = "short",
            stop_loss             = stop_loss,
            take_profit           = take_profit,
            entry_fee             = fee,
            strategy_name         = strategy_name,
            leverage              = self.leverage,
            margin                = margin,
            liquidation_price     = liquidation,
            entry_timestamp_unix  = time.time(),   # Minimum hold için
            live_tracking         = is_live_tracking,
        )

        self.trade_history.append(Trade(
            symbol    = symbol,
            side      = "SELL",
            quantity  = quantity,
            price     = effective_price,
            timestamp = datetime.now(),
            fee       = fee,
        ))

        lev_tag = f" [{self.leverage:.0f}x]" if self.leverage > 1 else ""
        liq_tag = f" | Tasfiye: ${liquidation:,.4f}" if liquidation > 0 else ""
        logger.info(
            f"[KAĞIT] SHORT{lev_tag} {symbol:10s} | "
            f"Piyasa: ${price:>12,.4f} | Giriş: ${effective_price:>12,.4f} | "
            f"Miktar: {quantity:.6f} | Marjin: ${margin:>9,.2f} | Notional: ${notional:>9,.2f} | "
            f"SL: ${stop_loss:>12,.4f} | TP: ${take_profit:>12,.4f}{liq_tag} | Komisyon: ${fee:.3f}"
        )
        return True

    # ─── Pozisyon Kapama ──────────────────────────────────────────────────────

    def close_position(
        self,
        symbol:      str,
        price:       float,
        reason:      str  = "Kapatıldı",
    ) -> Optional[float]:
        """
        Pozisyonu kapat. LONG ve SHORT için farklı PnL hesaplaması.
        Returns: Gerçekleşen PnL (None = pozisyon yoktu)
        """
        pos = self.positions.pop(symbol, None)
        if pos is None:
            return None

        # ── Kaldıraçlı PnL Hesaplama ──────────────────────────────────────────
        # Formül: PnL = (çıkış - giriş) × miktar - çıkış_komisyonu - giriş_komisyonu
        # Bakiye değişimi = marjin + PnL (marjin geri döner, kazanç/kayıp eklenir)
        # Bu formül hem 1x hem kaldıraçlı pozisyonlar için doğru çalışır.

        if pos.side == "long":
            # LONG kapanış: satarken slippage ile daha düşük fiyat alırız
            effective_price = price * (1 - self.slippage_pct)
            exit_fee        = pos.quantity * effective_price * self.fee_rate
            pnl             = (effective_price - pos.entry_price) * pos.quantity - exit_fee - pos.entry_fee
            pnl_pct         = (pnl / pos.margin) * 100 if pos.margin > 0 else 0
            # Marjin geri dön + net PnL
            self.balance   += pos.margin + pnl

        else:
            # SHORT kapanış: geri alırken slippage ile daha yüksek fiyat öderiz
            effective_price = price * (1 + self.slippage_pct)
            exit_fee        = pos.quantity * effective_price * self.fee_rate
            # SHORT'ta fiyat düşünce kâr: (giriş - çıkış) × miktar
            pnl             = (pos.entry_price - effective_price) * pos.quantity - exit_fee - pos.entry_fee
            pnl_pct         = (pnl / pos.margin) * 100 if pos.margin > 0 else 0
            # Marjin geri dön + net PnL
            self.balance   += pos.margin + pnl

        self.total_fees_paid += exit_fee

        self.trade_history.append(Trade(
            symbol      = symbol,
            side        = "BUY" if pos.side == "short" else "SELL",
            quantity    = pos.quantity,
            price       = effective_price,
            timestamp   = datetime.now(),
            pnl         = pnl,
            fee         = exit_fee,
            exit_reason = reason,
        ))

        emoji     = "✅" if pnl >= 0 else "❌"
        held_info = f" | Tutuldu: {pos.candles_held} mum" if pos.candles_held > 0 else ""
        lev_tag   = f" [{pos.leverage:.0f}x]" if pos.leverage > 1 else ""
        dir_label = "SHORT↑" if pos.side == "short" else "LONG ↓"
        logger.info(
            f"[KAĞIT] {dir_label}{lev_tag} KAPAT {symbol:10s} | "
            f"Çıkış: ${effective_price:>12,.4f} | "
            f"PnL: {emoji} ${pnl:>+9,.2f} ({pnl_pct:+.2f}%) | "
            f"Komisyon: ${exit_fee:.3f}{held_info} | Neden: {reason}"
        )
        return pnl

    def partial_close_position(
        self,
        symbol:    str,
        price:     float,
        pct:       float,   # Kapatılacak yüzde (0.0-1.0 arası, örn 0.30)
        reason:    str = "Kısmi TP",
    ) -> Optional[float]:
        """
        Pozisyonun belirtilen yüzdesini kapat (kısmi TP için).
        Returns: Kısmi kapanışın PnL'i (None = pozisyon yok)
        """
        pos = self.positions.get(symbol)
        if pos is None or pct <= 0:
            return None

        close_qty = pos.quantity * pct
        if close_qty <= 0:
            return None

        if pos.side == "long":
            effective_price = price * (1 - self.slippage_pct)
            exit_fee        = close_qty * effective_price * self.fee_rate
            entry_fee_share = pos.entry_fee * pct
            pnl             = (effective_price - pos.entry_price) * close_qty - exit_fee - entry_fee_share
            margin_released = pos.margin * pct
        else:
            effective_price = price * (1 + self.slippage_pct)
            exit_fee        = close_qty * effective_price * self.fee_rate
            entry_fee_share = pos.entry_fee * pct
            pnl             = (pos.entry_price - effective_price) * close_qty - exit_fee - entry_fee_share
            margin_released = pos.margin * pct

        # Pozisyonu küçült
        pos.quantity    -= close_qty
        pos.margin      -= margin_released
        pos.entry_fee   -= entry_fee_share
        self.balance    += margin_released + pnl
        self.total_fees_paid += exit_fee

        pnl_pct = (pnl / margin_released) * 100 if margin_released > 0 else 0
        emoji   = "✅" if pnl >= 0 else "❌"
        lev_tag = f" [{pos.leverage:.0f}x]" if pos.leverage > 1 else ""
        logger.info(
            f"[KISMİ] {symbol}{lev_tag} %{pct*100:.0f} kapatıldı @ ${effective_price:,.4f} | "
            f"PnL: {emoji} ${pnl:>+,.2f} ({pnl_pct:+.2f}%) | Neden: {reason}"
        )
        return pnl

    # ─── Triple-Barrier Çıkış Kontrolü ───────────────────────────────────────

    def check_exits(self, symbol: str, current_price: float) -> Optional[float]:
        """
        Gelişmiş çıkış kontrolü (LONG ve SHORT):
          Barrier 1: Stop Loss (sabit veya trailing)
          Barrier 2: Take Profit
          Barrier 3: Maksimum tutma süresi
          Bonus: Break-Even tetiklemesi + Trailing Stop güncelleme

        Returns: PnL (pozisyon kapandıysa) veya None
        """
        pos = self.positions.get(symbol)
        if not pos:
            return None

        # ── Manuel pozisyon — bot yönetmez, sadece izler ──────────────────────
        if getattr(pos, 'is_manual', False):
            return None

        from strategies.exit_rules import minutes_since_open as _min_open

        # ── Trailing Stop Güncelle ─────────────────────────────────────────────
        if pos.trailing_stop_pct > 0:
            self._update_trailing_stop(pos, current_price)

        # ── Break-Even (Yüzde Tabanlı) Tetikle ────────────────────────────────
        if pos.break_even_pct > 0 and not pos.break_even_triggered:
            self._check_break_even(pos, current_price)

        # ── Break-Even (Fiyat Tabanlı — exit_rules.py) ────────────────────────
        if pos.break_even_trigger_price > 0 and not pos.break_even_activated:
            if pos.side == "long" and current_price >= pos.break_even_trigger_price:
                new_sl = pos.entry_price * 1.001   # Giriş + %0.1 buffer
                if new_sl > pos.stop_loss:
                    old_sl = pos.stop_loss
                    pos.stop_loss           = new_sl
                    pos.break_even_activated = True
                    logger.info(
                        f"[BREAKEVEN ACTIVATED] {symbol} "
                        f"fiyat=${current_price:.4f} >= trigger=${pos.break_even_trigger_price:.4f} "
                        f"→ SL ${old_sl:.4f} → ${new_sl:.4f} (giriş seviyesi)"
                    )

        # ── Minimum Hold: kaç dakikadır açık? ─────────────────────────────────
        _minutes_open = _min_open(pos.entry_timestamp_unix)

        # ── Tasfiye Fiyatı Kontrolü (Kaldıraç) ────────────────────────────────
        if pos.liquidation_price > 0:
            if pos.side == "long" and current_price <= pos.liquidation_price:
                logger.warning(
                    f"[LİKİDASYON] {symbol} LONG pozisyon tasfiye edildi! "
                    f"Fiyat ${current_price:,.4f} <= Tasfiye ${pos.liquidation_price:,.4f} "
                    f"({pos.leverage:.0f}x kaldıraç)"
                )
                return self.close_position(symbol, pos.liquidation_price,
                                           reason=f"Tasfiye ({pos.leverage:.0f}x) ${pos.liquidation_price:,.4f}")
            elif pos.side == "short" and current_price >= pos.liquidation_price:
                logger.warning(
                    f"[LİKİDASYON] {symbol} SHORT pozisyon tasfiye edildi! "
                    f"Fiyat ${current_price:,.4f} >= Tasfiye ${pos.liquidation_price:,.4f} "
                    f"({pos.leverage:.0f}x kaldıraç)"
                )
                return self.close_position(symbol, pos.liquidation_price,
                                           reason=f"Tasfiye ({pos.leverage:.0f}x) ${pos.liquidation_price:,.4f}")

        # ── Stage2: Mutlak USDT Kâr Tetikleyici ──────────────────────────────
        # % TP1 ve % USDT tetikleyici birbirinden bağımsız çalışır; hangisi önce
        # tetiklenirse o geçerlidir. İkincisi tp1_triggered bayrağı sayesinde engellenir.
        if pos.usdt_tp1_trigger > 0 and not pos.usdt_tp1_triggered and not pos.tp1_triggered and pos.quantity > 0:
            _upnl_raw = ((current_price - pos.entry_price) * pos.quantity
                         if pos.side == "long"
                         else (pos.entry_price - current_price) * pos.quantity)
            if _upnl_raw >= pos.usdt_tp1_trigger:
                _s2_size = pos.usdt_tp1_size if pos.usdt_tp1_size > 0 else 0.50
                pos.usdt_tp1_triggered = True
                pos.tp1_triggered      = True   # % TP1 çift tetiklemesini önle
                partial_pnl = self.partial_close_position(
                    symbol, current_price, _s2_size,
                    reason=f"[STAGE2 USDT] +${_upnl_raw:,.1f} kâr → %{_s2_size*100:.0f} kısmi çıkış"
                )
                if not pos.break_even_triggered:
                    if pos.side == "long":
                        _new_sl = pos.entry_price * 1.001
                        if _new_sl > pos.stop_loss:
                            pos.stop_loss = _new_sl
                    else:
                        _new_sl = pos.entry_price * 0.999
                        if _new_sl < pos.stop_loss:
                            pos.stop_loss = _new_sl
                    pos.break_even_triggered = True
                logger.info(
                    f"[STAGE2 USDT TRIGGER] {symbol} | +${_upnl_raw:,.1f} USDT kâr → "
                    f"%{_s2_size*100:.0f} kapatıldı | SL→BE:${pos.stop_loss:.4f} | "
                    f"Runner TP2:+{pos.tp2_pct*100:.1f}% Trail:{pos.trailing_stop_pct*100:.1f}%"
                )

        # ── Smart Exit: Kısmi TP1 (+%1.0 → %50 kapat) ────────────────────────
        if pos.tp1_pct > 0 and not pos.tp1_triggered and pos.quantity > 0:
            if pos.side == "long":
                profit_pct = (current_price - pos.entry_price) / pos.entry_price
            else:
                profit_pct = (pos.entry_price - current_price) / pos.entry_price
            if profit_pct >= pos.tp1_pct:
                pos.tp1_triggered = True
                partial_pnl = self.partial_close_position(
                    symbol, current_price, pos.tp1_size_pct,
                    reason=f"Kısmi TP1 +{pos.tp1_pct*100:.1f}% → %{pos.tp1_size_pct*100:.0f} kapatıldı"
                )
                logger.info(
                    f"[TP1 PARTIAL TAKE] {symbol} +{profit_pct*100:.2f}% → "
                    f"%{pos.tp1_size_pct*100:.0f} kapatıldı | Kısmi PnL: ${partial_pnl:+,.2f}"
                )
                # Breakeven'e SL taşı (tp1 sonrası)
                if not pos.break_even_triggered:
                    if pos.side == "long":
                        new_sl = pos.entry_price * 1.001
                        if new_sl > pos.stop_loss:
                            pos.stop_loss = new_sl
                    else:
                        new_sl = pos.entry_price * 0.999
                        if new_sl < pos.stop_loss:
                            pos.stop_loss = new_sl
                    pos.break_even_triggered = True
                    logger.info(f"[BREAKEVEN ACTIVATED] {symbol} TP1 sonrası SL kilitleme: ${pos.stop_loss:,.4f}")
                # Runner aktif bilgisi
                if pos.tp1_size_pct < 1.0:
                    _runner_pct = round((1.0 - pos.tp1_size_pct) * 100)
                    logger.info(
                        f"[RUNNER ACTIVE] {symbol} kalan %{_runner_pct} pozisyon devam ediyor | "
                        f"TP2 hedef: +{pos.tp2_pct*100:.1f}% | Trailing: %{pos.trailing_stop_pct*100:.1f}"
                    )

        # ── Smart Exit: Kısmi TP2 (+%2.0 → kalan %50 runner kapat) ──────────
        if pos.tp2_pct > 0 and pos.tp1_triggered and not pos.tp2_triggered and pos.quantity > 0:
            if pos.side == "long":
                profit_pct = (current_price - pos.entry_price) / pos.entry_price
            else:
                profit_pct = (pos.entry_price - current_price) / pos.entry_price
            if profit_pct >= pos.tp2_pct:
                pos.tp2_triggered = True
                # TP2 size: orijinal pozisyonun %30'u → mevcut pozisyonda bu oran farklı
                # Mevcut miktar = orijinalin %70'i, biz %30 daha kapatıyoruz
                # Yani mevcut miktarın 30/70 = %42.86'sını kapayacağız
                actual_pct = pos.tp2_size_pct / (1.0 - pos.tp1_size_pct) if pos.tp1_size_pct < 1.0 else 0
                partial_pnl = self.partial_close_position(
                    symbol, current_price, min(actual_pct, 0.999),
                    reason=f"Kısmi TP2 +{pos.tp2_pct*100:.1f}% → %{pos.tp2_size_pct*100:.0f} (orijinal) kapatıldı"
                )
                logger.info(
                    f"[TP2 TARGET REACHED] {symbol} +{profit_pct*100:.2f}% → "
                    f"%{pos.tp2_size_pct*100:.0f} kapatıldı | Kısmi PnL: ${partial_pnl:+,.2f}"
                )

        # ── Smart Exit: Zaman Bazlı — 4 mumda min kâr yok → kapat (seçici) ────
        # Minimum hold aktifse ilk 30 dakika bu çıkışı engelle
        _min_hold_ok = (pos.min_hold_seconds <= 0) or (_minutes_open * 60 >= pos.min_hold_seconds)
        if (pos.min_profit_pct > 0 and pos.candles_held >= pos.min_profit_bar
                and not pos.tp1_triggered and pos.quantity > 0 and _min_hold_ok):
            if pos.side == "long":
                profit_pct = (current_price - pos.entry_price) / pos.entry_price
            else:
                profit_pct = (pos.entry_price - current_price) / pos.entry_price
            if profit_pct < pos.min_profit_pct:
                import config as _cfg_se
                _delay_bars = getattr(_cfg_se, "SMART_EXIT_DELAY_BARS", 2)
                _delay_tol  = getattr(_cfg_se, "SMART_EXIT_DELAY_LOSS_TOL", 0.003)
                _ext_bar    = pos.min_profit_bar + _delay_bars

                # Seçici geciktirme: hafif pozitif, BE'ye yakın veya trend güçlüyse
                _is_slight_pos = profit_pct >= -_delay_tol    # %-0.3 içinde (hafif negatif/pozitif)
                _is_be_area    = pos.break_even_activated or pos.break_even_triggered
                _is_trending   = getattr(pos, "trend_is_strong", False)
                _should_delay  = (_is_slight_pos or _is_be_area or _is_trending) \
                                 and pos.candles_held < _ext_bar

                if _should_delay:
                    # Geciktir — henüz kapatma
                    _reason_delay = (
                        "hafif pozitif" if _is_slight_pos and not _is_be_area and not _is_trending else
                        "BE aktif" if _is_be_area else
                        "trend güçlü" if _is_trending else "koşul"
                    )
                    logger.info(
                        f"[SMART EXIT DELAYED] {symbol} | mum={pos.candles_held}/{pos.min_profit_bar}: "
                        f"kâr={profit_pct*100:.2f}% eşiğin altında ama {_reason_delay} → "
                        f"{_ext_bar} muma kadar bekleniyor."
                    )
                else:
                    # Geciktirme dönemi de doldu veya hak yok → kapat
                    _bar_info = f"{pos.candles_held}/{_ext_bar}" if pos.candles_held >= _ext_bar else f"{pos.candles_held}/{pos.min_profit_bar}"
                    logger.info(
                        f"[SMART EXIT CONFIRMED] {symbol} | mum={_bar_info}: "
                        f"kâr={profit_pct*100:.2f}% < eşik={pos.min_profit_pct*100:.2f}% → kapatılıyor."
                    )
                    return self.close_position(
                        symbol, current_price,
                        reason=f"Zaman Limiti: {pos.candles_held} mumda +{pos.min_profit_pct*100:.1f}% kâr gelmedi"
                    )

        # ── Smart Exit: Dinamik Max Bar — TP/BE/Trend durumuna göre süre uzatılır ─
        if pos.max_bars > 0 and pos.quantity > 0 and _min_hold_ok:
            import config as _cfg

            if pos.candles_held >= pos.max_bars:
                # Kâr hesapla (LONG / SHORT)
                if pos.side == "long":
                    _profit_pct = (current_price - pos.entry_price) / pos.entry_price
                else:
                    _profit_pct = (pos.entry_price - current_price) / pos.entry_price

                # ── TP2 aktifse zaman limiti kalkıyor: trailing stop öncelikli ──
                if pos.tp2_triggered:
                    if pos.candles_held == pos.max_bars:
                        logger.info(
                            f"[TIME-EXIT] {symbol} mum={pos.candles_held}/{pos.max_bars}: "
                            f"TP2 aktif → zaman limiti kaldırıldı, trailing stop öncelikli "
                            f"| kâr:{_profit_pct*100:.2f}%"
                        )
                    # Kapatma yok — trailing stop zaten takip ediyor

                else:
                    # ── Dinamik max bar hesapla ─────────────────────────────────
                    _base_max  = pos.max_bars
                    _dyn_max   = _base_max
                    _ext_parts: list = []

                    if pos.tp1_triggered:
                        _tp1_ext = getattr(_cfg, "SMART_EXIT_TP1_EXTENSION", 3)
                        _dyn_max += _tp1_ext
                        _ext_parts.append(f"TP1+{_tp1_ext}bar")
                    elif pos.break_even_activated or pos.break_even_triggered:
                        _be_ext = getattr(_cfg, "SMART_EXIT_BE_EXTENSION", 2)
                        _dyn_max += _be_ext
                        _ext_parts.append(f"BE+{_be_ext}bar")

                    # Güçlü trend varsa SMART_EXIT_TREND_MAX_BARS'a kadar uzat
                    _trend_max = getattr(_cfg, "SMART_EXIT_TREND_MAX_BARS", 12)
                    if pos.trend_is_strong and _dyn_max < _trend_max:
                        _dyn_max = _trend_max
                        _ext_parts.append(f"TREND→{_trend_max}bar")

                    # ── PATCH-1: HARD CAP — mutlak üst sınır, hiçbir uzatma geçemez ─
                    _hc_small = getattr(_cfg, "SMART_EXIT_SMALL_LOT_ABS_MAX_BARS", 10)
                    _hc_large = getattr(_cfg, "SMART_EXIT_LARGE_LOT_ABS_MAX_BARS", 14)
                    _hard_cap = _hc_large if getattr(pos, "is_large_lot", False) else _hc_small
                    if _dyn_max > _hard_cap:
                        logger.info(
                            f"[TIME-EXIT HARD CAP] {symbol} → "
                            f"dyn_max={_dyn_max} hesaplandı ama absolute cap={_hard_cap} "
                            f"({'large lot' if getattr(pos, 'is_large_lot', False) else 'small lot'}) uygulandı"
                        )
                        _dyn_max = _hard_cap

                    # ── Uzatılmış süre de dolmuşsa: kapat ──────────────────────
                    if pos.candles_held >= _dyn_max:
                        _reason_str = (
                            f"uzatıldı({', '.join(_ext_parts)})"
                            if _ext_parts else "normal süre"
                        )
                        logger.info(
                            f"[TIME-EXIT] {symbol} mum={pos.candles_held}/{_dyn_max}: "
                            f"{_reason_str} | kâr:{_profit_pct*100:.2f}% → kapatılıyor"
                        )
                        return self.close_position(
                            symbol, current_price,
                            reason=(
                                f"Maks Bar Limiti: {_dyn_max} mum ({_reason_str})"
                                f" | kâr:{_profit_pct*100:.2f}%"
                            )
                        )

                    # ── İlk uzatma anında (base doldu, henüz dyn_max dolmadı) log ─
                    elif pos.candles_held == _base_max:
                        _ext_str = ", ".join(_ext_parts) if _ext_parts else "—"
                        logger.info(
                            f"[TIME-EXIT] {symbol} mum={pos.candles_held}/{_base_max}: "
                            f"Süre uzatıldı → {_dyn_max} bar ({_ext_str})"
                            f" | kâr:{_profit_pct*100:.2f}%"
                        )

        # ── Etkin SL: trailing varsa trailing kullan ───────────────────────────
        effective_sl = (
            pos.trailing_stop_price
            if pos.trailing_stop_pct > 0 and pos.trailing_stop_price > 0
            else pos.stop_loss
        )

        if pos.side == "long":
            if effective_sl > 0 and current_price <= effective_sl:
                reason = (
                    f"[TRAILING EXIT] Trailing Stop tetiklendi (${effective_sl:,.4f})"
                    if pos.trailing_stop_pct > 0 and pos.trailing_stop_price > 0
                    else f"Stop-Loss tetiklendi (${effective_sl:,.4f})"
                )
                return self.close_position(symbol, current_price, reason=reason)
            if pos.take_profit > 0 and current_price >= pos.take_profit and not pos.tp1_pct > 0:
                return self.close_position(
                    symbol, current_price,
                    reason=f"Take-Profit tetiklendi (${pos.take_profit:,.4f})"
                )
        else:  # short
            if effective_sl > 0 and current_price >= effective_sl:
                reason = (
                    f"[TRAILING EXIT] Short Trailing Stop tetiklendi (${effective_sl:,.4f})"
                    if pos.trailing_stop_pct > 0 and pos.trailing_stop_price > 0
                    else f"Short Stop-Loss tetiklendi (${effective_sl:,.4f})"
                )
                return self.close_position(symbol, current_price, reason=reason)
            if pos.take_profit > 0 and current_price <= pos.take_profit and not pos.tp1_pct > 0:
                return self.close_position(
                    symbol, current_price,
                    reason=f"Short Take-Profit tetiklendi (${pos.take_profit:,.4f})"
                )

        # ── Barrier 3: Maksimum Tutma Süresi (fallback) ───────────────────────
        if self.max_holding_candles > 0 and pos.candles_held >= self.max_holding_candles and pos.max_bars == 0:
            return self.close_position(
                symbol, current_price,
                reason=f"Maks. tutma süresi ({self.max_holding_candles} mum)"
            )

        return None

    def _update_trailing_stop(self, pos: "Position", current_price: float):
        """Trailing stop seviyesini fiyat hareketiyle güncelle."""
        if pos.side == "long":
            if current_price > pos.highest_price:
                pos.highest_price = current_price
            new_trail = pos.highest_price * (1 - pos.trailing_stop_pct)
            if new_trail > pos.trailing_stop_price:
                pos.trailing_stop_price = new_trail
            # Başlangıç: ilk trailing stop = giriş - trail
            if pos.trailing_stop_price == 0:
                pos.trailing_stop_price = pos.entry_price * (1 - pos.trailing_stop_pct)
                pos.highest_price = max(pos.highest_price, current_price)
        else:  # short
            if current_price < pos.lowest_price:
                pos.lowest_price = current_price
            new_trail = pos.lowest_price * (1 + pos.trailing_stop_pct)
            if pos.trailing_stop_price == 0 or new_trail < pos.trailing_stop_price:
                pos.trailing_stop_price = new_trail
            if pos.trailing_stop_price == 0:
                pos.trailing_stop_price = pos.entry_price * (1 + pos.trailing_stop_pct)
                pos.lowest_price = min(pos.lowest_price, current_price)

    def _check_break_even(self, pos: "Position", current_price: float):
        """Break-even: belirli kâr görülünce SL'yi giriş fiyatına çek."""
        if pos.side == "long":
            profit_pct = (current_price - pos.entry_price) / pos.entry_price
            if profit_pct >= pos.break_even_pct:
                # SL'yi giriş fiyatına taşı (küçük marj ile)
                new_sl = pos.entry_price * 1.001
                if new_sl > pos.stop_loss:
                    pos.stop_loss = new_sl
                    if pos.trailing_stop_price > 0:
                        pos.trailing_stop_price = max(pos.trailing_stop_price, new_sl)
                    pos.break_even_triggered = True
                    logger.info(f"[BREAKEVEN ACTIVATED] {pos.symbol} +{profit_pct*100:.2f}% → SL kilitleme: ${new_sl:,.4f}")
        else:  # short
            profit_pct = (pos.entry_price - current_price) / pos.entry_price
            if profit_pct >= pos.break_even_pct:
                new_sl = pos.entry_price * 0.999
                if new_sl < pos.stop_loss:
                    pos.stop_loss = new_sl
                    if pos.trailing_stop_price > 0:
                        pos.trailing_stop_price = min(pos.trailing_stop_price, new_sl)
                    pos.break_even_triggered = True
                    logger.info(f"[BREAKEVEN ACTIVATED] {pos.symbol} SHORT +{profit_pct*100:.2f}% → SL kilitleme: ${new_sl:,.4f}")

    def increment_candle_count(self):
        """Her döngüde tüm açık pozisyonların mum sayacını artır."""
        for pos in self.positions.values():
            pos.candles_held += 1

    # ─── Portföy Değeri ───────────────────────────────────────────────────────

    def portfolio_value(self, prices: Dict[str, float]) -> float:
        """Toplam portföy değeri (USDT). SHORT pozisyonlar için unrealized PnL dahil.
        Live OKX takip pozisyonları (live_tracking=True) atlanır — değerleri
        zaten trader.balance (OKX equity) içinde dahil."""
        position_value = 0.0
        for sym, pos in self.positions.items():
            if getattr(pos, "live_tracking", False):
                # OKX'ten sync'lenmiş pozisyon: değeri trader.balance'a dahil
                continue
            current = prices.get(sym, pos.entry_price)
            if pos.side == "long":
                position_value += pos.quantity * current
            else:
                # SHORT: teminat + gerçekleşmemiş PnL
                margin = pos.quantity * pos.entry_price
                upnl   = (pos.entry_price - current) * pos.quantity
                position_value += margin + upnl
        return self.balance + position_value

    def unrealized_pnl(self, symbol: str, current_price: float) -> Optional[float]:
        """Gerçekleşmemiş PnL (long ve short için)."""
        pos = self.positions.get(symbol)
        if not pos:
            return None
        if pos.side == "long":
            return (current_price - pos.entry_price) * pos.quantity
        else:
            return (pos.entry_price - current_price) * pos.quantity

    def unrealized_pnl_pct(self, symbol: str, current_price: float) -> Optional[float]:
        """Gerçekleşmemiş PnL yüzdesi."""
        pos = self.positions.get(symbol)
        if not pos or pos.entry_price == 0:
            return None
        if pos.side == "long":
            return ((current_price - pos.entry_price) / pos.entry_price) * 100
        else:
            return ((pos.entry_price - current_price) / pos.entry_price) * 100

    # ─── Performans İstatistikleri ────────────────────────────────────────────

    def performance_report(self, current_prices: Dict[str, float]) -> dict:
        """Kapsamlı performans raporu."""
        closed = [t for t in self.trade_history if t.pnl != 0 or t.exit_reason]
        closed = [t for t in self.trade_history if t.side in ("SELL", "BUY") and t.exit_reason]
        wins   = [t for t in closed if t.pnl > 0]
        losses = [t for t in closed if t.pnl <= 0]

        total_pnl   = sum(t.pnl for t in closed)
        gross_wins  = sum(t.pnl for t in wins)
        gross_losses = abs(sum(t.pnl for t in losses))
        profit_factor = (gross_wins / gross_losses) if gross_losses > 0 else float("inf")

        avg_win  = (gross_wins  / len(wins))   if wins   else 0
        avg_loss = (gross_losses / len(losses)) if losses else 0

        expectancy = (
            (len(wins) / len(closed)) * avg_win -
            (len(losses) / len(closed)) * avg_loss
        ) if closed else 0

        portfolio_val  = self.portfolio_value(current_prices)
        total_return   = ((portfolio_val - self.initial_balance) / self.initial_balance) * 100
        win_rate       = (len(wins) / len(closed) * 100) if closed else 0

        # Max drawdown
        equity_curve   = self._equity_curve(current_prices)
        max_dd         = self._max_drawdown(equity_curve)

        return {
            "initial_balance":   self.initial_balance,
            "current_balance":   self.balance,
            "portfolio_value":   portfolio_val,
            "total_return_pct":  total_return,
            "realized_pnl":      total_pnl,
            "unrealized_pnl":    portfolio_val - self.balance,
            "total_trades":      len(closed),
            "winning_trades":    len(wins),
            "losing_trades":     len(losses),
            "win_rate_pct":      win_rate,
            "profit_factor":     profit_factor,
            "avg_win":           avg_win,
            "avg_loss":          avg_loss,
            "expectancy":        expectancy,
            "max_drawdown_pct":  max_dd,
            "total_fees_paid":   self.total_fees_paid,
            "open_positions":    len(self.positions),
        }

    def _equity_curve(self, current_prices: Dict[str, float]) -> list:
        """Basit equity curve (PnL geçmişinden)."""
        equity = self.initial_balance
        curve  = [equity]
        for trade in self.trade_history:
            if trade.exit_reason:  # Yalnızca kapanış işlemleri
                equity += trade.pnl
                curve.append(equity)
        return curve

    @staticmethod
    def _max_drawdown(equity_curve: list) -> float:
        """Maksimum drawdown yüzdesi."""
        if len(equity_curve) < 2:
            return 0.0
        peak = equity_curve[0]
        max_dd = 0.0
        for val in equity_curve:
            if val > peak:
                peak = val
            dd = (peak - val) / peak * 100 if peak > 0 else 0
            if dd > max_dd:
                max_dd = dd
        return max_dd
