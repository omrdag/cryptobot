"""
Exit Rules — Temiz Pozisyon Çıkış Mantığı
==========================================
Temel Felsefe:
  SL ve TP her zaman çalışır — piyasa beklenmez.
  İlk 30 dakika sinyal kaynaklı çıkışlar (SELL sinyali, zaman bazlı, kâr yok)
  engellenir; pozisyona nefes aldırılır.
  Break-even tetiklendiğinde SL fiyata taşınır — bedava risk kalmaz.

Kullanım (paper_trader.check_exits içinden):
  from strategies.exit_rules import should_exit_long, check_and_apply_break_even
"""

import time
from typing import Tuple


def should_exit_long(
    position:     dict,
    current_price: float,
    minutes_open:  int,
) -> Tuple[bool, str]:
    """
    LONG pozisyon için çıkış kararı.

    position sözlüğünde beklenen alanlar:
      stop_loss              float  — stop loss fiyatı
      take_profit            float  — take profit fiyatı
      break_even_trigger     float  — bu fiyata ulaşınca SL=giriş (0 = kapalı)
      break_even_activated   bool   — break-even zaten aktif mi?

    Dönüş: (should_exit: bool, reason: str)
    """
    sl  = position.get("stop_loss",  0.0)
    tp  = position.get("take_profit", 0.0)

    # ── Barrier 1: Stop Loss — her zaman önce kontrol ────────────────────────
    if sl > 0 and current_price <= sl:
        return True, f"Stop loss tetiklendi (${sl:.4f})"

    # ── Barrier 2: Take Profit — her zaman ───────────────────────────────────
    if tp > 0 and current_price >= tp:
        return True, f"Take profit tetiklendi (${tp:.4f})"

    # ── Minimum Hold: İlk 30 dakika sinyal kaynaklı çıkış engellenir ─────────
    if minutes_open < 30:
        return False, f"Minimum hold aktif ({minutes_open} dk < 30 dk)"

    return False, "Hold"


def should_exit_short(
    position:     dict,
    current_price: float,
    minutes_open:  int,
) -> Tuple[bool, str]:
    """
    SHORT pozisyon için çıkış kararı (simetrik).
    """
    sl  = position.get("stop_loss",  0.0)
    tp  = position.get("take_profit", 0.0)

    if sl > 0 and current_price >= sl:
        return True, f"Short stop loss tetiklendi (${sl:.4f})"

    if tp > 0 and current_price <= tp:
        return True, f"Short take profit tetiklendi (${tp:.4f})"

    if minutes_open < 30:
        return False, f"Minimum hold aktif ({minutes_open} dk < 30 dk)"

    return False, "Hold"


def check_and_apply_break_even(position: dict, current_price: float) -> dict:
    """
    Break-even tetiklemesi: fiyat `break_even_trigger` seviyesine ulaşınca
    stop_loss = entry_price olarak güncellenir.

    Orijinal position dict'ini döndürür (in-place güncellenir).
    """
    if position.get("break_even_activated", False):
        return position   # Zaten aktif

    trigger = position.get("break_even_trigger", 0.0)
    if trigger <= 0:
        return position   # Kapalı

    entry = position.get("entry_price", 0.0)
    if current_price >= trigger and entry > 0:
        old_sl = position.get("stop_loss", 0.0)
        # SL'yi giriş fiyatına taşı (biraz üstüne: +%0.1 buffer)
        new_sl = entry * 1.001
        if new_sl > old_sl:
            position["stop_loss"]            = new_sl
            position["break_even_activated"] = True
        # else: zaten daha iyi bir SL var, dokunma

    return position


def minutes_since_open(entry_timestamp_unix: float) -> int:
    """Pozisyonun kaç dakikadır açık olduğunu döndür (int)."""
    if entry_timestamp_unix <= 0:
        return 9999   # Bilinmiyorsa kısıtlama getirme
    elapsed = time.time() - entry_timestamp_unix
    return max(0, int(elapsed / 60))


def build_position_dict(pos) -> dict:
    """
    Position dataclass → should_exit_long uyumlu sözlük.
    pos: trader.paper_trader.Position instance
    """
    return {
        "entry_price":           pos.entry_price,
        "stop_loss":             pos.stop_loss,
        "take_profit":           pos.take_profit,
        "break_even_trigger":    getattr(pos, "break_even_trigger_price", 0.0),
        "break_even_activated":  getattr(pos, "break_even_activated",     False),
    }
