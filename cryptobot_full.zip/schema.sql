-- ═══════════════════════════════════════════════════════════════════════════
-- CryptoBot PostgreSQL Schema
-- Railway'de PostgreSQL servisi ekledikten sonra bu dosyayı çalıştır:
--   psql $DATABASE_URL -f schema.sql
-- ═══════════════════════════════════════════════════════════════════════════

-- ── Trades ──────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS trades (
    id              SERIAL PRIMARY KEY,
    symbol          TEXT        NOT NULL,
    side            TEXT        NOT NULL DEFAULT 'buy',   -- 'buy' / 'sell'
    entry_price     NUMERIC(20,8) NOT NULL,
    exit_price      NUMERIC(20,8),
    quantity        NUMERIC(20,8) NOT NULL,
    stop_loss       NUMERIC(20,8),
    take_profit     NUMERIC(20,8),
    pnl             NUMERIC(20,4) DEFAULT 0,
    pnl_percent     NUMERIC(10,4) DEFAULT 0,
    status          TEXT        DEFAULT 'open',           -- 'open' / 'closed' / 'stopped'
    exit_reason     TEXT        DEFAULT '',
    strategy_name   TEXT        DEFAULT '',
    mode            TEXT        DEFAULT 'paper',          -- 'paper' / 'live'
    commission      NUMERIC(20,8) DEFAULT 0,
    opened_at       TIMESTAMPTZ DEFAULT NOW(),
    closed_at       TIMESTAMPTZ,
    -- Ek alanlar (mevcut sistemle uyumlu)
    leverage        INTEGER     DEFAULT 1,
    lot_type        TEXT        DEFAULT 'standard',       -- 'standard' / 'large'
    is_adopted      BOOLEAN     DEFAULT FALSE,
    notional        NUMERIC(20,4),
    filled_notional NUMERIC(20,4)
);

CREATE INDEX IF NOT EXISTS idx_trades_symbol    ON trades(symbol);
CREATE INDEX IF NOT EXISTS idx_trades_status    ON trades(status);
CREATE INDEX IF NOT EXISTS idx_trades_opened_at ON trades(opened_at DESC);
CREATE INDEX IF NOT EXISTS idx_trades_closed_at ON trades(closed_at DESC);

-- ── Positions (açık pozisyonlar — her sembol için max 1 satır) ──────────────
CREATE TABLE IF NOT EXISTS positions (
    id              SERIAL PRIMARY KEY,
    symbol          TEXT        NOT NULL UNIQUE,
    side            TEXT        NOT NULL DEFAULT 'long',  -- 'long' / 'short'
    entry_price     NUMERIC(20,8) NOT NULL,
    current_price   NUMERIC(20,8) DEFAULT 0,
    quantity        NUMERIC(20,8) NOT NULL,
    pnl             NUMERIC(20,4) DEFAULT 0,
    pnl_percent     NUMERIC(10,4) DEFAULT 0,
    stop_loss       NUMERIC(20,8),
    take_profit     NUMERIC(20,8),
    status          TEXT        DEFAULT 'open',
    mode            TEXT        DEFAULT 'paper',
    strategy_name   TEXT        DEFAULT '',
    trade_id        INTEGER     REFERENCES trades(id),
    leverage        INTEGER     DEFAULT 1,
    candles_held    INTEGER     DEFAULT 0,
    max_bars        INTEGER     DEFAULT 8,
    lot_type        TEXT        DEFAULT 'standard',
    is_adopted      BOOLEAN     DEFAULT FALSE,
    -- Mesafe metrikleri (SSE için)
    distance_to_sl_pct    NUMERIC(10,4),
    distance_to_tp_pct    NUMERIC(10,4),
    distance_to_be_pct    NUMERIC(10,4),
    distance_to_tp1_pct   NUMERIC(10,4),
    -- Smart exit state
    break_even_activated  BOOLEAN DEFAULT FALSE,
    tp1_triggered         BOOLEAN DEFAULT FALSE,
    tp2_triggered         BOOLEAN DEFAULT FALSE,
    trailing_stop_price   NUMERIC(20,8),
    -- Zaman
    opened_at       TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE UNIQUE INDEX IF NOT EXISTS positions_symbol_key ON positions(symbol);

-- ── Balances (periyodik bakiye snapshot) ────────────────────────────────────
CREATE TABLE IF NOT EXISTS balances (
    id                  SERIAL PRIMARY KEY,
    total_balance       NUMERIC(20,4) NOT NULL,
    available_balance   NUMERIC(20,4) NOT NULL,
    daily_pnl           NUMERIC(20,4) DEFAULT 0,
    total_pnl           NUMERIC(20,4) DEFAULT 0,
    open_positions      INTEGER       DEFAULT 0,
    mode                TEXT          DEFAULT 'paper',
    recorded_at         TIMESTAMPTZ   DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_balances_recorded_at ON balances(recorded_at DESC);

-- ── Signals (strateji sinyalleri) ───────────────────────────────────────────
CREATE TABLE IF NOT EXISTS signals (
    id              SERIAL PRIMARY KEY,
    symbol          TEXT    NOT NULL,
    signal          TEXT    NOT NULL,   -- 'BUY' / 'SELL' / 'HOLD'
    strategy_name   TEXT    DEFAULT '',
    price           NUMERIC(20,8),
    atr             NUMERIC(20,8),
    reasons         JSONB   DEFAULT '[]',
    acted           TEXT    DEFAULT 'no',
    blocked_reason  TEXT    DEFAULT '',
    mode            TEXT    DEFAULT 'paper',
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_signals_symbol     ON signals(symbol);
CREATE INDEX IF NOT EXISTS idx_signals_created_at ON signals(created_at DESC);

-- ── Orders (emir yaşam döngüsü) ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS orders (
    id               SERIAL PRIMARY KEY,
    client_order_id  TEXT    UNIQUE NOT NULL,
    symbol           TEXT    NOT NULL,
    side             TEXT    NOT NULL,
    order_type       TEXT    DEFAULT 'market',
    quantity         NUMERIC(20,8),
    price            NUMERIC(20,8),
    filled_price     NUMERIC(20,8),
    filled_qty       NUMERIC(20,8),
    fee              NUMERIC(20,8) DEFAULT 0,
    status           TEXT    DEFAULT 'pending',
    stop_loss        NUMERIC(20,8),
    take_profit      NUMERIC(20,8),
    strategy_name    TEXT    DEFAULT '',
    mode             TEXT    DEFAULT 'paper',
    trade_id         INTEGER REFERENCES trades(id),
    created_at       TIMESTAMPTZ DEFAULT NOW(),
    filled_at        TIMESTAMPTZ
);

-- ── Risk Events ──────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS risk_events (
    id                  SERIAL PRIMARY KEY,
    symbol              TEXT    NOT NULL,
    event_type          TEXT    NOT NULL,
    blocked             BOOLEAN DEFAULT FALSE,
    reason              TEXT    DEFAULT '',
    portfolio_value     NUMERIC(20,4),
    open_positions      INTEGER,
    consecutive_losses  INTEGER,
    mode                TEXT    DEFAULT 'paper',
    created_at          TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_risk_events_created_at ON risk_events(created_at DESC);

-- ── Logs ─────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS logs (
    id          SERIAL PRIMARY KEY,
    level       TEXT    DEFAULT 'info',
    category    TEXT    DEFAULT 'system',
    message     TEXT    NOT NULL,
    details     TEXT    DEFAULT '',
    created_at  TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_logs_created_at ON logs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_logs_level      ON logs(level);

-- ── Settings (tek satır bot konfigürasyonu) ──────────────────────────────────
CREATE TABLE IF NOT EXISTS settings (
    id                          SERIAL PRIMARY KEY,
    -- Borsa
    exchange                    TEXT    DEFAULT 'okx',
    trading_pair                TEXT    DEFAULT 'BTC/USDT',
    trading_pairs               JSONB   DEFAULT '["BTCUSDT","ETHUSDT","SOLUSDT"]',
    timeframe                   TEXT    DEFAULT '1h',
    -- İşlem boyutu
    trade_amount                NUMERIC(10,2) DEFAULT 175,
    trade_amount_type           TEXT    DEFAULT 'fixed',
    leverage                    INTEGER DEFAULT 10,
    -- Risk
    stop_loss_percent           NUMERIC(6,2) DEFAULT 2.5,
    take_profit_percent         NUMERIC(6,2) DEFAULT 5.0,
    max_daily_loss              NUMERIC(10,2) DEFAULT 200,
    max_daily_loss_pct          NUMERIC(6,2) DEFAULT 6,
    max_open_positions          INTEGER DEFAULT 5,
    max_consecutive_losses      INTEGER DEFAULT 5,
    -- Mod
    trading_mode                TEXT    DEFAULT 'paper',   -- 'paper' / 'live'
    direction_mode              TEXT    DEFAULT 'long-short',
    bot_running                 BOOLEAN DEFAULT FALSE,
    initial_balance             NUMERIC(12,2) DEFAULT 10000,
    -- API (şifreli tutulmalı)
    api_key                     TEXT    DEFAULT '',
    api_secret                  TEXT    DEFAULT '',
    api_passphrase              TEXT    DEFAULT '',
    -- Smart Exit
    breakeven_trigger_pct       NUMERIC(6,2) DEFAULT 1.2,
    breakeven_offset_pct        NUMERIC(6,2) DEFAULT 0.1,
    partial_tp1_pct             NUMERIC(6,2) DEFAULT 1.5,
    partial_tp1_size            NUMERIC(6,2) DEFAULT 50,
    partial_tp2_pct             NUMERIC(6,2) DEFAULT 2.5,
    partial_tp2_size            NUMERIC(6,2) DEFAULT 50,
    trailing_stop_pct           NUMERIC(6,2) DEFAULT 1.0,
    runner_position_pct         NUMERIC(6,2) DEFAULT 0,
    max_bars_in_trade           INTEGER DEFAULT 8,
    min_profit_after_4_bars_pct NUMERIC(6,2) DEFAULT 0.7,
    -- Large Lot
    large_lot_enabled           BOOLEAN DEFAULT TRUE,
    large_lot_min_quality       TEXT    DEFAULT 'A',
    large_lot_min_notional      NUMERIC(10,2) DEFAULT 2000,
    -- Telegram (opsiyonel)
    telegram_token              TEXT    DEFAULT '',
    telegram_chat_id            TEXT    DEFAULT '',
    -- Zaman
    created_at                  TIMESTAMPTZ DEFAULT NOW(),
    updated_at                  TIMESTAMPTZ DEFAULT NOW()
);

-- Default settings satırı
INSERT INTO settings DEFAULT VALUES
ON CONFLICT DO NOTHING;

-- ── Scanner Runs ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS scanner_runs (
    id              SERIAL PRIMARY KEY,
    scanned_at      TIMESTAMPTZ DEFAULT NOW(),
    total_scanned   INTEGER,
    total_filtered  INTEGER,
    shortlist_size  INTEGER,
    scan_seconds    NUMERIC(6,2),
    market_regime   TEXT,
    scanner_type    TEXT    DEFAULT 'GENERAL',
    shortlist       JSONB   DEFAULT '[]',
    rejected        JSONB   DEFAULT '[]'
);

-- ── Ghost Blacklist (phantom sembol takibi) ──────────────────────────────────
CREATE TABLE IF NOT EXISTS ghost_blacklist (
    id          SERIAL PRIMARY KEY,
    symbol      TEXT    NOT NULL UNIQUE,
    reason      TEXT    DEFAULT '',
    added_at    TIMESTAMPTZ DEFAULT NOW()
);

-- ═══════════════════════════════════════════════════════════════════════════
-- MIGRATION: Mevcut DB'ye eksik sütunlar ekle (idempotent)
-- ═══════════════════════════════════════════════════════════════════════════

ALTER TABLE positions ADD COLUMN IF NOT EXISTS candles_held         INTEGER DEFAULT 0;
ALTER TABLE positions ADD COLUMN IF NOT EXISTS max_bars             INTEGER DEFAULT 8;
ALTER TABLE positions ADD COLUMN IF NOT EXISTS lot_type             TEXT    DEFAULT 'standard';
ALTER TABLE positions ADD COLUMN IF NOT EXISTS is_adopted           BOOLEAN DEFAULT FALSE;
ALTER TABLE positions ADD COLUMN IF NOT EXISTS distance_to_sl_pct  NUMERIC(10,4);
ALTER TABLE positions ADD COLUMN IF NOT EXISTS distance_to_tp_pct  NUMERIC(10,4);
ALTER TABLE positions ADD COLUMN IF NOT EXISTS distance_to_be_pct  NUMERIC(10,4);
ALTER TABLE positions ADD COLUMN IF NOT EXISTS distance_to_tp1_pct NUMERIC(10,4);
ALTER TABLE positions ADD COLUMN IF NOT EXISTS break_even_activated BOOLEAN DEFAULT FALSE;
ALTER TABLE positions ADD COLUMN IF NOT EXISTS tp1_triggered        BOOLEAN DEFAULT FALSE;
ALTER TABLE positions ADD COLUMN IF NOT EXISTS tp2_triggered        BOOLEAN DEFAULT FALSE;
ALTER TABLE positions ADD COLUMN IF NOT EXISTS trailing_stop_price  NUMERIC(20,8);

ALTER TABLE trades ADD COLUMN IF NOT EXISTS leverage        INTEGER DEFAULT 1;
ALTER TABLE trades ADD COLUMN IF NOT EXISTS lot_type        TEXT    DEFAULT 'standard';
ALTER TABLE trades ADD COLUMN IF NOT EXISTS is_adopted      BOOLEAN DEFAULT FALSE;
ALTER TABLE trades ADD COLUMN IF NOT EXISTS notional        NUMERIC(20,4);
ALTER TABLE trades ADD COLUMN IF NOT EXISTS filled_notional NUMERIC(20,4);

ALTER TABLE settings ADD COLUMN IF NOT EXISTS large_lot_enabled        BOOLEAN DEFAULT TRUE;
ALTER TABLE settings ADD COLUMN IF NOT EXISTS large_lot_min_quality    TEXT    DEFAULT 'A';
ALTER TABLE settings ADD COLUMN IF NOT EXISTS large_lot_min_notional   NUMERIC(10,2) DEFAULT 2000;
ALTER TABLE settings ADD COLUMN IF NOT EXISTS api_passphrase           TEXT    DEFAULT '';
ALTER TABLE settings ADD COLUMN IF NOT EXISTS trading_pairs            JSONB   DEFAULT '["BTCUSDT","ETHUSDT","SOLUSDT"]';
