"""
Database Writer — Web Panel Entegrasyonu
=========================================
Trading botunu PostgreSQL veritabanına bağlar.
Web paneli bu verilerle anlık güncellenir.

Yazılan tablolar:
  - trades          → Açılan/kapanan işlemler
  - positions       → Anlık açık pozisyonlar
  - balances        → Periyodik bakiye snapshotları
  - logs            → Bot logları (tüm kategoriler)
  - signals         → Strateji sinyalleri (BUY/SELL/HOLD)
  - orders          → Emir yaşam döngüsü
  - risk_events     → Risk motoru kararları
  - settings        → Bot çalışma durumu
"""

import os
import json
from typing import Optional
from datetime import datetime
from utils.logger import get_logger

logger = get_logger()


class DBWriter:
    """PostgreSQL tabanlı bot-panel veri köprüsü."""

    def __init__(self, dsn: str):
        import psycopg2
        import psycopg2.extras
        self._dsn  = dsn
        self._psycopg2 = psycopg2
        self.conn  = self._connect()
        logger.info("Veritabanı bağlantısı kuruldu.")

    def _connect(self):
        """Yeni bağlantı oluştur."""
        conn = self._psycopg2.connect(self._dsn)
        conn.autocommit = True
        return conn

    def _reconnect(self):
        """Kopan bağlantıyı yeniden kur."""
        try:
            if self.conn and not self.conn.closed:
                try:
                    self.conn.close()
                except Exception:
                    pass
        except Exception:
            pass
        try:
            self.conn = self._connect()
            logger.info("[DB] Bağlantı yeniden kuruldu.")
        except Exception as e:
            logger.error(f"[DB] Yeniden bağlantı hatası: {e}")

    def _is_conn_error(self, e: Exception) -> bool:
        """Bağlantı hatası mı?"""
        msg = str(e).lower()
        return any(k in msg for k in (
            "closed", "connection", "broken pipe",
            "server closed", "ssl", "terminating",
        ))

    def _exec(self, sql: str, params=None):
        """SQL çalıştır; bağlantı kopuksa yeniden bağlan ve 1 kez daha dene."""
        for attempt in range(2):
            try:
                with self.conn.cursor() as cur:
                    cur.execute(sql, params or ())
                    return cur
            except Exception as e:
                if attempt == 0 and self._is_conn_error(e):
                    logger.warning("[DB] Bağlantı koptu — yeniden bağlanılıyor…")
                    self._reconnect()
                    continue
                logger.error(f"DB hata: {e} | SQL: {sql[:120]}")
                try:
                    self.conn.rollback()
                except Exception:
                    pass
                return None
        return None

    def _fetchone(self, sql: str, params=None):
        """Tek satır çek; bağlantı kopuksa yeniden bağlan ve 1 kez daha dene."""
        for attempt in range(2):
            try:
                with self.conn.cursor() as cur:
                    cur.execute(sql, params or ())
                    return cur.fetchone()
            except Exception as e:
                if attempt == 0 and self._is_conn_error(e):
                    logger.warning("[DB] fetchone: bağlantı koptu — yeniden bağlanılıyor…")
                    self._reconnect()
                    continue
                logger.error(f"DB fetchone hata: {e}")
                return None
        return None

    # ─── Bot Durumu ───────────────────────────────────────────────────────────

    def set_bot_running(self, running: bool):
        self._exec(
            "UPDATE settings SET bot_running = %s WHERE id = (SELECT id FROM settings LIMIT 1)",
            (running,)
        )

    def sync_initial_balance(self, balance: float):
        self._exec(
            "UPDATE settings SET initial_balance = %s WHERE id = (SELECT id FROM settings LIMIT 1)",
            (balance,)
        )

    # ─── Bakiye Snapshot ──────────────────────────────────────────────────────

    def write_balance(
        self,
        total_balance:     float,
        available_balance: float,
        daily_pnl:         float,
        total_pnl:         float,
        mode:              str = "paper",
    ):
        self._exec(
            """INSERT INTO balances
               (total_balance, available_balance, daily_pnl, total_pnl, mode, recorded_at)
               VALUES (%s, %s, %s, %s, %s, NOW())
            """,
            (total_balance, available_balance, daily_pnl, total_pnl, mode)
        )

    # ─── İşlemler (Trades) ────────────────────────────────────────────────────

    def open_trade(
        self,
        symbol:        str,
        price:         float,
        quantity:      float,
        stop_loss:     float,
        take_profit:   float,
        strategy_name: str,
        mode:          str   = "paper",
        fee:           float = 0.0,
    ) -> Optional[int]:
        """Yeni işlem aç, DB trade_id döndür."""
        row = self._fetchone(
            """INSERT INTO trades
               (symbol, side, entry_price, quantity, stop_loss, take_profit,
                strategy_name, mode, status, commission, opened_at)
               VALUES (%s, 'buy', %s, %s, %s, %s, %s, %s, 'open', %s, NOW())
               RETURNING id
            """,
            (symbol, price, quantity, stop_loss, take_profit, strategy_name, mode, fee)
        )
        return row[0] if row else None

    def close_trade(
        self,
        trade_id:  int,
        exit_price: float,
        pnl:       float,
        pnl_pct:   float,
        reason:    str   = "",
        fee:       float = 0.0,
    ):
        """Açık işlemi kapat."""
        status = "closed"
        if reason and "stop" in reason.lower():
            status = "stopped"
        self._exec(
            """UPDATE trades
               SET exit_price = %s, pnl = %s, pnl_percent = %s,
                   status = %s, commission = commission + %s, closed_at = NOW()
               WHERE id = %s
            """,
            (exit_price, pnl, pnl_pct, status, fee, trade_id)
        )

    def get_open_trade(self, symbol: str) -> Optional[dict]:
        """
        Positions tablosunda trade_id eksik olduğunda (restart/PNL-thread yarış koşulu)
        trades tablosundan en güncel açık kaydı döndürür.
        Döndürür: {"id": int, "strategy_name": str} veya None.
        """
        row = self._fetchone(
            """SELECT id, strategy_name
               FROM trades
               WHERE symbol = %s AND status = 'open'
               ORDER BY opened_at DESC
               LIMIT 1
            """,
            (symbol,)
        )
        if row:
            return {"id": row[0], "strategy_name": row[1] or ""}
        return None

    # ─── Pozisyonlar ──────────────────────────────────────────────────────────

    def upsert_position(
        self,
        symbol:        str,
        entry_price:   float,
        current_price: float,
        quantity:      float,
        pnl:           float,
        pnl_pct:       float,
        stop_loss:     float,
        take_profit:   float,
        strategy_name: str,
        trade_id:      Optional[int],
        mode:          str = "paper",
        candles_held:  int = 0,
        side:          str = "long",
        leverage:      int = 1,
    ):
        self._exec(
            """INSERT INTO positions
               (symbol, side, entry_price, current_price, quantity, pnl, pnl_percent,
                stop_loss, take_profit, mode, strategy_name, trade_id, leverage, opened_at, updated_at)
               VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, NOW(), NOW())
               ON CONFLICT (symbol) DO UPDATE SET
                 current_price = EXCLUDED.current_price,
                 pnl           = EXCLUDED.pnl,
                 pnl_percent   = EXCLUDED.pnl_percent,
                 side          = EXCLUDED.side,
                 entry_price   = EXCLUDED.entry_price,
                 quantity      = EXCLUDED.quantity,
                 stop_loss     = EXCLUDED.stop_loss,
                 take_profit   = EXCLUDED.take_profit,
                 strategy_name = EXCLUDED.strategy_name,
                 trade_id      = EXCLUDED.trade_id,
                 leverage      = EXCLUDED.leverage,
                 mode          = EXCLUDED.mode,
                 updated_at    = NOW()
            """,
            (symbol, side, entry_price, current_price, quantity,
             pnl, pnl_pct, stop_loss, take_profit, mode, strategy_name, trade_id, leverage)
        )

    def delete_position(self, symbol: str):
        self._exec("DELETE FROM positions WHERE symbol = %s", (symbol,))

    def load_positions(self) -> list:
        """
        Positions tablosundaki tüm açık pozisyonları döndürür.
        Bot, bunları trader.positions ile karşılaştırıp sahiplenilmemiş
        pozisyonları (manuel açılanlar dahil) otomatik tanır.
        """
        try:
            with self.conn.cursor() as cur:
                cur.execute(
                    """SELECT symbol, side, entry_price, quantity,
                              stop_loss, take_profit, strategy_name, trade_id
                       FROM positions"""
                )
                rows = cur.fetchall()
            return [
                {
                    "symbol":        r[0],
                    "side":          r[1],
                    "entry_price":   float(r[2]),
                    "quantity":      float(r[3]),
                    "stop_loss":     float(r[4]) if r[4] else 0.0,
                    "take_profit":   float(r[5]) if r[5] else 0.0,
                    "strategy_name": r[6] or "",
                    "trade_id":      r[7],
                }
                for r in rows
            ]
        except Exception as e:
            logger.error(f"load_positions hata: {e}")
            return []

    # ─── Sinyaller ────────────────────────────────────────────────────────────

    def write_signal(
        self,
        symbol:         str,
        signal:         str,
        strategy_name:  str,
        price:          float,
        atr:            Optional[float] = None,
        reasons:        list            = None,
        acted:          str             = "no",
        blocked_reason: str             = "",
        mode:           str             = "paper",
    ):
        self._exec(
            """INSERT INTO signals
               (symbol, signal, strategy_name, price, atr, reasons, acted, blocked_reason, mode, created_at)
               VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, NOW())
            """,
            (symbol, signal, strategy_name, price, atr,
             json.dumps(reasons or []), acted, blocked_reason or "", mode)
        )

    # ─── Emirler ──────────────────────────────────────────────────────────────

    def write_order(
        self,
        client_order_id: str,
        symbol:          str,
        side:            str,
        order_type:      str,
        quantity:        float,
        price:           float,
        status:          str,
        filled_price:    Optional[float] = None,
        filled_qty:      Optional[float] = None,
        fee:             float           = 0.0,
        stop_loss:       Optional[float] = None,
        take_profit:     Optional[float] = None,
        strategy_name:   str             = "",
        mode:            str             = "paper",
        trade_id:        Optional[int]   = None,
    ):
        self._exec(
            """INSERT INTO orders
               (client_order_id, symbol, side, order_type, quantity, price,
                filled_price, filled_qty, fee, status, stop_loss, take_profit,
                strategy_name, mode, trade_id, created_at, filled_at)
               VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, NOW(), %s)
            """,
            (client_order_id, symbol, side, order_type, quantity, price,
             filled_price, filled_qty, fee, status, stop_loss, take_profit,
             strategy_name, mode, trade_id,
             datetime.now() if status == "filled" else None)
        )

    # ─── Risk Olayları ────────────────────────────────────────────────────────

    def write_risk_event(
        self,
        symbol:             str,
        event_type:         str,
        blocked:            bool,
        reason:             str,
        portfolio_value:    Optional[float] = None,
        open_positions:     Optional[int]   = None,
        consecutive_losses: Optional[int]   = None,
        mode:               str             = "paper",
    ):
        self._exec(
            """INSERT INTO risk_events
               (symbol, event_type, blocked, reason, portfolio_value,
                open_positions, consecutive_losses, mode, created_at)
               VALUES (%s, %s, %s, %s, %s, %s, %s, %s, NOW())
            """,
            (symbol, event_type, blocked, reason, portfolio_value,
             open_positions, consecutive_losses, mode)
        )

    # ─── Loglar ───────────────────────────────────────────────────────────────

    def write_log(
        self,
        level:    str,
        category: str,
        message:  str,
        details:  str = "",
    ):
        self._exec(
            """INSERT INTO logs (level, category, message, details, created_at)
               VALUES (%s, %s, %s, %s, NOW())
            """,
            (level, category, message, details or "")
        )

    # ─── Yardımcı ─────────────────────────────────────────────────────────────

    def ensure_positions_unique_constraint(self):
        """
        positions.symbol üzerinde unique constraint kontrol et.
        Yoksa doğrudan CREATE UNIQUE INDEX ile oluştur (IF NOT EXISTS destekli).
        """
        try:
            self._exec(
                """
                CREATE UNIQUE INDEX IF NOT EXISTS positions_symbol_key
                ON positions (symbol);
                """
            )
            logger.debug("[DB] positions.symbol unique index hazır.")
        except Exception as e:
            logger.warning(f"[DB] positions unique index oluşturulamadı: {e}")

    # ─── Market Scanner Sonuçları ─────────────────────────────────────────────

    def write_scanner_result(self, scan_result, scanner_type: str = "GENERAL") -> Optional[int]:
        """
        Tarama sonucunu scanner_runs tablosuna yaz.
        scan_result:  engine.market_scanner.ScanResult veya engine.momentum_scanner.MomentumScanResult
        scanner_type: "GENERAL" veya "MOMENTUM"
        Döndürür: eklenen satırın ID'si
        """
        try:
            shortlist_json = json.dumps([c.to_dict() for c in scan_result.shortlist])
            rejected_json  = json.dumps([c.to_dict() for c in scan_result.rejected[:30]])
            stype = getattr(scan_result, "scanner_type", scanner_type)

            row = self._fetchone(
                """
                INSERT INTO scanner_runs
                    (scanned_at, total_scanned, total_filtered, shortlist_size,
                     scan_seconds, market_regime, scanner_type, shortlist, rejected)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s::jsonb, %s::jsonb)
                RETURNING id
                """,
                (
                    scan_result.scanned_at,
                    scan_result.total_scanned,
                    scan_result.total_filtered,
                    scan_result.shortlist_size,
                    scan_result.scan_seconds,
                    scan_result.market_regime,
                    stype,
                    shortlist_json,
                    rejected_json,
                ),
            )
            if row:
                logger.debug(
                    f"[SCAN] DB'ye yazıldı: run_id={row[0]} | "
                    f"type={stype} | shortlist={scan_result.shortlist_size}"
                )
                return row[0]
        except Exception as e:
            logger.warning(f"[SCAN] DB yazma hatası: {e}")
        return None

    def get_last_scanner_run(self, scanner_type: str = "GENERAL") -> Optional[dict]:
        """Son genel veya momentum tarama sonucunu döndür."""
        try:
            row = self._fetchone(
                """
                SELECT id, scanned_at, total_scanned, total_filtered, shortlist_size,
                       scan_seconds, market_regime, scanner_type, shortlist, rejected
                FROM scanner_runs
                WHERE scanner_type = %s
                ORDER BY scanned_at DESC
                LIMIT 1
                """,
                (scanner_type,),
            )
            if not row:
                return None
            return {
                "id":             row[0],
                "scanned_at":     row[1].isoformat() if row[1] else None,
                "total_scanned":  row[2],
                "total_filtered": row[3],
                "shortlist_size": row[4],
                "scan_seconds":   row[5],
                "market_regime":  row[6],
                "scanner_type":   row[7],
                "shortlist":      row[8] or [],
                "rejected":       row[9] or [],
            }
        except Exception as e:
            logger.warning(f"[SCAN] DB okuma hatası: {e}")
            return None

    def close(self):
        try:
            self.conn.close()
            logger.info("Veritabanı bağlantısı kapatıldı.")
        except Exception:
            pass


def create_db_writer() -> Optional[DBWriter]:
    """DBWriter oluştur. DB URL yoksa None döndür."""
    dsn = os.getenv("DATABASE_URL", "")
    if not dsn:
        logger.warning("DATABASE_URL bulunamadı — DB entegrasyonu devre dışı.")
        return None
    try:
        writer = DBWriter(dsn)
        writer.ensure_positions_unique_constraint()
        return writer
    except Exception as e:
        logger.error(f"Veritabanı bağlantısı kurulamadı: {e}")
        return None
