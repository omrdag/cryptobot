"""
OKX Exchange Client Factory
============================
Mevcut OKX client'ı Railway ortamına uyarlanmış hali.
Environment variables üzerinden API credentials okur.
"""

import os
from typing import Optional
from utils.logger import get_logger

logger = get_logger()


class OKXClient:
    """
    OKX REST API client — OHLCV, ticker, pozisyon, emir.
    ccxt kütüphanesi üzerinden çalışır.
    """

    def __init__(
        self,
        api_key: str = "",
        api_secret: str = "",
        passphrase: str = "",
        sandbox: bool = False,
    ):
        try:
            import ccxt
            self._exchange = ccxt.okx({
                "apiKey":     api_key,
                "secret":     api_secret,
                "password":   passphrase,
                "sandbox":    sandbox,
                "enableRateLimit": True,
                "options": {
                    "defaultType": "swap",
                },
            })
            self._live = bool(api_key and api_secret and passphrase)
            logger.info(
                f"OKX client başlatıldı — "
                f"{'LIVE' if self._live else 'PUBLIC (veri only)'}"
            )
        except ImportError:
            logger.error("ccxt kütüphanesi bulunamadı: pip install ccxt")
            raise

    # ── Market Data ──────────────────────────────────────────────────────────

    def fetch_ohlcv(self, symbol: str, timeframe: str = "1h", limit: int = 300):
        """OHLCV mum verisi çek. symbol: 'BTC/USDT:USDT' formatında."""
        try:
            return self._exchange.fetch_ohlcv(symbol, timeframe, limit=limit)
        except Exception as e:
            logger.warning(f"[OKX] OHLCV hatası {symbol}: {e}")
            return []

    def fetch_ticker(self, symbol: str) -> Optional[dict]:
        """Anlık fiyat ticker."""
        try:
            return self._exchange.fetch_ticker(symbol)
        except Exception as e:
            logger.warning(f"[OKX] Ticker hatası {symbol}: {e}")
            return None

    def fetch_balance(self) -> dict:
        """Hesap bakiyesi."""
        if not self._live:
            return {}
        try:
            return self._exchange.fetch_balance({"type": "swap"})
        except Exception as e:
            logger.warning(f"[OKX] Bakiye hatası: {e}")
            return {}

    def fetch_positions(self) -> list:
        """Açık pozisyonlar."""
        if not self._live:
            return []
        try:
            return self._exchange.fetch_positions()
        except Exception as e:
            logger.warning(f"[OKX] Pozisyon hatası: {e}")
            return []

    def create_market_order(
        self,
        symbol: str,
        side: str,          # "buy" / "sell"
        amount: float,
        params: dict = None,
    ) -> Optional[dict]:
        """Market emri gönder."""
        if not self._live:
            logger.warning("Live mode kapalı — emir gönderilmedi")
            return None
        try:
            return self._exchange.create_market_order(
                symbol, side, amount, params=params or {}
            )
        except Exception as e:
            logger.error(f"[OKX] Emir hatası {symbol} {side}: {e}")
            return None

    def set_leverage(self, symbol: str, leverage: int, margin_mode: str = "cross") -> bool:
        """Kaldıraç ayarla."""
        if not self._live:
            return True
        try:
            self._exchange.set_leverage(leverage, symbol, {"mgnMode": margin_mode})
            return True
        except Exception as e:
            logger.warning(f"[OKX] Kaldıraç ayarlama hatası {symbol}: {e}")
            return False

    @property
    def is_live(self) -> bool:
        return self._live

    # ── Margin unsupported tracking (mevcut sistemle uyumlu) ────────────────
    _margin_unsupported: set = set()


def create_client(
    exchange: str = "okx",
    api_key: str = "",
    api_secret: str = "",
    passphrase: str = "",
) -> OKXClient:
    """
    Exchange client factory.
    Credentials env'den veya parametre olarak alınır.
    """
    exchange = exchange.lower()

    if exchange == "okx":
        key  = api_key    or os.getenv("OKX_API_KEY",    "")
        sec  = api_secret or os.getenv("OKX_API_SECRET", "")
        pwd  = passphrase or os.getenv("OKX_PASSPHRASE", "")
        return OKXClient(api_key=key, api_secret=sec, passphrase=pwd)

    raise ValueError(f"Desteklenmeyen borsa: {exchange}. Şu an sadece 'okx' destekleniyor.")
