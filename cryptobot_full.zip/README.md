# CryptoBot — OKX Pullback Trading Bot

Tam mimari: Python trading engine + FastAPI SSE + Next.js canlı dashboard. Railway üzerinde çalışır.

## Proje Yapısı

```
/
├── crypto_bot/              ← Python bot
│   ├── main.py              ← Ana döngü
│   ├── api_server.py        ← FastAPI (SSE + REST)
│   ├── config.py            ← Tüm parametreler
│   ├── schema.sql           ← PostgreSQL şeması
│   ├── requirements.txt
│   ├── .env.example
│   ├── exchange/
│   │   └── client_factory.py
│   ├── engine/
│   │   ├── risk_manager.py
│   │   ├── slot_manager.py
│   │   ├── position_sizer.py
│   │   └── execution.py
│   ├── filters/
│   │   └── market_regime.py
│   ├── strategies/
│   │   ├── pullback_long.py
│   │   ├── pullback_short.py
│   │   └── signal_scorer.py
│   ├── trader/
│   │   ├── paper_trader.py
│   │   └── exit_rules.py
│   ├── bots/
│   │   └── bot_profiles.py
│   └── utils/
│       └── logger.py
│
└── crypto_bot_dashboard/    ← Next.js dashboard
    ├── app/
    │   ├── page.tsx         ← Ana dashboard (SSE canlı)
    │   ├── settings/page.tsx← Bot kontrol paneli
    │   ├── layout.tsx
    │   └── globals.css
    ├── package.json
    ├── tailwind.config.js
    └── next.config.js
```

---

## Railway Deploy (Adım Adım)

### 1. GitHub'a Yükle

```bash
git init
git add .
git commit -m "feat: crypto bot + dashboard"
git remote add origin https://github.com/KULLANICIADIN/crypto-bot.git
git push -u origin main
```

### 2. Railway'de Proje Oluştur

1. [railway.app](https://railway.app) → **New Project**
2. **Deploy from GitHub repo** → repoyu seç

### 3. PostgreSQL Ekle

Railway Dashboard → **+ New Service** → **PostgreSQL**
`DATABASE_URL` otomatik inject edilir.

### 4. DB Schema Oluştur

```bash
# Railway CLI veya PostgreSQL bağlantı URL ile:
psql $DATABASE_URL -f crypto_bot/schema.sql
```

### 5. Bot API Servisi

Railway Dashboard → bot servisini seç:

**Settings → Build & Deploy:**
- Root Directory: `/`  (veya `crypto_bot/`)
- Build Command: `pip install -r crypto_bot/requirements.txt`
- Start Command: `cd crypto_bot && uvicorn api_server:app --host 0.0.0.0 --port $PORT`

**Environment Variables:**
```
OKX_API_KEY=xxx
OKX_API_SECRET=xxx
OKX_PASSPHRASE=xxx
DATABASE_URL=<Railway otomatik inject eder>
PAPER_TRADING=true
LEVERAGE=10
LOG_LEVEL=INFO
API_PORT=8080
```

### 6. Bot Main Loop Servisi (Ayrı servis veya aynı serviste background)

Eğer bot döngüsünü ayrı çalıştırmak istiyorsan:
- Start Command: `cd crypto_bot && python main.py`

Ya da api_server.py içinde background thread olarak başlatabilirsin (şu an ayrı).

### 7. Next.js Dashboard Servisi

Railway → **+ New Service** → **GitHub Repo** → aynı repo

**Settings:**
- Root Directory: `crypto_bot_dashboard/`
- Build Command: `npm install && npm run build`
- Start Command: `npm start`

**Environment Variables:**
```
NEXT_PUBLIC_BOT_API_URL=https://<bot-api-service>.railway.app/api
```

### 8. Domain Al

Her servis için Railway otomatik `.railway.app` domain verir.
Dashboard servisinin URL'sini tarayıcıda aç → canlı panel hazır.

---

## Lokal Geliştirme

```bash
# Terminal 1 — Python bot API
cd crypto_bot
cp .env.example .env  # Düzenle
pip install -r requirements.txt
uvicorn api_server:app --reload --port 8080

# Terminal 2 — Bot döngüsü (opsiyonel)
python main.py --once  # Tek döngü testi

# Terminal 3 — Next.js dashboard
cd crypto_bot_dashboard
cp .env.local.example .env.local
npm install
npm run dev
# → http://localhost:3000
```

---

## Paper → Live Geçiş

1. Dashboard → Settings → **Live Mod** toggle'ı aç
2. OKX API Key'lerini Railway env variables'a ekle
3. `PAPER_TRADING=false` olarak güncelle
4. Botu yeniden başlat
5. OKX hesabında **Cross Margin** ve **Swap** açık olduğunu kontrol et

---

## Önemli Notlar

- **Large Lot Modu**: Varsayılan olarak açık, min kalite A (skor ≥ 85)
- **Economic Notional**: 900$ altı fill'ler otomatik reddedilir
- **Phantom Koruması**: OKX'te olmayan DB pozisyonları atlanır
- **Cooldown**: Aynı coin 10 dk, yön flip 30 dk koruması aktif
- **Hard Cap**: Small lot max 80 iter (~3.5 saat), large lot max 160 iter (~6.5 saat)
