"""
Slot Manager — Kalite Ağırlıklı 5 Slot Pozisyon Motoru
=======================================================
5 slot tanımlar; her slot sinyal kalitesine ve piyasa rejimine göre açılır.

Sinyal Skoru → Kalite → Slot:
  skor 90+   → A+ → Slot 4-5 (325-400 USDT)
  skor 85-89 → A  → Slot 3   (250 USDT)
  skor 80-84 → B+ → Slot 2   (200 USDT)
  skor 75-79 → B  → Slot 1   (175 USDT) ← Minimum giriş eşiği
  skor 70-74 → C  → İZLEME LİSTESİ (işlem açılmaz)
  skor < 70  → REDDEDİLDİ (izleme listesinden çıkarılır)

Slot Tablosu:
  Slot 1 → 175 USDT  (B  kalite — her rejimde, skor≥75)
  Slot 2 → 200 USDT  (B+ kalite — her rejimde, skor≥80)
  Slot 3 → 250 USDT  (A  kalite — medium+ rejim, skor≥85)
  Slot 4 → 325 USDT  (A+ kalite — strong rejim, skor≥90)
  Slot 5 → 400 USDT  (A+ kalite — strong rejim, skor≥90)

Rejim → Max Aktif Slot:
  WEAK / WEAK_LIQUIDITY   → 0-1 slot
  RANGING / NEUTRAL       → 2 slot
  TRENDING_UP             → 4 slot
  BULL / STRONG           → 5 slot

Feature Flag:
  config.USE_QUALITY_WEIGHTED_SLOT_STRATEGY = True/False

Durum dosyası: /tmp/bot_slot_state.json (API server okur)
"""

import json
import os
from datetime import datetime
from typing import Optional, Dict, Tuple
from utils.logger import get_logger

logger = get_logger()

# ── Konfigürasyon (config.py'den, fallback sabit) ──────────────────────────

def _cfg(attr, default):
    try:
        import config as _c
        return getattr(_c, attr, default)
    except Exception:
        return default


# Slot tablosu sabit yapısı (B = minimum giriş kalitesi = skor≥75)
_DEFAULT_SLOTS = [
    {"id": 1, "notional": 175, "quality_min": "B",  "regime_min": "any"},    # skor 75–79
    {"id": 2, "notional": 200, "quality_min": "B+", "regime_min": "any"},    # skor 80–84
    {"id": 3, "notional": 250, "quality_min": "A",  "regime_min": "medium"}, # skor 85–89
    {"id": 4, "notional": 325, "quality_min": "A+", "regime_min": "strong"}, # skor 90+
    {"id": 5, "notional": 400, "quality_min": "A+", "regime_min": "strong"}, # skor 90+ premium
]

# C kalitesi (skor 70-74) → sadece izleme listesi, işlem açılmaz
_ENTRY_BLOCKED_QUALITIES = {"C"}
_ENTRY_MIN_SCORE = 75   # Bu skoru geçemeyen sinyaller için işlem açılmaz

_QUALITY_RANK = {"C": 1, "B": 2, "B+": 3, "A": 4, "A+": 5}

_REGIME_STRENGTH = {
    "WEAK_LIQUIDITY":  0,
    "UNKNOWN":         1,
    "HIGH_VOLATILITY": 1,
    "TRENDING_DOWN":   1,
    "RANGING":         2,
    "NEUTRAL":         2,
    "MEDIUM":          3,
    "TRENDING_UP":     4,
    "BULL":            5,
    "STRONG":          5,
    "BULLISH":         5,
}

_REGIME_STRENGTH_FOR_SLOT = {
    "any":    0,    # Her rejimde açılır
    "medium": 3,    # Strength ≥ 3 gerekli
    "strong": 4,    # Strength ≥ 4 gerekli
}

STATE_FILE = "/tmp/bot_slot_state.json"


# ══════════════════════════════════════════════════════════════════════════════
# SLOT MANAGER
# ══════════════════════════════════════════════════════════════════════════════

class SlotManager:
    """
    5-slot pozisyon yönetimi.
    assign_slot()  → coin için en uygun slotu bul ve rezerve et
    release_slot() → coin kapandığında slotu serbest bırak
    get_status()   → anlık slot tablosunu döndür
    """

    def __init__(self):
        self._slots: Dict[int, dict] = {}     # slot_id → slot config
        self._active: Dict[str, int] = {}     # symbol → slot_id
        self._last_regime: str = "UNKNOWN"
        self._enabled: bool = True
        self._reload_config()

    # ─── Konfigürasyon Yükle ──────────────────────────────────────────────

    def _reload_config(self):
        slot_cfgs = _cfg("SLOT_CONFIG", _DEFAULT_SLOTS)
        self._slots = {s["id"]: s for s in slot_cfgs}
        self._enabled = _cfg("USE_QUALITY_WEIGHTED_SLOT_STRATEGY", True)

    # ─── Sinyal Kalitesi Tespiti ──────────────────────────────────────────

    @staticmethod
    def detect_quality(
        gate_score: Optional[float],
        signal_score: Optional[float] = None,
        is_pullback: bool = True,
    ) -> str:
        """
        Gate skoru veya sinyal skorundan genişletilmiş kalite tespiti.
        Döndürür: "A+" | "A" | "B+" | "B" | "C"
        """
        bplus_score_min = _cfg("SLOT_QUALITY_BPLUS_SCORE_MIN", 80)

        if is_pullback and gate_score is not None:
            g = int(gate_score)
            if g >= 10:
                return "A+"
            if g >= 9:
                return "A"
            if g >= 8:
                # B+ için ilave skor koşulu: score varsa ≥80 gerekli
                if signal_score is not None and signal_score >= bplus_score_min:
                    return "B+"
                return "B"
            return "C"  # gate=7

        # Signal engine skoruna göre (veya fallback)
        if signal_score is not None:
            thresholds = _cfg("SLOT_QUALITY_SCORE_THRESHOLDS", {
                "A+": 90, "A": 85, "B+": 80, "B": 75, "C": 65
            })
            for q in ("A+", "A", "B+", "B", "C"):
                if signal_score >= thresholds.get(q, 999):
                    return q

        return "B"  # Varsayılan

    # ─── Rejim Gücü ───────────────────────────────────────────────────────

    @staticmethod
    def _regime_strength(regime_str: str) -> int:
        """Rejim adını 0-5 güç skoruna çevirir."""
        r = (regime_str or "UNKNOWN").upper().replace(" ", "_")
        return _REGIME_STRENGTH.get(r, 2)

    def _max_active_slots(self, regime_str: str) -> int:
        """Bu rejimde aynı anda kaç slot aktif olabilir?"""
        regime_map = _cfg("SLOT_REGIME_MAX_ACTIVE", {})
        r = (regime_str or "UNKNOWN").upper().replace(" ", "_")
        if r in regime_map:
            return int(regime_map[r])
        # Güç skoruna göre interpolasyon
        strength = self._regime_strength(r)
        if strength <= 0: return 0
        if strength <= 1: return 1
        if strength <= 2: return 2
        if strength <= 3: return 3
        if strength <= 4: return 4
        return 5

    # ─── Slot Atama ───────────────────────────────────────────────────────

    def assign_slot(
        self,
        symbol: str,
        quality: str,
        regime: str,
        available_balance: float = 0.0,
    ) -> Optional[Tuple[int, float, str]]:
        """
        Coin için en uygun slotu bul ve rezerve et.

        Returns:
          (slot_id, notional_usdt, reason_str) — başarılı
          None                                  — slot yok / engellendi
        """
        if not self._enabled:
            return None  # Feature flag kapalı → eski sistem kullanılır

        self._last_regime = regime

        # ── Minimum Kalite Kapısı ──────────────────────────────────────────────
        # C kalitesi (skor 70-74) = sadece izleme listesi, işlem açılmaz
        entry_blocked = _cfg("SLOT_ENTRY_BLOCKED_QUALITIES", list(_ENTRY_BLOCKED_QUALITIES))
        if quality in entry_blocked:
            logger.info(
                f"[SLOT] {symbol} GİRİŞ ENGELLENDI: "
                f"Kalite={quality} (skor 70-74 → sadece izleme). "
                f"Min giriş kalitesi: B (skor≥75)"
            )
            self._write_state()
            return None

        max_slots = self._max_active_slots(regime)
        active_count = len(self._active)

        # ── WEAK_LIQUIDITY ek kalite kapısı ───────────────────────────────────
        # Bu rejimde 1 slota izin var ama minimum B+ kalite gerekir
        regime_upper = (regime or "").upper().replace(" ", "_")
        if regime_upper == "WEAK_LIQUIDITY" and max_slots >= 1:
            weak_min = _cfg("SLOT_WEAK_LIQUIDITY_MIN_QUALITY", "B+")
            quality_rank = _QUALITY_RANK.get(quality, 0)
            weak_min_rank = _QUALITY_RANK.get(weak_min, 3)
            if quality_rank < weak_min_rank:
                logger.info(
                    f"[SLOT] {symbol} REDDEDİLDİ: "
                    f"WEAK_LIQUIDITY rejiminde min kalite {weak_min} gerekli "
                    f"(mevcut: {quality})"
                )
                self._write_state()
                return None

        # Zaten slota sahip mi?
        if symbol in self._active:
            existing_id = self._active[symbol]
            existing_slot = self._slots.get(existing_id, {})
            return (existing_id, existing_slot.get("notional", 100), "zaten açık slot")

        # Rejim izin veriyor mu?
        if active_count >= max_slots:
            reason = (
                f"Rejim '{regime}' → max {max_slots} slot "
                f"(aktif: {active_count}) — yeni slot yok"
            )
            logger.info(f"[SLOT] {symbol} REDDEDİLDİ: {reason}")
            self._write_state()
            return None

        # Rezerv marjin kontrolü (kaldıraç-bilinçli)
        # Gerçek marjin = notional / kaldıraç; notional'ın tamamı bakiyeden ÇIKMAZ.
        reserve = _cfg("SLOT_RESERVE_USDT", 100.0)
        if available_balance > 0:
            leverage = max(_cfg("LEVERAGE", 10), 1)
            total_margin_used = sum(
                self._slots[sid]["notional"] / leverage
                for sid in self._active.values()
                if sid in self._slots
            )
            if available_balance - total_margin_used <= reserve:
                reason = (
                    f"Rezerv koruma: bakiye ${available_balance:.0f} − "
                    f"marjin ${total_margin_used:.0f} ≤ rezerv ${reserve:.0f}"
                )
                logger.info(f"[SLOT] {symbol} REDDEDİLDİ: {reason}")
                self._write_state()
                return None

        # Kullanılabilir slot bul (en yüksek uyanik slottan başla)
        quality_rank = _QUALITY_RANK.get(quality, 2)
        regime_strength = self._regime_strength(regime)
        used_ids = set(self._active.values())

        best_slot = None
        # Kaliteye uyan en yüksek ID'li boş slotu seç
        for slot_id in sorted(self._slots.keys(), reverse=True):
            slot = self._slots[slot_id]
            if slot_id in used_ids:
                continue  # Bu slot zaten kullanılıyor
            slot_quality_rank = _QUALITY_RANK.get(slot["quality_min"], 1)
            slot_regime_min   = _REGIME_STRENGTH_FOR_SLOT.get(slot["regime_min"], 0)
            if quality_rank >= slot_quality_rank and regime_strength >= slot_regime_min:
                best_slot = slot
                break

        if best_slot is None:
            reason = (
                f"Uygun slot bulunamadı — kalite={quality} "
                f"rejim={regime} (güç={regime_strength})"
            )
            logger.info(f"[SLOT] {symbol} REDDEDİLDİ: {reason}")
            self._write_state()
            return None

        # Rezerve et
        self._active[symbol] = best_slot["id"]
        notional = best_slot["notional"]

        logger.info(
            f"[SLOT] {symbol} → Slot {best_slot['id']} | "
            f"{notional:.0f} USDT | Kalite: {quality} | Rejim: {regime} "
            f"(aktif: {active_count+1}/{max_slots})"
        )
        self._write_state()
        return (best_slot["id"], notional, f"slot {best_slot['id']} atandı")

    def release_slot(self, symbol: str) -> None:
        """Sembol kapandığında slotu serbest bırak."""
        slot_id = self._active.pop(symbol, None)
        if slot_id is not None:
            notional = self._slots.get(slot_id, {}).get("notional", 0)
            logger.info(
                f"[SLOT] {symbol} → Slot {slot_id} serbest bırakıldı "
                f"(${notional:.0f} USDT)"
            )
        self._write_state()

    # ─── Durum ────────────────────────────────────────────────────────────

    def get_status(self, regime: str = None) -> dict:
        """Anlık slot tablosunu döndür."""
        if regime:
            self._last_regime = regime
        r = self._last_regime
        max_slots = self._max_active_slots(r)
        active_count = len(self._active)

        # Symbol → slot_id ters haritası
        sym_to_slot = {v: k for k, v in self._active.items()}

        slots_status = []
        for slot_id in sorted(self._slots.keys()):
            slot = self._slots[slot_id]
            symbol = sym_to_slot.get(slot_id)
            slots_status.append({
                "id":         slot_id,
                "notional":   slot["notional"],
                "quality_min":slot["quality_min"],
                "regime_min": slot["regime_min"],
                "occupied":   symbol is not None,
                "symbol":     symbol,
                "enabled":    slot_id <= max_slots,
            })

        reserve = _cfg("SLOT_RESERVE_USDT", 200.0)
        total_notional = sum(
            self._slots[sid]["notional"]
            for sid in self._active.values()
            if sid in self._slots
        )

        return {
            "feature_enabled": self._enabled,
            "regime":          r,
            "max_active_slots": max_slots,
            "active_slots":    active_count,
            "reserve_usdt":    reserve,
            "used_notional":   total_notional,
            "slots":           slots_status,
            "active_map":      dict(self._active),
        }

    # ─── Durum Dosyası ─────────────────────────────────────────────────────

    def _write_state(self) -> None:
        """Slot durumunu JSON dosyasına yaz (API server okur)."""
        try:
            state = self.get_status()
            state["updated_at"] = datetime.utcnow().isoformat()
            # camelCase alanlar → TypeScript SlotState interface ile uyumlu
            state["featureActive"]         = state.get("feature_enabled", False)
            state["activeCount"]           = state.get("active_slots", 0)
            state["maxActive"]             = state.get("max_active_slots", 0)
            state["availableCount"]        = max(0, state.get("max_active_slots", 0) - state.get("active_slots", 0))
            state["lastUpdated"]           = state["updated_at"]
            state["forceMaxSlotTestMode"]  = _cfg("FORCE_MAX_SLOT_TEST_MODE", False)
            # slot kartları için alan dönüşümü
            for s in state.get("slots", []):
                s["slot_id"]    = s.get("id")
                s["min_quality"] = s.get("quality_min")
            with open(STATE_FILE, "w") as f:
                json.dump(state, f, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.debug(f"[SLOT] Durum dosyası yazılamadı: {e}")

    @classmethod
    def read_state_file(cls) -> Optional[dict]:
        """Durum dosyasını oku (API/dışarıdan kullanım)."""
        try:
            if os.path.exists(STATE_FILE):
                with open(STATE_FILE) as f:
                    return json.load(f)
        except Exception:
            pass
        return None
