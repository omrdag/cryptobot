"""
Execution Engine — Emir Yönetim Motoru
=======================================
Strateji sinyallerini gerçek (veya kağıt) emirlere dönüştürür.
Emir yaşam döngüsünü yönetir: pending → filled / cancelled / rejected.

Özellikler:
  - Duplicate order koruması (aynı sembol için bekleyen emir varsa geç)
  - Benzersiz client_order_id üretimi
  - Paper trading entegrasyonu
  - Gelecekte live trading için hazır altyapı

Kullanım:
    exe = ExecutionEngine(paper_trader=trader, live_mode=False)
    order = exe.submit_buy(symbol, price, sizing_result, strategy_name)
    exe.submit_sell(symbol, price, reason="SELL sinyali")
"""

import uuid
from typing import Optional, Dict
from datetime import datetime
from utils.logger import get_logger

logger = get_logger()

# Cross-margin desteklemeyen sembollerin runtime kara listesi
# (OKX "Margin trading is not supported" hatası aldığında doldurulur)
_margin_unsupported: set = set()


class Order:
    """Emir kaydı."""

    STATUS_PENDING   = "pending"
    STATUS_FILLED    = "filled"
    STATUS_CANCELLED = "cancelled"
    STATUS_REJECTED  = "rejected"

    def __init__(
        self,
        client_order_id: str,
        symbol: str,
        side: str,       # "BUY" / "SELL"
        order_type: str, # "market" / "limit"
        quantity: float,
        price: float,
        stop_loss: float   = 0.0,
        take_profit: float = 0.0,
        strategy_name: str = "",
        mode: str          = "paper",
    ):
        self.client_order_id = client_order_id
        self.symbol          = symbol
        self.side            = side
        self.order_type      = order_type
        self.quantity        = quantity
        self.price           = price
        self.stop_loss       = stop_loss
        self.take_profit     = take_profit
        self.strategy_name   = strategy_name
        self.mode            = mode
        self.status          = self.STATUS_PENDING
        self.filled_qty      = 0.0
        self.filled_price    = 0.0
        self.fee             = 0.0
        self.created_at      = datetime.now()
        self.filled_at: Optional[datetime] = None
        self.exchange_order_id: str = ""

    def fill(self, filled_price: float, filled_qty: float, fee: float = 0.0):
        """Emri doldur."""
        self.status       = self.STATUS_FILLED
        self.filled_price = filled_price
        self.filled_qty   = filled_qty
        self.fee          = fee
        self.filled_at    = datetime.now()

    def reject(self, reason: str = ""):
        """Emri reddet."""
        self.status = self.STATUS_REJECTED
        logger.warning(f"Emir reddedildi [{self.client_order_id}]: {reason}")

    def cancel(self):
        """Emri iptal et."""
        self.status = self.STATUS_CANCELLED

    def to_dict(self) -> dict:
        return {
            "client_order_id": self.client_order_id,
            "symbol":          self.symbol,
            "side":            self.side,
            "order_type":      self.order_type,
            "quantity":        self.quantity,
            "price":           self.price,
            "stop_loss":       self.stop_loss,
            "take_profit":     self.take_profit,
            "strategy_name":   self.strategy_name,
            "mode":            self.mode,
            "status":          self.status,
            "filled_qty":      self.filled_qty,
            "filled_price":    self.filled_price,
            "fee":             self.fee,
            "created_at":      self.created_at.isoformat(),
            "filled_at":       self.filled_at.isoformat() if self.filled_at else None,
        }

    def __repr__(self):
        return (
            f"<Order {self.side} {self.symbol} "
            f"qty={self.quantity:.6f} @ ${self.price:,.4f} "
            f"[{self.status}]>"
        )


class ExecutionEngine:
    """
    Emir yönetim motoru.
    Paper ve live trading için ortak arayüz sağlar.
    """

    def __init__(self, paper_trader=None, live_mode: bool = False, leverage: float = 1.0):
        self.paper_trader = paper_trader
        self.live_mode    = live_mode  # False = paper trading (güvenli)
        self.leverage     = max(1.0, leverage)   # Fallback hesaplaması için

        # Emir takibi
        self._orders: Dict[str, Order]         = {}   # client_order_id → Order
        self._pending: Dict[str, str]          = {}   # symbol → client_order_id
        self._order_history: list              = []

    # ─── Alış Emri ────────────────────────────────────────────────────────────

    def submit_buy(
        self,
        symbol: str,
        price: float,
        sizing: dict,               # PositionSizer.calculate() sonucu
        strategy_name: str = "",
    ) -> Optional[Order]:
        """
        Alış emri gönder.
        Returns: Order nesnesi (başarılıysa), None (başarısızsa)
        """
        # Cross-margin kara liste kontrolü (hem yerel hem OKX client listesi)
        _live_client = getattr(self, "_live_client", None)
        _client_blacklist = getattr(_live_client, "_margin_unsupported", set())
        if symbol in _margin_unsupported or symbol in _client_blacklist:
            logger.debug(f"[EXEC] {symbol} atlandı — margin desteklemiyor (kara listede)")
            return None

        # Duplicate kontrolü
        if self._has_pending(symbol):
            logger.warning(f"{symbol}: Bekleyen emir var, yeni emir atlandı")
            return None

        order_id = self._new_order_id()
        order = Order(
            client_order_id = order_id,
            symbol          = symbol,
            side            = "BUY",
            order_type      = "market",
            quantity        = sizing["quantity"],
            price           = price,
            stop_loss       = sizing.get("stop_loss", 0),
            take_profit     = sizing.get("take_profit", 0),
            strategy_name   = strategy_name,
            mode            = "live" if self.live_mode else "paper",
        )

        self._orders[order_id] = order
        self._pending[symbol]  = order_id

        # Çalıştır
        if self.live_mode:
            success = self._execute_live_buy(order)
        else:
            success = self._execute_paper_buy(order)

        if success:
            del self._pending[symbol]
        else:
            order.reject("Emir çalıştırılamadı")
            del self._pending[symbol]

        self._order_history.append(order)
        return order if order.status == Order.STATUS_FILLED else None

    # ─── Short Açma Emri ──────────────────────────────────────────────────────

    def submit_short(
        self,
        symbol: str,
        price: float,
        sizing: dict,
        strategy_name: str = "",
    ) -> Optional[Order]:
        """
        SHORT pozisyon emri gönder.
        Returns: Order nesnesi (başarılıysa), None (başarısızsa)
        """
        if self._has_pending(symbol):
            logger.warning(f"{symbol}: Bekleyen emir var, short atlandı")
            return None

        order_id = self._new_order_id()
        order = Order(
            client_order_id = order_id,
            symbol          = symbol,
            side            = "SHORT",
            order_type      = "market",
            quantity        = sizing["quantity"],
            price           = price,
            stop_loss       = sizing.get("stop_loss", 0),
            take_profit     = sizing.get("take_profit", 0),
            strategy_name   = strategy_name,
            mode            = "live" if self.live_mode else "paper",
        )

        self._orders[order_id] = order
        self._pending[symbol]  = order_id

        # Live modda OKX'e gerçek SELL emri gönder; paper modda kağıt trader
        if self.live_mode:
            success = self._execute_live_short(order)
        else:
            success = self._execute_paper_short(order)

        if success:
            del self._pending[symbol]
        else:
            order.reject("Short emri çalıştırılamadı")
            del self._pending[symbol]

        self._order_history.append(order)
        return order if order.status == Order.STATUS_FILLED else None

    # ─── Satış Emri ───────────────────────────────────────────────────────────

    def submit_sell(
        self,
        symbol: str,
        price: float,
        reason: str        = "SELL sinyali",
        strategy_name: str = "",
    ) -> Optional[Order]:
        """
        Satış emri gönder (mevcut pozisyonu kapat).
        Returns: Order nesnesi (başarılıysa), None (başarısızsa)
        """
        if self.paper_trader and symbol not in self.paper_trader.positions:
            logger.warning(f"{symbol}: Kapatılacak pozisyon yok")
            return None

        pos = self.paper_trader.positions.get(symbol) if self.paper_trader else None
        quantity = pos.quantity if pos else 0

        order_id = self._new_order_id()
        order = Order(
            client_order_id = order_id,
            symbol          = symbol,
            side            = "SELL",
            order_type      = "market",
            quantity        = quantity,
            price           = price,
            strategy_name   = strategy_name,
            mode            = "live" if self.live_mode else "paper",
        )

        self._orders[order_id] = order

        if self.live_mode:
            success = self._execute_live_sell(order)
        else:
            success = self._execute_paper_sell(order, reason)

        self._order_history.append(order)
        return order if order.status == Order.STATUS_FILLED else None

    def submit_short_close(
        self,
        symbol: str,
        price: float,
        reason: str        = "BUY sinyal ile short kapatıldı",
        strategy_name: str = "",
    ) -> Optional[Order]:
        """
        SHORT pozisyon kapatma emri gönder.
        Live modda: side=buy, pos_side=short (hedge mod — doğru path)
        Paper modda: paper_trader.close_position() (side'ı bilir)
        Returns: Order nesnesi (başarılıysa), None (başarısızsa)
        """
        if self.paper_trader and symbol not in self.paper_trader.positions:
            logger.warning(f"{symbol}: Kapatılacak SHORT pozisyon yok")
            return None

        pos      = self.paper_trader.positions.get(symbol) if self.paper_trader else None
        quantity = pos.quantity if pos else 0

        order_id = self._new_order_id()
        order = Order(
            client_order_id = order_id,
            symbol          = symbol,
            side            = "BUY",          # SHORT kapatmak = BUY yönünde emir
            order_type      = "market",
            quantity        = quantity,
            price           = price,
            strategy_name   = strategy_name,
            mode            = "live" if self.live_mode else "paper",
        )

        self._orders[order_id] = order

        if self.live_mode:
            # Ayrı path: side=buy, pos_side=short → hedge modda short kapatır
            success = self._execute_live_short_close(order)
        else:
            # Paper modda paper_trader.close_position() doğru çalışır (side'ı bilir)
            success = self._execute_paper_sell(order, reason)

        if not success:
            order.reject("Short kapatma emri çalıştırılamadı")

        self._order_history.append(order)
        return order if order.status == Order.STATUS_FILLED else None

    # OKX tarafından "pozisyon yok" kesin onayı alınan semboller (phantom)
    _confirmed_phantom_symbols: set = set()

    def submit_force_close(
        self,
        symbol:        str,
        side:          str,    # "long" veya "short" — kapanacak pozisyonun yönü
        quantity:      float,
        price:         float,
        reason:        str   = "force_close",
        strategy_name: str   = "",
    ) -> bool:
        """
        Pozisyon paper_trader'da yoksa bile OKX'e kapatma emri gönder.
        check_exits() tarafından zaten kaldırılmış live pozisyonlar için kullanılır.

        OKX /trade/close-position endpoint'ini kullanır — hedge modda
        posSide belirtmek gerekir (long → "long", short → "short").

        Returns: True if OKX order was sent successfully.
        Side-effect: self._confirmed_phantom_symbols'a ekler eğer OKX 51023/51169 döndürürse.
        """
        if not self.live_mode:
            return False

        # Önceki phantom kaydını temizle
        self._confirmed_phantom_symbols.discard(symbol)

        logger.info(
            f"[FORCE CLOSE] {symbol} {'LONG' if side == 'long' else 'SHORT'} kapatılıyor "
            f"qty={quantity:.6f} @ ~${price:.4f} | Neden: {reason}"
        )

        client = getattr(self, "_live_client", None)
        if not client or not client.is_authenticated():
            logger.error("[FORCE CLOSE] Live client yok veya kimlik doğrulanmamış!")
            return False

        pos_side  = "long" if side == "long" else "short"
        close_fn  = getattr(client, "close_position", None)
        swap_fn   = getattr(client, "place_swap_order", None)

        # OKX "pozisyon yok" hata kodları — kesin phantom onayı
        PHANTOM_CODES = {"51023", "51169"}

        def _is_phantom_error(client_obj) -> bool:
            code = str(getattr(client_obj, "_last_close_error_code", ""))
            return code in PHANTOM_CODES

        # ── Deneme 1: /trade/close-position (en güvenilir, hedge mode uyumlu) ──
        if close_fn:
            result = close_fn(symbol=symbol, pos_side=pos_side)
            if result is not None:
                logger.info(f"[FORCE CLOSE] {symbol} {pos_side.upper()} başarıyla kapatıldı (close-position)")
                return True
            # Phantom mı? İlk denemede bile 51023 geldiyse direkt phantom say
            if _is_phantom_error(client):
                logger.warning(
                    f"[FORCE CLOSE] {symbol}: OKX 'Position doesn't exist' dedi (1. deneme) — phantom olarak işaretleniyor"
                )
                self._confirmed_phantom_symbols.add(symbol)
                return False
            # İlk deneme başarısız — 1 saniye bekle, tekrar dene
            import time as _time
            _time.sleep(1)
            logger.warning(f"[FORCE CLOSE] {symbol} ilk close-position başarısız, yeniden deneniyor…")
            result = close_fn(symbol=symbol, pos_side=pos_side)
            if result is not None:
                logger.info(f"[FORCE CLOSE] {symbol} {pos_side.upper()} 2. denemede kapatıldı")
                return True
            if _is_phantom_error(client):
                logger.warning(
                    f"[FORCE CLOSE] {symbol}: OKX 'Position doesn't exist' dedi (2. deneme) — phantom olarak işaretleniyor"
                )
                self._confirmed_phantom_symbols.add(symbol)
                return False
            logger.error(f"[FORCE CLOSE] {symbol} close-position iki kez başarısız, swap order fallback deneniyor…")

        # ── Deneme 2: place_swap_order ile market kapatma (fallback) ──────────
        if swap_fn:
            cover_side = "sell" if side == "long" else "buy"
            order_id   = self._new_order_id()
            res = swap_fn(
                symbol          = symbol,
                side            = cover_side,
                pos_side        = pos_side,
                coin_quantity   = quantity,
                order_type      = "market",
                client_order_id = order_id,
            )
            success = res is not None and res.get("status") in ("filled", "live", "partially_filled")
            if success:
                logger.info(f"[FORCE CLOSE] {symbol} {pos_side.upper()} swap-order fallback ile kapatıldı")
            else:
                # 51169 = "you don't have any positions in this direction" → kesin phantom
                swap_scode = str((res or {}).get("sCode", "")) if res else ""
                if swap_scode == "51169" or (res is None):
                    # res=None veya swap emri de reddedildiyse OKX'te gerçekten yok
                    self._confirmed_phantom_symbols.add(symbol)
                    logger.warning(
                        f"[FORCE CLOSE] {symbol}: Swap fallback da 'pozisyon yok' döndürdü — phantom olarak işaretleniyor"
                    )
                logger.error(f"[FORCE CLOSE] {symbol} {pos_side.upper()} TÜM KAPATMA DENEMELERİ BAŞARISIZ!")
            return success

        logger.error(f"[FORCE CLOSE] {symbol}: Ne close_position ne de place_swap_order mevcut!")
        return False

    # ─── Paper Trading Çalıştırma ─────────────────────────────────────────────

    def _execute_paper_buy(self, order: Order) -> bool:
        """Kağıt alış emrini çalıştır."""
        if not self.paper_trader:
            logger.error("Paper trader tanımlanmamış!")
            return False

        opened = self.paper_trader.open_position(
            symbol      = order.symbol,
            price       = order.price,
            stop_loss   = order.stop_loss,
            take_profit = order.take_profit,
        )

        if opened:
            pos = self.paper_trader.positions.get(order.symbol)
            order.fill(
                filled_price = order.price,
                filled_qty   = pos.quantity if pos else order.quantity,
                fee          = (order.quantity * order.price) * 0.001,
            )
            return True
        return False

    def _execute_paper_sell(self, order: Order, reason: str) -> bool:
        """Kağıt satış emrini çalıştır."""
        if not self.paper_trader:
            return False

        pnl = self.paper_trader.close_position(order.symbol, order.price, reason)
        if pnl is not None:
            order.fill(
                filled_price = order.price,
                filled_qty   = order.quantity,
                fee          = (order.quantity * order.price) * 0.001,
            )
            return True
        return False

    def _execute_paper_short(self, order: Order) -> bool:
        """Kağıt SHORT emrini çalıştır."""
        if not self.paper_trader:
            logger.error("Paper trader tanımlanmamış!")
            return False

        opened = self.paper_trader.open_short_position(
            symbol            = order.symbol,
            price             = order.price,
            stop_loss         = order.stop_loss,
            take_profit       = order.take_profit,
            strategy_name     = order.strategy_name,
            quantity_override = order.quantity,
        )

        if opened:
            pos = self.paper_trader.positions.get(order.symbol)
            order.fill(
                filled_price = order.price,
                filled_qty   = pos.quantity if pos else order.quantity,
                fee          = (order.quantity * order.price) * 0.001,
            )
            return True
        return False

    # ─── Live Trading Modunu Güncelle ────────────────────────────────────────

    def update_live_mode(self, live_mode: bool, client=None):
        """
        Trading modunu çalışma anında güncelle.
        Kullanıcı UI'dan paper↔live geçiş yaptığında çağrılır.
        """
        self.live_mode = live_mode
        if live_mode and client:
            self._live_client = client
            logger.info(f"ExecutionEngine LIVE moda geçirildi — OKX bağlantısı aktif")
        elif not live_mode:
            self._live_client = None
            logger.info("ExecutionEngine PAPER moda geçirildi")

    # ─── Live Trading ────────────────────────────────────────────────────────

    def set_live_client(self, client):
        """
        Gerçek borsa bağlayıcısını ata (live trading için).
        client: OKXLiveClient veya ExchangeConnector türevi
        """
        self._live_client = client
        logger.info(f"Live trading istemcisi ayarlandı: {client.__class__.__name__}")

    def _place_live_order(
        self, symbol: str, side: str, quantity: float, client_order_id: str
    ) -> Optional[dict]:
        """
        OKX'e emir gönder.
        BUY  → SWAP LONG aç  (place_swap_order side=buy  pos_side=long)
        SELL → SWAP LONG kapat (place_swap_order side=sell pos_side=long)
        Her iki taraf da aynı kontrat türünü (SWAP) kullanır — asimetri yok.
        SWAP başarısız olursa SPOT cross-margin'e fallback yapılır.
        """
        client = getattr(self, "_live_client", None)
        if not client or not client.is_authenticated():
            logger.error("Live client yok veya kimlik doğrulanmamış!")
            return None

        # Minimum notional kontrolü — OKX yaklaşık $5 altını reddeder
        MIN_NOTIONAL_USD = 5.0
        price = 0.0
        if hasattr(client, "get_ticker"):
            ticker = client.get_ticker(symbol)
            price = float((ticker or {}).get("last", (ticker or {}).get("last_price", 0.0)))
        elif hasattr(client, "get_last_price"):
            price = float(client.get_last_price(symbol) or 0.0)
        if price > 0:
            notional = quantity * price
            if notional < MIN_NOTIONAL_USD:
                logger.warning(
                    f"[EXEC] Emir atlandı — notional ${notional:.2f} < ${MIN_NOTIONAL_USD} minimum "
                    f"| {side.upper()} {quantity:.6f} {symbol} @ ${price:.2f} | "
                    f"Hesaba daha fazla USDT yatırın."
                )
                return None

        # Hesap SWAP destekliyor mu? acctLv>=2 gerekir.
        swap_supported = getattr(client, "supports_swap", True)
        swap_fn = getattr(client, "place_swap_order", None)

        # ── SELL: Açık LONG pozisyonu kapat (pos_side=long, side=sell) ──────
        if side.lower() == "sell":
            if not swap_supported:
                logger.warning(
                    f"[EXEC] SWAP LONG-KAPAT atlandı ({symbol}) — "
                    f"OKX hesabı Simple Account (acctLv=1), vadeli işlem desteklenmiyor."
                )
                return None

            if swap_fn:
                result = swap_fn(
                    symbol          = symbol,
                    side            = "sell",
                    pos_side        = "long",   # LONG pozisyonu kapat
                    coin_quantity   = quantity,
                    order_type      = "market",
                    client_order_id = client_order_id,
                )
                if result:
                    logger.info(f"[EXEC] SWAP LONG kapatma emri kabul edildi: {quantity:.6f} {symbol}")
                else:
                    logger.warning(
                        f"[EXEC] SWAP LONG kapatma reddedildi ({symbol}) — "
                        f"OKX'te açık SWAP LONG pozisyon var mı kontrol edin."
                    )
                return result

            # SWAP metodu yoksa (paper trader), spot cross dene
            result = client.place_order(
                symbol          = symbol,
                side            = side,
                order_type      = "market",
                quantity        = quantity,
                client_order_id = client_order_id,
                td_mode         = "cross",
            )
            return result

        # ── BUY: SWAP LONG aç (pos_side=long, side=buy) ──────────────────────
        if swap_supported and swap_fn:
            # order.quantity = margin_usdt / price  (marjin bazlı coin miktarı)
            # SWAP için notional gerekli: margin × kaldıraç / price = quantity × leverage
            swap_coin_qty = quantity * max(self.leverage, 1.0)
            logger.debug(
                f"[EXEC] SWAP BUY {symbol}: marjin_qty={quantity:.4f} "
                f"× kaldıraç={self.leverage:.0f}x → notional_qty={swap_coin_qty:.4f} coin"
            )

            # ── Minimum Contract Viability Check ───────────────────────────────
            # OKX her sembol için minSz (minimum kontrat sayısı) ve ctVal
            # (1 kontrattaki coin adedi) tanımlar. Slot notional bu eşiği
            # karşılamıyorsa emir OKX tarafından reddedilir; biz önceden
            # reddediyoruz ve dashboard için nedeni kaydediyoruz.
            if hasattr(client, "_get_swap_specs") and hasattr(client, "_inst_id"):
                _inst_spot = client._inst_id(symbol)
                if _inst_spot:
                    _swap_inst_id = f"{_inst_spot}-SWAP"
                    _specs        = client._get_swap_specs(_swap_inst_id)
                    _ct_val       = _specs.get("ct_val", 1.0)
                    _min_sz       = _specs.get("min_sz", 1)
                    _n_contracts  = swap_coin_qty / _ct_val if _ct_val > 0 else 0
                    if _n_contracts < _min_sz:
                        _slot_notional_usd = round(swap_coin_qty * price, 2) if price > 0 else 0
                        logger.warning(
                            f"[CONTRACT-CHECK] ❌ {symbol} REDDEDİLDİ — "
                            f"slot notional ${_slot_notional_usd} ({self.leverage:.0f}x kaldıraç) → "
                            f"{swap_coin_qty:.2f} coin → {_n_contracts:.2f} kontrat "
                            f"(minimum: {_min_sz} kontrat, ctVal={_ct_val}). "
                            f"Bu slot bu sembol için çok küçük."
                        )
                        # Dashboard için reddetme nedenini /tmp dosyasına kaydet
                        try:
                            import json as _json, os as _os, time as _time
                            _rej_file = "/tmp/bot_min_contract_rejected.json"
                            _existing: dict = {}
                            if _os.path.exists(_rej_file):
                                with open(_rej_file) as _f:
                                    _existing = _json.load(_f)
                            _existing[symbol] = {
                                "reason": "MIN_CONTRACT",
                                "contracts": round(_n_contracts, 3),
                                "min_required": _min_sz,
                                "ct_val": _ct_val,
                                "swap_qty": round(swap_coin_qty, 2),
                                "slot_notional_usd": _slot_notional_usd,
                                "ts": _time.time(),
                            }
                            with open(_rej_file, "w") as _f:
                                _json.dump(_existing, _f)
                        except Exception:
                            pass
                        return None
            # ──────────────────────────────────────────────────────────────────

            result = swap_fn(
                symbol          = symbol,
                side            = "buy",
                pos_side        = "long",   # LONG pozisyon aç
                coin_quantity   = swap_coin_qty,
                order_type      = "market",
                client_order_id = client_order_id,
            )
            if result:
                logger.info(f"[EXEC] SWAP LONG açma emri kabul edildi: {swap_coin_qty:.4f} coin ({symbol})")
                return result
            logger.error(
                f"[EXEC] SWAP BUY başarısız ({symbol}) — kontrat boyutu yetersiz veya OKX hatası. "
                f"Emir atıldı. (swap_coin_qty={swap_coin_qty:.4f}, kaldıraç={self.leverage:.0f}x)"
            )
            return None

        # --- SPOT fallback KALDIRILDI ---
        # SPOT üzerinden açılan pozisyonlar _sync_okx_positions_to_db tarafından
        # görünmez (SWAP sync sadece instType=SWAP okur) → dashboard titremesine yol açar.
        # SWAP başarısız olduğunda emir atılır, bir sonraki döngüde tekrar denenir.
        logger.error(f"[EXEC] SWAP BUY atıldı ({symbol}) — SWAP desteği yok veya client hatalı.")
        return None

        # --- Eski fallback kodu (devre dışı) ---
        if False:
            result = client.place_order(
                symbol          = symbol,
                side            = side,
                order_type      = "market",
                quantity        = quantity,
                client_order_id = client_order_id,
                td_mode         = "cross",
            )
            if result:
                logger.info(f"[EXEC] SPOT cross-margin BUY kabul edildi: {quantity:.6f} {symbol}")
                return result
        if False and self.leverage > 1.0:
            spot_qty = quantity / self.leverage
            logger.info(
                f"[EXEC] cross-margin başarısız → cash/spot fallback | "
                f"miktar: {quantity:.6f} → {spot_qty:.6f} (÷{self.leverage:.0f}x)"
            )
            import uuid as _uuid
            fallback_id = f"BOT{_uuid.uuid4().hex[:12].upper()}"
            result = client.place_order(
                symbol          = symbol,
                side            = side,
                order_type      = "market",
                quantity        = spot_qty,
                client_order_id = fallback_id,
                td_mode         = "cash",
            )
            if result:
                logger.info(f"[EXEC] cash/spot fallback başarılı: BUY {spot_qty:.6f} {symbol}")
            return result
        return None

    def _execute_live_buy(self, order: Order) -> bool:
        """Gerçek alış emri — OKXLiveClient ile gönder."""
        result = self._place_live_order(
            symbol           = order.symbol,
            side             = "buy",
            quantity         = order.quantity,
            client_order_id  = order.client_order_id,
        )

        if result and result.get("status") in ("filled", "live", "partially_filled"):
            # Fiyat sıfır gelirse order.price'ı kullan (OKX zaman zaman 0 döner)
            filled_price = result.get("filled_price") or order.price
            filled_qty   = result.get("filled_qty",   order.quantity)
            order.fill(
                filled_price = filled_price,
                filled_qty   = filled_qty,
                fee          = result.get("fee", 0.0),
            )
            order.exchange_order_id = result.get("order_id", "")
            # Paper trader'ı senkronize et (PnL takibi için)
            if self.paper_trader:
                self.paper_trader.open_position(
                    symbol            = order.symbol,
                    price             = filled_price,
                    stop_loss         = order.stop_loss,
                    take_profit       = order.take_profit,
                    quantity_override = filled_qty,
                    is_live_tracking  = True,
                )
            return True
        return False

    def _execute_live_sell(self, order: Order) -> bool:
        """Gerçek satış emri — OKXLiveClient ile gönder (LONG kapatma)."""
        result = self._place_live_order(
            symbol          = order.symbol,
            side            = "sell",
            quantity        = order.quantity,
            client_order_id = order.client_order_id,
        )

        if result and result.get("status") in ("filled", "live", "partially_filled"):
            order.fill(
                filled_price = result.get("filled_price", order.price),
                filled_qty   = result.get("filled_qty", order.quantity),
                fee          = result.get("fee", 0.0),
            )
            order.exchange_order_id = result.get("order_id", "")
            # Paper trader pozisyonunu kapat (PnL takibi için)
            if self.paper_trader and order.symbol in self.paper_trader.positions:
                self.paper_trader.close_position(
                    order.symbol,
                    result.get("filled_price", order.price),
                    "LIVE SELL",
                )
            return True
        return False

    def _place_live_short_open(
        self, symbol: str, quantity: float, client_order_id: str
    ) -> Optional[dict]:
        """
        OKX'e SHORT pozisyon AÇMA emri gönder.
        SHORT aç = side=sell, pos_side=short  (hedge modda net açıklama)
        _place_live_order(side="sell") → pos_side=long (LONG kapatır) — YANLIŞ.
        Bu metot doğrudan pos_side=short ile emir gönderir.
        """
        client = getattr(self, "_live_client", None)
        if not client or not client.is_authenticated():
            logger.error("[SHORT OPEN] Live client yok veya kimlik doğrulanmamış!")
            return None

        swap_fn = getattr(client, "place_swap_order", None)
        if not swap_fn:
            logger.error(f"[SHORT OPEN] {symbol}: place_swap_order metodu yok!")
            return None

        # Minimum notional kontrolü
        MIN_NOTIONAL_USD = 5.0
        price = 0.0
        if hasattr(client, "get_ticker"):
            ticker = client.get_ticker(symbol)
            price = float((ticker or {}).get("last", (ticker or {}).get("last_price", 0.0)))
        elif hasattr(client, "get_last_price"):
            price = float(client.get_last_price(symbol) or 0.0)
        if price > 0:
            notional = quantity * price
            if notional < MIN_NOTIONAL_USD:
                logger.warning(
                    f"[SHORT OPEN] Emir atlandı — notional ${notional:.2f} < ${MIN_NOTIONAL_USD} "
                    f"| SHORT {quantity:.6f} {symbol} @ ${price:.2f}"
                )
                return None

        # Kaldıraçlı kontrat miktarı
        swap_coin_qty = quantity * max(self.leverage, 1.0)
        logger.debug(
            f"[SHORT OPEN] {symbol}: marjin_qty={quantity:.4f} "
            f"× kaldıraç={self.leverage:.0f}x → notional_qty={swap_coin_qty:.4f} coin"
        )

        # Minimum Contract Viability Check (SHORT için de geçerli)
        if hasattr(client, "_get_swap_specs") and hasattr(client, "_inst_id"):
            _inst_spot = client._inst_id(symbol)
            if _inst_spot:
                _swap_inst_id = f"{_inst_spot}-SWAP"
                _specs        = client._get_swap_specs(_swap_inst_id)
                _ct_val       = _specs.get("ct_val", 1.0)
                _min_sz       = _specs.get("min_sz", 1)
                _n_contracts  = swap_coin_qty / _ct_val if _ct_val > 0 else 0
                if _n_contracts < _min_sz:
                    _slot_notional_usd = round(swap_coin_qty * price, 2) if price > 0 else 0
                    logger.warning(
                        f"[SHORT CONTRACT-CHECK] ❌ {symbol} SHORT REDDEDİLDİ — "
                        f"slot notional ${_slot_notional_usd} → {_n_contracts:.2f} kontrat "
                        f"(minimum: {_min_sz}, ctVal={_ct_val})"
                    )
                    return None

        result = swap_fn(
            symbol          = symbol,
            side            = "sell",
            pos_side        = "short",
            coin_quantity   = swap_coin_qty,
            order_type      = "market",
            client_order_id = client_order_id,
        )
        if result:
            logger.info(f"[SHORT OPEN] SWAP SHORT açma emri kabul edildi: {swap_coin_qty:.4f} coin ({symbol})")
        else:
            logger.error(
                f"[SHORT OPEN] SWAP SHORT başarısız ({symbol}) — "
                f"OKX hatası veya kontrat boyutu yetersiz"
            )
        return result

    def _place_live_short_close(
        self, symbol: str, quantity: float, client_order_id: str
    ) -> Optional[dict]:
        """
        OKX'e SHORT pozisyon KAPATMA emri gönder.
        SHORT kapat = side=buy, pos_side=short  (hedge modda net kapatma)
        _place_live_order(side="sell") → pos_side=long (LONG kapatır) — YANLIŞ.
        Bu metot doğrudan side=buy, pos_side=short ile emir gönderir.
        """
        client = getattr(self, "_live_client", None)
        if not client or not client.is_authenticated():
            logger.error("[SHORT CLOSE] Live client yok veya kimlik doğrulanmamış!")
            return None

        swap_fn = getattr(client, "place_swap_order", None)
        if not swap_fn:
            logger.error(f"[SHORT CLOSE] {symbol}: place_swap_order metodu yok!")
            return None

        # Kaldıraçlı kontrat miktarı (açılışla simetrik)
        swap_coin_qty = quantity * max(self.leverage, 1.0)
        logger.info(
            f"[SHORT CLOSE] {symbol}: kapatma qty={quantity:.4f} "
            f"× kaldıraç={self.leverage:.0f}x → notional_qty={swap_coin_qty:.4f} coin"
        )

        result = swap_fn(
            symbol          = symbol,
            side            = "buy",       # SHORT kapat = alış yönünde
            pos_side        = "short",     # hedge mod: short tarafı kapat
            coin_quantity   = swap_coin_qty,
            order_type      = "market",
            client_order_id = client_order_id,
        )
        if result:
            logger.info(
                f"[SHORT CLOSE] ✅ SWAP SHORT kapatma emri kabul edildi: "
                f"{swap_coin_qty:.4f} coin ({symbol})"
            )
        else:
            logger.error(
                f"[SHORT CLOSE] ❌ SWAP SHORT kapatma başarısız ({symbol}) — "
                f"OKX'te açık SHORT pozisyon var mı kontrol edin."
            )
        return result

    def _execute_live_short_close(self, order: Order) -> bool:
        """Gerçek SHORT KAPATMA emri — OKXLiveClient ile gönder (side=buy, pos_side=short)."""
        result = self._place_live_short_close(
            symbol          = order.symbol,
            quantity        = order.quantity,
            client_order_id = order.client_order_id,
        )

        if result and result.get("status") in ("filled", "live", "partially_filled"):
            filled_price = result.get("filled_price") or order.price
            filled_qty   = result.get("filled_qty",   order.quantity)
            order.fill(
                filled_price = filled_price,
                filled_qty   = filled_qty,
                fee          = result.get("fee", 0.0),
            )
            order.exchange_order_id = result.get("order_id", "")
            # Paper trader'da short pozisyonu kapat (PnL takibi için)
            if self.paper_trader and order.symbol in self.paper_trader.positions:
                self.paper_trader.close_position(
                    order.symbol,
                    filled_price,
                    "LIVE SHORT CLOSE",
                )
            return True
        return False

    def _execute_live_short(self, order: Order) -> bool:
        """Gerçek SHORT emri — OKXLiveClient ile gönder (SWAP SHORT aç)."""
        result = self._place_live_short_open(
            symbol          = order.symbol,
            quantity        = order.quantity,
            client_order_id = order.client_order_id,
        )

        if result and result.get("status") in ("filled", "live", "partially_filled"):
            # Fiyat sıfır gelirse order.price'ı kullan (OKX zaman zaman 0 döner)
            filled_price = result.get("filled_price") or order.price
            filled_qty   = result.get("filled_qty",   order.quantity)
            order.fill(
                filled_price = filled_price,
                filled_qty   = filled_qty,
                fee          = result.get("fee", 0.0),
            )
            order.exchange_order_id = result.get("order_id", "")
            # Paper trader'ı senkronize et (SHORT PnL takibi için)
            if self.paper_trader:
                self.paper_trader.open_short_position(
                    symbol            = order.symbol,
                    price             = filled_price,
                    stop_loss         = order.stop_loss,
                    take_profit       = order.take_profit,
                    strategy_name     = order.strategy_name,
                    quantity_override = filled_qty,
                    is_live_tracking  = True,
                )
            return True
        return False

    # ─── Yardımcı ─────────────────────────────────────────────────────────────

    def _has_pending(self, symbol: str) -> bool:
        return symbol in self._pending

    @staticmethod
    def _new_order_id() -> str:
        """
        OKX uyumlu benzersiz emir ID'si üret.
        OKX clOrdId yalnızca harf ve rakam kabul eder (tire/özel karakter yok).
        """
        return f"BOT{uuid.uuid4().hex[:12].upper()}"

    def get_order_history(self) -> list:
        """Tüm emir geçmişi."""
        return [o.to_dict() for o in self._order_history]

    def get_recent_orders(self, limit: int = 50) -> list:
        """Son N emir."""
        return [o.to_dict() for o in self._order_history[-limit:]]

    @property
    def total_orders(self) -> int:
        return len(self._order_history)

    @property
    def filled_orders(self) -> int:
        return sum(1 for o in self._order_history if o.status == Order.STATUS_FILLED)
