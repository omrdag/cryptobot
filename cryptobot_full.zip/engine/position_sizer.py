"""
Position Sizer — Pozisyon Boyutlandırma Motoru
===============================================
ATR tabanlı veya sabit yüzde ile pozisyon büyüklüğünü hesaplar.

ATR Modu (önerilen):
    quantity = (balance × risk_per_trade) / stop_distance
    stop_distance = ATR × sl_multiplier

Sabit Mod:
    quantity = (balance × trade_amount_pct) / price

Slot Modu (v4 — birincil):
    slot_notional verildiğinde kalite-cap tamamen devre dışı kalır.
    margin  = slot_notional / leverage
    quantity = margin / price          ← execution.py bu değeri × leverage yapar
    final OKX notional = quantity × leverage × price = slot_notional ✓

Kullanım:
    ps = PositionSizer(mode="atr", risk_per_trade=0.01, ...)
    result = ps.calculate(symbol, price, atr, balance, slot_notional=125)
    # result: {quantity, trade_value, stop_loss, take_profit, risk_amount, ...}
"""

from typing import Optional
from utils.logger import get_logger

logger = get_logger()

# Sinyal kalitesi → hedef notional (USDT)
# Risk hesabı bu değerleri üst sınır olarak kullanır; risk < hedef ise risk kullanılır
_QUALITY_TARGET_NOTIONAL = {
    "A": 125.0,   # Güçlü sinyal → 125 USDT
    "B": 100.0,   # Normal sinyal → 100 USDT
    "C":  75.0,   # Zayıf sinyal  →  75 USDT (= min_notional)
}

# config'den güncel değerleri almayı dene (dinamik override için)
try:
    from config import POSITION_NOTIONAL_BY_QUALITY as _Q
    _QUALITY_TARGET_NOTIONAL.update(_Q)
except ImportError:
    pass


class PositionSizer:
    """
    Pozisyon büyüklüğü ve SL/TP seviyelerini hesaplar.
    Kaldıraç desteği: marjin aynı kalır, miktar leverage × büyür.

    Boyutlandırma mantığı (v3 — kalite bazlı hedef):
      1. Risk tutarı = bakiye × risk_pct           → $10 (1000 USDT × %1)
      2. Teorik notional = risk / stop_distance     → ATR tabanlı
      3. Kalite hedefini üst limit olarak uygula:
           actual = min(teorik, kalite_hedefi)      → B=100, A=125, C=75
      4. Eğer actual < min_notional (75 USDT) → None (işlem atlanır)
      5. Eğer actual > max_notional (150 USDT) → hard cap uygula
      6. Kaldıraç, komisyon, log ekle
    """

    def __init__(
        self,
        mode: str           = "atr",     # "atr" veya "fixed"
        risk_per_trade: float = 0.01,    # Bakiyenin %1'i riske edilir
        trade_amount_pct: float = 0.10,  # Sabit mod: bakiyenin %10'u
        atr_sl_multiplier: float = 1.5,  # SL = giriş - ATR × bu
        atr_tp_multiplier: float = 3.0,  # TP = giriş + ATR × bu
        stop_loss_pct: float  = 0.02,    # Fallback SL (%2)
        take_profit_pct: float = 0.04,   # Fallback TP (%4)
        fee_rate: float       = 0.001,   # Komisyon oranı
        slippage_pct: float   = 0.0005,  # Slippage oranı
        min_trade_value: float = 10.0,   # Minimum işlem değeri (USDT) — eski uyumluluk
        leverage: float       = 1.0,     # Kaldıraç çarpanı
        # ── Risk Bazlı Notional Limitleri (v3) ──────────────────
        min_notional: float   = 75.0,    # Min işlem notional'ı (USDT) — C kalite
        max_notional: float   = 150.0,   # Max notional hard cap (USDT)
    ):
        self.mode             = mode
        self.risk_per_trade   = risk_per_trade
        self.trade_amount_pct = trade_amount_pct
        self.atr_sl_mult      = atr_sl_multiplier
        self.atr_tp_mult      = atr_tp_multiplier
        self.stop_loss_pct    = stop_loss_pct
        self.take_profit_pct  = take_profit_pct
        self.fee_rate         = fee_rate
        self.slippage_pct     = slippage_pct
        self.min_trade_value  = min_trade_value
        self.leverage         = max(1.0, leverage)
        self.min_notional     = max(0.0, min_notional)
        self.max_notional     = max(self.min_notional, max_notional)

    def calculate(
        self,
        symbol: str,
        price: float,
        available_balance: float,
        atr: Optional[float] = None,
        signal_quality: str  = "B",          # "A" / "B" / "C" — kalite-bazlı path için
        slot_notional: Optional[float] = None, # Slot'un belirlediği nihai notional (USDT, kaldıraçlı)
    ) -> Optional[dict]:
        """
        Pozisyon büyüklüğü ve SL/TP seviyelerini hesapla.

        slot_notional verilirse (v4 — birincil path):
          - Slot miktarı tek kaynak olur; kalite cap, quality target DEVREDİŞI
          - margin = slot_notional / leverage
          - quantity = margin / price  →  execution × leverage = slot_notional / price coin
          - Yalnızca bakiye yetersizliğinde aşağı ölçeklenir (hiçbir zaman yukarı)

        slot_notional verilmezse (legacy path — kalite bazlı):
          1. Risk tutarı hesapla (bakiye × risk_pct)
          2. ATR/fixed modunda teorik pozisyon boyutu bul
          3. Kalite hedefini üst sınır olarak uygula (A=125, B=100, C=75)
          4. Hard cap uygula (max_notional = 150 USDT)
          5. Min altındaysa None döndür (işlem atlanır)
          6. Kaldıraç, komisyon ve log ekle

        Returns dict veya None (işlem açılmamalı)
        """
        if price <= 0 or available_balance <= 0:
            logger.warning(f"{symbol}: Geçersiz fiyat veya bakiye ({price}, {available_balance})")
            return None

        quality = signal_quality.upper() if signal_quality else "B"
        lev_tag = f" [{self.leverage:.0f}x]" if self.leverage > 1 else ""

        # ── SLOT NOTIONAL PATH (v4 — tek kaynak) ────────────────────────────
        # slot_notional verildiğinde kalite tablosu tamamen atlanır.
        # Yalnızca bakiye yetersizliği durumunda aşağı ölçeklenir.
        if slot_notional is not None and slot_notional > 0:
            return self._slot_based_sizing(
                symbol, price, available_balance, atr, slot_notional, quality, lev_tag
            )

        # Kalite bazlı hedef notional: B→100, A→125, C→75
        quality_target = _QUALITY_TARGET_NOTIONAL.get(quality, 100.0)

        # Slippage dahil efektif giriş fiyatı
        effective_price = price * (1 + self.slippage_pct)

        if self.mode == "atr" and atr and atr > 0:
            result = self._atr_sizing(symbol, price, effective_price, available_balance, atr)
        else:
            if self.mode == "atr" and not atr:
                logger.warning(f"{symbol}: ATR verisi yok, sabit moda geçiliyor")
            result = self._fixed_sizing(symbol, price, effective_price, available_balance)

        if result is None:
            return None

        theoretical_notional = result["trade_value"]
        limit_reason = None

        # ── Kalite Bazlı Hedef Notional (üst sınır olarak) ──────────────────
        # Teorik notional, kalite hedefinden büyükse → hedef notional kullan
        # Teorik notional, kalite hedefinden küçükse → risk-limited (teorik kullan)
        if theoretical_notional > quality_target:
            cap_ratio             = quality_target / theoretical_notional
            result["quantity"]    = result["quantity"]    * cap_ratio
            result["trade_value"] = quality_target
            result["risk_amount"] = result["risk_amount"] * cap_ratio
            limit_reason = f"{quality} kalite hedefi ${quality_target:.0f}"

        # ── Hard Cap: max_notional (150 USDT) ───────────────────────────────
        if self.max_notional > 0 and result["trade_value"] > self.max_notional:
            cap_ratio             = self.max_notional / result["trade_value"]
            result["quantity"]    = result["quantity"]    * cap_ratio
            result["trade_value"] = self.max_notional
            result["risk_amount"] = result["risk_amount"] * cap_ratio
            limit_reason = f"hard cap ${self.max_notional:.0f}'e kesildi"

        # ── Min Notional Kontrolü ────────────────────────────────────────────
        if self.min_notional > 0 and result["trade_value"] < self.min_notional:
            logger.info(
                f"[SIZER] {symbol} ATLANDI | "
                f"Teorik: ${theoretical_notional:.2f} | "
                f"Kalite: {quality} → hedef ${quality_target:.0f} | "
                f"Hesaplanan: ${result['trade_value']:.2f} < min ${self.min_notional:.0f} → işlem açılmayacak"
            )
            return None

        # ── Kaldıraç Uygula ──────────────────────────────────────────────────
        if self.leverage > 1.0:
            if self.mode == "atr":
                notional_val        = result["trade_value"]
                result["margin"]    = notional_val / self.leverage
                result["notional"]  = notional_val
                result["leverage"]  = self.leverage
            else:
                result["margin"]    = result["trade_value"]
                result["quantity"]  = result["quantity"] * self.leverage
                result["notional"]  = result["trade_value"] * self.leverage
                result["leverage"]  = self.leverage

        # Komisyon notional üzerinden (kaldıraçlı)
        notional = result.get("notional", result["trade_value"])
        result["fee"] = notional * self.fee_rate * 2
        result["effective_price"]  = effective_price
        result["signal_quality"]   = quality
        result["quality_target"]   = quality_target
        result["theoretical_notional"] = theoretical_notional
        result["risk_reward"] = (
            (result["take_profit"] - effective_price) /
            (effective_price - result["stop_loss"])
            if effective_price > result["stop_loss"] else 0
        )

        logger.info(
            f"[SIZER{lev_tag}] {symbol} | "
            f"Bakiye: ${available_balance:.2f} | "
            f"Risk tutarı: ${result['risk_amount']:.2f} (%{self.risk_per_trade*100:.1f}) | "
            f"Teorik: ${theoretical_notional:.2f} | "
            f"Kalite: {quality} (hedef ${quality_target:.0f}) | "
            f"Uygulanmış: ${result['trade_value']:.2f}"
            + (f" ← {limit_reason}" if limit_reason else "") +
            f" | SL: ${result['stop_loss']:,.4f} | RR: {result['risk_reward']:.2f}"
        )
        return result

    def _atr_sizing(
        self, symbol: str, price: float, eff_price: float,
        balance: float, atr: float
    ) -> Optional[dict]:
        """ATR tabanlı pozisyon boyutlandırma."""
        stop_distance = atr * self.atr_sl_mult
        risk_amount   = balance * self.risk_per_trade

        if stop_distance <= 0:
            logger.warning(f"{symbol}: ATR stop mesafesi sıfır")
            return None

        quantity    = risk_amount / stop_distance
        trade_value = quantity * eff_price

        # Bakiye kontrolü
        if trade_value > balance * 0.95:
            quantity    = (balance * 0.95) / eff_price
            trade_value = quantity * eff_price

        if trade_value < self.min_trade_value:
            logger.warning(f"{symbol}: İşlem değeri çok küçük (${trade_value:.2f} < ${self.min_trade_value})")
            return None

        stop_loss   = eff_price - stop_distance
        take_profit = eff_price + (atr * self.atr_tp_mult)

        return {
            "quantity":    quantity,
            "trade_value": trade_value,
            "stop_loss":   max(stop_loss, 0.0),
            "take_profit": take_profit,
            "risk_amount": risk_amount,
            "sizing_mode": "atr",
            "atr":         atr,
        }

    def _fixed_sizing(
        self, symbol: str, price: float, eff_price: float, balance: float
    ) -> Optional[dict]:
        """Sabit yüzde pozisyon boyutlandırma."""
        # İstenen marjin miktarı
        requested = balance * self.trade_amount_pct
        # Serbest bakiyenin %95'ini asla aşma (OKX 51008 önlemi)
        trade_value = min(requested, balance * 0.95)

        if trade_value < self.min_trade_value:
            logger.warning(f"{symbol}: Yetersiz bakiye (${balance:.2f})")
            return None

        quantity    = trade_value / eff_price
        stop_loss   = eff_price * (1 - self.stop_loss_pct)
        take_profit = eff_price * (1 + self.take_profit_pct)
        risk_amount = trade_value * self.stop_loss_pct

        return {
            "quantity":    quantity,
            "trade_value": trade_value,
            "stop_loss":   stop_loss,
            "take_profit": take_profit,
            "risk_amount": risk_amount,
            "sizing_mode": "fixed",
            "atr":         None,
        }

    def _slot_based_sizing(
        self,
        symbol: str,
        price: float,
        balance: float,
        atr: Optional[float],
        slot_notional: float,
        quality: str,
        lev_tag: str,
    ) -> Optional[dict]:
        """
        Slot notional'dan pozisyon büyüklüğü hesapla (v4 — tek kaynak).

        Execution akışı:
          1. margin  = slot_notional / leverage
          2. quantity = margin / price          (marjin-bazlı coin miktarı)
          3. execution.py: swap_coin_qty = quantity × leverage = slot_notional / price
          4. OKX notional = swap_coin_qty × price = slot_notional ✓

        Risk güvenliği:
          - Marjin bakiyenin %90'ını asla geçemez
          - Aşılırsa ölçekle ve logla
        """
        eff_price = price * (1 + self.slippage_pct)

        # Hedef marjin = slot notional / kaldıraç
        target_margin = slot_notional / self.leverage

        # ── Risk Güvenliği: Bakiyenin %90'ını asla geçme ────────────────────
        max_safe_margin  = balance * 0.90
        applied_margin   = min(target_margin, max_safe_margin)
        applied_notional = applied_margin * self.leverage

        if applied_margin < 1.0:
            logger.warning(
                f"[SLOT-SIZER{lev_tag}] {symbol}: "
                f"Hedef marjin ${applied_margin:.2f} < $1 minimum — emir atlandı"
            )
            return None

        # ── SL / TP ──────────────────────────────────────────────────────────
        if atr and atr > 0:
            stop_distance = atr * self.atr_sl_mult
            stop_loss     = eff_price - stop_distance
            take_profit   = eff_price + (atr * self.atr_tp_mult)
            risk_amount   = balance * self.risk_per_trade
            sizing_mode   = "slot+atr"
        else:
            stop_loss   = eff_price * (1 - self.stop_loss_pct)
            take_profit = eff_price * (1 + self.take_profit_pct)
            risk_amount = applied_margin * self.stop_loss_pct
            sizing_mode = "slot+fixed"

        # ── Miktar (marjin bazlı) ─────────────────────────────────────────────
        # execution.py: swap_coin_qty = quantity × leverage → doğru notional
        quantity = applied_margin / eff_price

        # ── Log ──────────────────────────────────────────────────────────────
        balance_limited = applied_notional < slot_notional * 0.99
        limit_note      = (
            f" ⚠ BAKİYE SINIRI: ${applied_notional:.1f} < slot ${slot_notional:.1f}"
            if balance_limited else " ✓ slot tam uygulandı"
        )
        rr = (
            (take_profit - eff_price) / (eff_price - stop_loss)
            if eff_price > stop_loss else 0
        )

        logger.info(
            f"[SLOT-SIZER{lev_tag}] {symbol} | "
            f"Slot Notional: ${slot_notional:.0f} → "
            f"Marjin: ${applied_margin:.2f} | "
            f"Notional: ${applied_notional:.2f} | "
            f"Miktar (marjin-coin): {quantity:.4f} | "
            f"Kalite: {quality} | SL: ${stop_loss:,.4f} | RR: {rr:.2f}"
            f"{limit_note}"
        )

        fee = applied_notional * self.fee_rate * 2

        return {
            "quantity":    quantity,           # marjin-bazlı coin (exec × leverage = notional coin)
            "trade_value": applied_margin,     # marjin USDT
            "stop_loss":   max(stop_loss, 0.0),
            "take_profit": take_profit,
            "risk_amount": risk_amount,
            "sizing_mode": sizing_mode,
            "atr":         atr,
            # Slot bilgileri
            "slot_notional":          slot_notional,
            "slot_notional_applied":  applied_notional,
            "slot_notional_override": balance_limited,
            # Kaldıraç bilgileri
            "margin":   applied_margin,
            "notional": applied_notional,
            "leverage": self.leverage,
            # Meta
            "fee":             fee,
            "effective_price": eff_price,
            "signal_quality":  quality,
            "risk_reward":     rr,
        }
