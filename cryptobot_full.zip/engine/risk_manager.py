"""
Risk Manager — Güçlendirilmiş Risk Yönetim Motoru v3
=====================================================
Her sinyal bu risk motorundan geçmeden işleme dönüşmez.

Kontroller:
  1. Kill switch aktif mi?
  2. Günlük max zarar limiti aşıldı mı?
  3. Maksimum açık pozisyon sayısına ulaşıldı mı?
  4. Art arda kayıp limiti aşıldı mı?
  5. Drawdown koruması
  6. Savunma modu (defense mode): art arda kayıp sonrası pozisyon küçült
  7. Korelasyon koruması: aynı anda benzer coinler açılmasın
  8. BTC rejim filtresi: güçlü ayı piyasasında altcoin LONG engelle
  9. Düşük hacim filtresi: ince piyasalarda işlem açma
"""

from typing import Tuple, List, Optional, Dict, Set
from datetime import date, datetime, timedelta
import pandas as pd
from utils.logger import get_logger

# ── Sembol Bazlı Cooldown Ayarları ─────────────────────────────────────────
# config.py değerlerini öncelikli oku; yoksa fallback kullan
try:
    import config as _cfg
    SYMBOL_COOLDOWN_HOURS   = getattr(_cfg, "SYMBOL_COOLDOWN_HOURS",   4.0)
    SYMBOL_MAX_CONSEC_LOSS  = getattr(_cfg, "SYMBOL_MAX_CONSEC_LOSS",  2)
except Exception:
    SYMBOL_COOLDOWN_HOURS   = 4.0
    SYMBOL_MAX_CONSEC_LOSS  = 2

logger = get_logger()

# ── Korelasyon Grupları ────────────────────────────────────────────────────
# Aynı anda bu gruplardan birden fazla coin açılmaz
CORRELATED_GROUPS: List[Set[str]] = [
    {"BTCUSDT", "WBTCUSDT"},                          # BTC klonu
    {"ETHUSDT", "STETHUSDT", "WETHUSDT"},              # ETH klonu
    {"BNBUSDT", "CAKEUSDT"},                           # BSC ekosistemi
    {"SOLUSDT", "RAYUSDT", "JITOUSDT"},                # Solana ekosistemi
    {"AVAXUSDT", "SUSHIUSDT"},                         # Avalanche
    {"LINKUSDT", "AAVEUSDT", "COMPUSDT"},              # DeFi borç
    {"MATICUSDT", "OPUSDT", "ARBUSDT"},                # L2
    {"DOTUSDT", "KSMUSDT"},                            # Polkadot
    {"LTCUSDT", "BCHUSDT"},                            # BTC çatallı
]

# Düşük hacim eşiği (24s USDT ciro)
MIN_VOLUME_USDT = 5_000_000    # 5 milyon $ altındaki coinlerde işlem açma


class RiskEvent:
    def __init__(self, symbol: str, reason: str, blocked: bool):
        self.symbol  = symbol
        self.reason  = reason
        self.blocked = blocked

    def __repr__(self):
        flag = "BLOKE" if self.blocked else "OK"
        return f"<RiskEvent [{flag}] {self.symbol}: {self.reason}>"


class RiskManager:
    """
    Merkezi risk yönetim motoru.
    Kill switch, günlük limit, drawdown guard ve defense mode içerir.
    """

    def __init__(
        self,
        max_open_positions:    int   = 3,
        daily_max_loss_pct:    float = 0.05,    # %5 günlük max zarar
        max_consecutive_loss:  int   = 5,
        max_symbol_exposure:   float = 0.30,
        kill_switch:           bool  = False,
        # Drawdown guard
        max_drawdown_pct:      float = 0.15,    # %15 drawdown → tam durdur
        drawdown_warn_pct:     float = 0.08,    # %8 drawdown → pozisyon küçült
        # Defense mode
        defense_loss_count:    int   = 3,       # Bu kadar art arda kayıpta savunma modu
        defense_size_factor:   float = 0.5,     # Savunma modunda pozisyon × bu oran
    ):
        self.max_open_positions   = max_open_positions
        self.daily_max_loss_pct   = daily_max_loss_pct
        self.max_consecutive_loss = max_consecutive_loss
        self.max_symbol_exposure  = max_symbol_exposure
        self.kill_switch          = kill_switch
        self.max_drawdown_pct     = max_drawdown_pct
        self.drawdown_warn_pct    = drawdown_warn_pct
        self.defense_loss_count   = defense_loss_count
        self.defense_size_factor  = defense_size_factor

        # İç durum
        self._consecutive_losses: int      = 0
        self._day_start_value:    float    = 0.0
        self._peak_value:         float    = 0.0    # Drawdown hesabı için
        self._current_day:        date     = date.today()
        self._events:             List[RiskEvent] = []
        self._defense_mode:       bool     = False   # Savunma modu aktif mi
        self._block_since:        Optional[datetime] = None  # Blok ne zaman başladı
        self.consecutive_loss_reset_hours: float = 4.0  # X saat sonra blok otomatik kalkar

        # Sembol bazlı art arda kayıp takibi
        self._symbol_consec_losses: Dict[str, int]      = {}  # symbol → art arda kayıp
        self._symbol_cooldown_end:  Dict[str, datetime] = {}  # symbol → cooldown bitiş

        # Günlük sembol işlem sayısı sınırı (aşırı işlem koruması)
        self._daily_symbol_trades: Dict[str, int]  = {}  # symbol → bu gün kaç işlem
        self._daily_trades_date:   date            = date.today()
        self.max_daily_trades_per_symbol: int      = 2    # Sembol başına günlük max işlem

        # ── Açık Risk Takibi (v3) ────────────────────────────────────────────
        # Her açık pozisyon için riske edilen USDT miktarını tutar
        self._open_risk_amounts: Dict[str, float] = {}   # symbol → risk_amount (USDT)
        self.max_total_open_risk_pct: float        = 0.02  # %2 toplam açık risk

    # ─── Ana Kontrol ──────────────────────────────────────────────────────────

    def _maybe_auto_reset_losses(self):
        """
        Art arda kayıp bloğunu otomatik kaldır:
        - Yeni gün başladığında SIFIRLA
        - Blok üzerinden `consecutive_loss_reset_hours` saat geçtiyse SIFIRLA
        """
        if self._consecutive_losses < self.max_consecutive_loss:
            return  # Blok yok, kontrol gereksiz

        today = date.today()
        if today != self._current_day:
            logger.info(
                f"[RISK] Yeni gün — art arda kayıp sayacı sıfırlandı "
                f"({self._consecutive_losses} → 0)."
            )
            self._consecutive_losses = 0
            self._defense_mode = False
            self._block_since  = None
            self._current_day  = today
            return

        if self._block_since is not None:
            elapsed_h = (datetime.utcnow() - self._block_since).total_seconds() / 3600.0
            if elapsed_h >= self.consecutive_loss_reset_hours:
                logger.info(
                    f"[RISK] Blok üzerinden {elapsed_h:.1f} saat geçti — "
                    f"art arda kayıp sayacı sıfırlandı ({self._consecutive_losses} → 0)."
                )
                self._consecutive_losses = 0
                self._defense_mode = False
                self._block_since  = None

    def check_signal(
        self,
        symbol:          str,
        side:            str,
        portfolio_value: float,
        open_positions:  dict,
        initial_balance: float = None,
    ) -> Tuple[bool, str]:
        """
        Sinyal geçerli mi? (True/False, gerekçe)
        SELL/kapat sinyalleri her zaman geçer.
        """
        # Kapatma sinyalleri her zaman geçer
        if side in ("SELL", "CLOSE"):
            return True, "Kapatma sinyali — risk kontrolü bypass"

        # 1. Kill switch
        if self.kill_switch:
            return self._block(symbol, "Kill switch aktif — yeni işlem açılamaz")

        # 2. Günlük zarar limiti
        ok, reason = self._check_daily_loss(portfolio_value, initial_balance)
        if not ok:
            return self._block(symbol, reason)

        # 3. Drawdown guard
        ok, reason = self._check_drawdown(portfolio_value)
        if not ok:
            return self._block(symbol, reason)

        # 4. Açık pozisyon limiti (manuel pozisyonlar sayılmaz)
        _bot_pos_count = sum(
            1 for p in open_positions.values()
            if not getattr(p, 'is_manual', False)
        )
        if _bot_pos_count >= self.max_open_positions:
            return self._block(
                symbol,
                f"Maks. açık pozisyon sayısına ulaşıldı ({self.max_open_positions})"
            )

        # 5. Zaten açık pozisyon var mı?
        if symbol in open_positions:
            return self._block(symbol, f"{symbol} için zaten açık pozisyon var")

        # 6. Art arda kayıp limiti (hard stop) — günlük/zamanlı otomatik reset ile
        self._maybe_auto_reset_losses()
        if self._consecutive_losses >= self.max_consecutive_loss:
            return self._block(
                symbol,
                f"Art arda {self._consecutive_losses} kayıp — "
                f"yeni işlem durduruldu ({self.consecutive_loss_reset_hours:.0f} saat sonra açılır)"
            )

        # 7. Sembol bazlı cooldown (art arda kayıp sonrası geçici yasak)
        sym_ok, sym_reason = self._check_symbol_cooldown(symbol)
        if not sym_ok:
            return self._block(symbol, sym_reason)

        # 7b. Günlük sembol işlem sınırı (aşırı işlem koruması)
        daily_ok, daily_reason = self._check_daily_symbol_cap(symbol)
        if not daily_ok:
            return self._block(symbol, daily_reason)

        # 8. Korelasyon koruması
        corr_ok, corr_reason = self._check_correlation(symbol, open_positions)
        if not corr_ok:
            return self._block(symbol, corr_reason)

        self._log_ok(symbol)
        return True, "Tüm risk kontrolleri geçildi"

    def position_size_multiplier(self) -> float:
        """
        Pozisyon büyüklüğü çarpanı.
        Savunma modunda pozisyonu küçültür.
        Normal: 1.0, Savunma: defense_size_factor
        """
        if self._defense_mode:
            return self.defense_size_factor
        # Yumuşak azaltma: her art arda kayıpta biraz daha küçük
        if self._consecutive_losses >= 2:
            return max(0.3, 1.0 - (self._consecutive_losses - 1) * 0.15)
        return 1.0

    # ─── Güncelleme ───────────────────────────────────────────────────────────

    def update_portfolio_value(self, value: float):
        """Portföy değerini güncelle (drawdown takibi için)."""
        if value > self._peak_value:
            self._peak_value = value
        self.set_day_start_value(value)

    def set_day_start_value(self, value: float):
        """Günlük başlangıç portföy değerini ayarla."""
        today = date.today()
        if today != self._current_day:
            self._current_day  = today
            self._day_start_value = value
            logger.info(f"Risk: Yeni gün — başlangıç değeri ${value:,.2f}")
        elif self._day_start_value == 0:
            self._day_start_value = value
        if self._peak_value == 0:
            self._peak_value = value

    def activate_kill_switch(self, reason: str = "Manuel"):
        self.kill_switch = True
        logger.error(f"⛔ KİLL SWİTCH AKTİF: {reason}")

    def reset_kill_switch(self):
        self.kill_switch = False
        logger.info("Kill switch devre dışı bırakıldı.")

    def reset_defense_mode(self):
        self._defense_mode = False
        self._consecutive_losses = 0
        logger.info("Savunma modu devre dışı bırakıldı.")

    # ─── Yardımcı ─────────────────────────────────────────────────────────────

    def _check_daily_loss(
        self, portfolio_value: float, initial_balance: float = None
    ) -> Tuple[bool, str]:
        """Günlük zarar limitini kontrol et."""
        base = self._day_start_value or (initial_balance or portfolio_value)
        if base <= 0:
            return True, "OK"
        loss_pct = (portfolio_value - base) / base
        if loss_pct <= -self.daily_max_loss_pct:
            pct   = abs(loss_pct) * 100
            limit = self.daily_max_loss_pct * 100
            # Kill switch'i otomatik aktifleştir
            self.activate_kill_switch(f"Günlük zarar limiti aşıldı: -%{pct:.1f}")
            return False, f"Günlük zarar limiti aşıldı: -%{pct:.1f} (limit: -%{limit:.1f})"
        return True, "OK"

    def _check_drawdown(self, portfolio_value: float) -> Tuple[bool, str]:
        """Drawdown koruma kontrolü."""
        if self._peak_value <= 0:
            return True, "OK"
        drawdown_pct = (self._peak_value - portfolio_value) / self._peak_value
        if drawdown_pct >= self.max_drawdown_pct:
            return False, (
                f"Maksimum drawdown aşıldı: -%{drawdown_pct*100:.1f} "
                f"(limit: -%{self.max_drawdown_pct*100:.0f})"
            )
        return True, "OK"

    def current_drawdown_pct(self, portfolio_value: float) -> float:
        """Güncel drawdown yüzdesi."""
        if self._peak_value <= 0:
            return 0.0
        return max(0.0, (self._peak_value - portfolio_value) / self._peak_value * 100)

    # ─── Global Filtreler (dışarıdan çağrılır) ───────────────────────────────

    def check_btc_regime(
        self,
        btc_df: "pd.DataFrame",
        symbol: str,
        side: str,
    ) -> Tuple[bool, str]:
        """
        BTC güçlü bearish rejimdeyse altcoin LONG'larını filtrele.
        BTC pair'ler ve SHORT sinyalleri her zaman geçer.
        """
        if side != "BUY":
            return True, "SHORT sinyali — BTC rejim filtresi bypass"
        if symbol in ("BTCUSDT", "WBTCUSDT"):
            return True, "BTC pair — rejim filtresi bypass"

        if btc_df is None or len(btc_df) < 21:
            return True, "BTC verisi yetersiz — filtre atlanıyor"

        close     = btc_df["close"]
        ema_fast  = close.ewm(span=9,  adjust=False).mean().iloc[-1]
        ema_slow  = close.ewm(span=21, adjust=False).mean().iloc[-1]
        btc_price = close.iloc[-1]

        # Güçlü bearish: hızlı EMA < yavaş EMA ve fiyat yavaş EMA'nın altında
        bearish = ema_fast < ema_slow and btc_price < ema_slow
        if bearish:
            msg = (
                f"BTC ayı rejimi — altcoin LONG engellendi "
                f"(BTC ${btc_price:,.0f} | EMA9 ${ema_fast:,.0f} < EMA21 ${ema_slow:,.0f})"
            )
            logger.warning(f"Risk [BTC REJİM] {symbol}: {msg}")
            return False, msg
        return True, "BTC rejim: nötr/boğa — işleme izin ver"

    def check_volume_filter(
        self,
        symbol: str,
        volume_24h_usdt: float,
    ) -> Tuple[bool, str]:
        """
        Düşük hacimli coinlerde işlem açmayı engelle.
        24 saatlik hacim MIN_VOLUME_USDT altındaysa reddeder.
        """
        if volume_24h_usdt > 0 and volume_24h_usdt < MIN_VOLUME_USDT:
            msg = (
                f"Düşük hacim: ${volume_24h_usdt:,.0f} < ${MIN_VOLUME_USDT:,.0f} eşiği — "
                f"ince piyasada işlem açılmıyor"
            )
            logger.warning(f"Risk [HAÇİM] {symbol}: {msg}")
            return False, msg
        return True, "Hacim filtresi geçildi"

    def _check_daily_symbol_cap(self, symbol: str) -> Tuple[bool, str]:
        """
        Günlük sembol başına işlem limiti.
        Aynı sembolde günde max N işlem açılır.
        Gün değiştiğinde sayaç sıfırlanır.
        """
        today = date.today()
        if today != self._daily_trades_date:
            self._daily_symbol_trades = {}
            self._daily_trades_date   = today

        count = self._daily_symbol_trades.get(symbol, 0)
        if count >= self.max_daily_trades_per_symbol:
            return False, (
                f"{symbol}: Günlük sembol limiti doldu "
                f"({count}/{self.max_daily_trades_per_symbol}) — yarın tekrar"
            )
        return True, f"Günlük limit OK ({count}/{self.max_daily_trades_per_symbol})"

    def record_trade_open(self, symbol: str, risk_amount: float = 0.0):
        """
        İşlem açıldığında:
        - Günlük sembol sayacını artır
        - Açık risk kaydına ekle
        """
        today = date.today()
        if today != self._daily_trades_date:
            self._daily_symbol_trades = {}
            self._daily_trades_date   = today
        self._daily_symbol_trades[symbol] = self._daily_symbol_trades.get(symbol, 0) + 1
        logger.debug(
            f"[RISK-CAP] {symbol}: Bugün {self._daily_symbol_trades[symbol]}/"
            f"{self.max_daily_trades_per_symbol} işlem"
        )

        # Açık risk takibi
        if risk_amount > 0:
            self._open_risk_amounts[symbol] = risk_amount
            total = sum(self._open_risk_amounts.values())
            logger.debug(
                f"[OPEN-RISK] {symbol} açık risk: ${risk_amount:.2f} | "
                f"Toplam açık risk: ${total:.2f}"
            )

    def record_trade_close(self, symbol: str):
        """Pozisyon kapandığında açık risk kaydını kaldır."""
        removed = self._open_risk_amounts.pop(symbol, 0.0)
        if removed > 0:
            total = sum(self._open_risk_amounts.values())
            logger.debug(
                f"[OPEN-RISK] {symbol} kapatıldı, risk temizlendi: ${removed:.2f} | "
                f"Kalan açık risk: ${total:.2f}"
            )

    def get_total_open_risk(self) -> float:
        """Tüm açık pozisyonların toplam riske edilen USDT miktarı."""
        return sum(self._open_risk_amounts.values())

    def check_open_risk_limit(self, balance: float) -> tuple:
        """
        Toplam açık risk %2 bakiye sınırını aşıyor mu?
        Returns: (ok: bool, reason: str)
        """
        if balance <= 0 or self.max_total_open_risk_pct <= 0:
            return True, "Açık risk kontrolü devre dışı"
        total_risk = self.get_total_open_risk()
        limit_usdt = balance * self.max_total_open_risk_pct
        if total_risk >= limit_usdt:
            return False, (
                f"Toplam açık risk sınırına ulaşıldı: "
                f"${total_risk:.2f} / ${limit_usdt:.2f} "
                f"(%{self.max_total_open_risk_pct*100:.0f} bakiye)"
            )
        return True, f"Açık risk OK: ${total_risk:.2f} / ${limit_usdt:.2f}"

    def _check_symbol_cooldown(self, symbol: str) -> Tuple[bool, str]:
        """
        Sembol bazlı cooldown: aynı sembolde N art arda kayıp → geçici yasak.
        """
        now = datetime.utcnow()
        # Cooldown aktif mi?
        end = self._symbol_cooldown_end.get(symbol)
        if end and now < end:
            remaining = (end - now).total_seconds() / 60
            return False, (
                f"{symbol} cooldown: {SYMBOL_MAX_CONSEC_LOSS} art arda kayıp — "
                f"{remaining:.0f} dk daha bekle"
            )
        return True, "Sembol cooldown yok"

    def record_trade_result(self, pnl: float, symbol: str = None):
        """İşlem sonucunu kaydet (genel + sembol bazlı) ve açık riski temizle."""
        # Pozisyon kapandığında açık risk listesinden çıkar
        if symbol:
            self.record_trade_close(symbol)

        # Sembol bazlı takip
        if symbol:
            if pnl < 0:
                self._symbol_consec_losses[symbol] = self._symbol_consec_losses.get(symbol, 0) + 1
                consec = self._symbol_consec_losses[symbol]
                if consec >= SYMBOL_MAX_CONSEC_LOSS:
                    end = datetime.utcnow() + timedelta(hours=SYMBOL_COOLDOWN_HOURS)
                    self._symbol_cooldown_end[symbol] = end
                    logger.warning(
                        f"[RISK-SYMBOL] {symbol}: {consec} art arda kayıp → "
                        f"{SYMBOL_COOLDOWN_HOURS:.0f} saat cooldown başladı"
                    )
            else:
                # Kazandıysa sembol sayacını sıfırla
                self._symbol_consec_losses[symbol] = 0
                self._symbol_cooldown_end.pop(symbol, None)

        # Global art arda kayıp takibi (eski davranış)
        if pnl < 0:
            self._consecutive_losses += 1
            if self._consecutive_losses >= self.defense_loss_count:
                if not self._defense_mode:
                    self._defense_mode = True
                    logger.warning(
                        f"⚠ SAVUNMA MODU AKTİF: Art arda {self._consecutive_losses} kayıp. "
                        f"Pozisyon boyutu ×{self.defense_size_factor:.1f}"
                    )
            if self._consecutive_losses >= self.max_consecutive_loss and self._block_since is None:
                self._block_since = datetime.utcnow()
                logger.warning(
                    f"[RISK] Blok tetiklendi — {self.consecutive_loss_reset_hours:.0f} saat "
                    f"sonra otomatik kalkacak."
                )
            logger.warning(
                f"Risk: Art arda kayıp sayısı: {self._consecutive_losses}"
                + (" ← LİMİT AŞILDI" if self._consecutive_losses >= self.max_consecutive_loss else "")
            )
        else:
            if self._consecutive_losses > 0:
                logger.info(f"Risk: Kazanan işlem — art arda kayıp sayacı sıfırlandı.")
            self._consecutive_losses = 0
            self._defense_mode = False
            self._block_since  = None

    def get_symbol_status(self) -> dict:
        """Tüm sembollerin cooldown durumunu döndür."""
        now = datetime.utcnow()
        result = {}
        for sym, losses in self._symbol_consec_losses.items():
            end = self._symbol_cooldown_end.get(sym)
            result[sym] = {
                "consec_losses": losses,
                "cooldown_active": bool(end and now < end),
                "cooldown_ends": end.isoformat() if end else None,
            }
        return result

    def _check_correlation(
        self,
        symbol: str,
        open_positions: dict,
    ) -> Tuple[bool, str]:
        """
        Aynı anda yüksek korelasyonlu iki pozisyon açılmasını engelle.
        """
        for group in CORRELATED_GROUPS:
            if symbol in group:
                for open_sym in open_positions:
                    if open_sym in group and open_sym != symbol:
                        msg = (
                            f"Korelasyon: {symbol} ve {open_sym} aynı grupta — "
                            f"eş zamanlı açılmıyor"
                        )
                        return False, msg
        return True, "Korelasyon koruması geçildi"

    def check(
        self,
        symbol:          str,
        current_balance: float,
        initial_balance: float,
        open_positions:  dict,
        portfolio_value: float,
        side:            str = "BUY",
    ) -> Tuple[bool, str]:
        """
        multi-bot döngüsü için check_signal alias'ı.
        current_balance → portfolio_value yerine kullanılır.
        """
        return self.check_signal(
            symbol          = symbol,
            side            = side,
            portfolio_value = portfolio_value or current_balance,
            open_positions  = open_positions,
            initial_balance = initial_balance,
        )

    def _block(self, symbol: str, reason: str) -> Tuple[bool, str]:
        self._events.append(RiskEvent(symbol, reason, blocked=True))
        logger.warning(f"Risk [BLOKE] {symbol}: {reason}")
        return False, reason

    def _log_ok(self, symbol: str):
        self._events.append(RiskEvent(symbol, "OK", blocked=False))

    @property
    def defense_mode(self) -> bool:
        return self._defense_mode

    @property
    def status(self) -> dict:
        return {
            "kill_switch":          self.kill_switch,
            "defense_mode":         self._defense_mode,
            "consecutive_losses":   self._consecutive_losses,
            "max_consecutive":      self.max_consecutive_loss,
            "daily_max_loss_pct":   self.daily_max_loss_pct * 100,
            "max_drawdown_pct":     self.max_drawdown_pct * 100,
            "max_open_positions":   self.max_open_positions,
            "events_today":         len(self._events),
            "blocked_count":        sum(1 for e in self._events if e.blocked),
            "position_multiplier":  self.position_size_multiplier(),
        }
