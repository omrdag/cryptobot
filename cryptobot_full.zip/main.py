#!/usr/bin/env python3
"""
Kripto Trading Bot — Profesyonel Mimari v2
==========================================
Modüler motor mimarisi: Market Data → Strateji → Risk → Position Sizer → Execution

Kullanım:
    python main.py                          # Tam bot (DB entegrasyonu ile)
    python main.py --strategy ema_crossover # Belirli strateji
    python main.py --once                   # Tek döngü (test)
    python main.py --once --no-db           # DB'siz test
    python main.py --report                 # Performans raporu
    python main.py --backtest               # Backtest çalıştır
"""

import os
import sys
import time
import threading
import argparse
from datetime import datetime, date
from typing import Dict, Optional
from tabulate import tabulate
from colorama import Fore, Style, init

import json
import config
from exchange.client_factory import create_client
from engine.market_data import MarketDataEngine
from engine.risk_manager import RiskManager
from engine.position_sizer import PositionSizer
from engine.slot_manager import SlotManager
from engine.execution import ExecutionEngine
from strategies.ema_crossover import EMACrossoverStrategy
from strategies.ma_crossover import MACrossoverStrategy
from strategies.rsi import RSIStrategy
from strategies.macd import MACDStrategy
from strategies.bollinger_bands import BollingerBandsStrategy
from strategies.combined import CombinedStrategy
from strategies.signal_engine import SignalEngine
from strategies.pullback_long import PullbackLongStrategy
from strategies.pullback_short import PullbackShortStrategy
from strategies.base import Signal
from trader.paper_trader import PaperTrader
from filters.market_regime import MarketRegimeFilter
from utils.logger import get_logger
from db_writer import create_db_writer
from bots.momentum_bot import MomentumBot
from bots.reversal_bot import ReversalBot
from bots.divergence_bot import DivergenceBot
from bots.base_bot import BotSignal
from bots.bot_profiles import get_profile

init(autoreset=True)
logger = get_logger()

# Funding hesabı USDT bakiyesi (canlı modda startup + periyodik güncellenir)
_funding_usdt: float = 0.0


# ═══════════════════════════════════════════════════════════════════════════════
# DB'DEN COIN LİSTESİ OKU
# ═══════════════════════════════════════════════════════════════════════════════

def load_trading_pairs_from_db() -> list:
    """
    Veritabanındaki settings tablosundan izleme listesini okur.
    DB yoksa ya da liste boşsa config.py'deki değeri kullanır.
    """
    dsn = os.getenv("DATABASE_URL", "")
    if not dsn:
        return config.TRADING_PAIRS

    try:
        import psycopg2
        conn = psycopg2.connect(dsn)
        with conn.cursor() as cur:
            cur.execute("SELECT trading_pairs FROM settings LIMIT 1")
            row = cur.fetchone()
        conn.close()

        if row and row[0]:
            pairs = json.loads(row[0])
            if isinstance(pairs, list) and pairs:
                # OKX formatına normalize et (BTC/USDT → BTCUSDT)
                normalized = [p.replace("/", "").upper() for p in pairs]
                logger.info(f"DB'den coin listesi yüklendi: {normalized}")
                return normalized
    except Exception as e:
        logger.warning(f"DB coin listesi okunamadı, config.py kullanılıyor: {e}")

    return config.TRADING_PAIRS


def load_mode_from_db(risk_mgr=None) -> None:
    """
    DB'deki settings tablosundan trading parametrelerini okur ve config'e yazar.
    Bunlar: tradingMode, leverage, exchange, trade_amount, trade_amount_type,
            max_open_positions, max_consecutive_losses, max_daily_loss_pct.

    risk_mgr (opsiyonel): Verildiğinde risk yöneticisini de anlık günceller.
    """
    dsn = os.getenv("DATABASE_URL", "")
    if not dsn:
        return
    try:
        import psycopg2
        conn = psycopg2.connect(dsn)
        with conn.cursor() as cur:
            cur.execute(
                "SELECT trading_mode, leverage, exchange, "
                "       trade_amount, trade_amount_type, max_open_positions, "
                "       max_consecutive_losses, max_daily_loss_pct "
                "FROM settings LIMIT 1"
            )
            row = cur.fetchone()
        conn.close()
        if row:
            (db_mode, db_leverage, db_exchange, db_amount, db_amount_type,
             db_max_open, db_max_consec, db_daily_loss_pct) = row

            # Trading modu: "live" → PAPER_TRADING=False
            if db_mode and isinstance(db_mode, str):
                is_paper = db_mode.lower() != "live"
                if is_paper != config.PAPER_TRADING:
                    logger.info(
                        f"[DB] Trading modu: {db_mode.upper()} → "
                        f"PAPER_TRADING={'True' if is_paper else 'False'}"
                    )
                    config.PAPER_TRADING = is_paper

            # Leverage — env var açıkça set edilmişse DB'yi yoksay
            _env_lev = os.getenv("LEVERAGE")
            if db_leverage and int(db_leverage) != config.LEVERAGE:
                if _env_lev:
                    logger.info(
                        f"[DB] Kaldıraç DB'den ({db_leverage}x) yoksayıldı "
                        f"→ env LEVERAGE={_env_lev}x kullanılıyor"
                    )
                else:
                    logger.info(f"[DB] Kaldıraç: {db_leverage}x (config: {config.LEVERAGE}x)")
                    config.LEVERAGE = int(db_leverage)

            # Exchange
            if db_exchange and db_exchange.lower() != config.EXCHANGE.lower():
                logger.info(f"[DB] Borsa: {db_exchange} (config: {config.EXCHANGE})")
                config.EXCHANGE = db_exchange.lower()

            # İşlem boyutu
            if db_amount is not None:
                config.TRADE_AMOUNT = float(db_amount)
            if db_amount_type and db_amount_type in ("auto", "fixed", "percent"):
                config.TRADE_AMOUNT_TYPE = db_amount_type

            # ── Risk Parametreleri ───────────────────────────────────────────────

            # Maksimum açık pozisyon — config'in üzerine çıkmasına izin verme
            if db_max_open is not None:
                new_max = min(int(db_max_open), config.MAX_OPEN_POSITIONS)
                if new_max != config.MAX_OPEN_POSITIONS:
                    logger.info(
                        f"[DB] Maks açık pozisyon: {new_max} (eski: {config.MAX_OPEN_POSITIONS})"
                    )
                config.MAX_OPEN_POSITIONS = new_max
                if risk_mgr and risk_mgr.max_open_positions != new_max:
                    logger.info(f"[RiskMgr] max_open_positions → {new_max}")
                    risk_mgr.max_open_positions = new_max

            # Art arda maks kayıp
            if db_max_consec is not None:
                new_consec = int(db_max_consec)
                config.MAX_CONSECUTIVE_LOSS = new_consec
                if risk_mgr and risk_mgr.max_consecutive_loss != new_consec:
                    logger.info(f"[RiskMgr] max_consecutive_loss → {new_consec}")
                    risk_mgr.max_consecutive_loss = new_consec

            # Günlük maks kayıp yüzdesi (DB'de 8 → 0.08 şeklinde normalize edilir)
            if db_daily_loss_pct is not None:
                raw = float(db_daily_loss_pct)
                # DB'de yüzde olarak saklanıyor (ör. 8 = %8); config 0-1 aralığında
                normalized = raw / 100.0 if raw > 1.0 else raw
                config.DAILY_MAX_LOSS_PCT = normalized
                if risk_mgr and abs(risk_mgr.daily_max_loss_pct - normalized) > 0.0001:
                    logger.info(f"[RiskMgr] daily_max_loss_pct → {normalized:.3f} ({raw:.1f}%)")
                    risk_mgr.daily_max_loss_pct = normalized

    except Exception as e:
        logger.warning(f"DB mod ayarı okunamadı, config.py kullanılıyor: {e}")


# ═══════════════════════════════════════════════════════════════════════════════
# STRATEJİ FABRIKASI
# ═══════════════════════════════════════════════════════════════════════════════

def build_strategy(name: str):
    """Strateji adına göre strateji nesnesi döndürür."""
    name = name.lower()

    if name in ("signal_engine", "signal"):
        return SignalEngine(
            min_score           = config.SIGNAL_MIN_SCORE,
            ema_fast            = config.EMA_FAST_PERIOD,
            ema_slow            = config.EMA_SLOW_PERIOD,
            ema_trend           = config.EMA_TREND_PERIOD,
            rsi_period          = config.RSI_PERIOD,
            rsi_buy_max         = config.RSI_BUY_MAX,
            rsi_sell_min        = config.RSI_SELL_MIN,
            rsi_oversold        = config.RSI_OVERSOLD,
            rsi_overbought      = config.RSI_OVERBOUGHT,
            vol_min_ratio       = config.VOLUME_MIN_RATIO,
            atr_period          = config.ATR_PERIOD,
            min_atr_ratio       = config.MIN_ATR_THRESHOLD,
            candle_confirm_bars = config.CANDLE_CONFIRM_BARS,
            adx_min             = getattr(config, "ADX_MIN_THRESHOLD", 18.0),
            gate_min_score      = getattr(config, "GATE_MIN_SCORE",    7),
        )
    elif name == "ema_crossover":
        return EMACrossoverStrategy(
            fast_period         = config.EMA_FAST_PERIOD,
            slow_period         = config.EMA_SLOW_PERIOD,
            trend_period        = config.EMA_TREND_PERIOD,
            atr_period          = config.ATR_PERIOD,
            min_atr_threshold   = config.MIN_ATR_THRESHOLD,
            min_volume_factor   = config.MIN_VOLUME_FACTOR,
        )
    elif name == "ma_crossover":
        return MACrossoverStrategy(
            short_period = config.MA_SHORT_PERIOD,
            long_period  = config.MA_LONG_PERIOD,
        )
    elif name == "rsi":
        return RSIStrategy(
            period     = config.RSI_PERIOD,
            oversold   = config.RSI_OVERSOLD,
            overbought = config.RSI_OVERBOUGHT,
        )
    elif name == "macd":
        return MACDStrategy(
            fast_period   = config.MACD_FAST_PERIOD,
            slow_period   = config.MACD_SLOW_PERIOD,
            signal_period = config.MACD_SIGNAL_PERIOD,
        )
    elif name == "bollinger":
        return BollingerBandsStrategy(
            period  = config.BB_PERIOD,
            std_dev = config.BB_STD_DEV,
        )
    elif name == "combined":
        sub_strats = [build_strategy(s) for s in config.COMBINED_STRATEGIES]
        return CombinedStrategy(strategies=sub_strats, min_votes=config.COMBINED_MIN_VOTES)
    elif name in ("pullback", "pullback_long"):
        return PullbackLongStrategy(
            min_score=getattr(config, "GATE_MIN_SCORE", 7),
        )
    elif name == "pullback_short":
        return PullbackShortStrategy(
            min_score=getattr(config, "PULLBACK_SHORT_MIN_SCORE", 7),
        )
    else:
        raise ValueError(
            f"Bilinmeyen strateji: '{name}'. "
            "Seçenekler: signal_engine | pullback | pullback_short | ema_crossover | ma_crossover | rsi | macd | bollinger | combined"
        )


# ═══════════════════════════════════════════════════════════════════════════════
# EKRAN ÇIKTISI
# ═══════════════════════════════════════════════════════════════════════════════

def print_banner():
    print(f"""
{Fore.CYAN}╔══════════════════════════════════════════════════════════╗
║       Kripto Trading Bot — Profesyonel Mimari v2          ║
║   Market Data → Strateji → Risk → Execution Engine        ║
╚══════════════════════════════════════════════════════════╝{Style.RESET_ALL}
""")


def print_status(trader: PaperTrader, mde: MarketDataEngine, strategy_name: str, risk_status: dict):
    """Döngü durumunu tabloya bas."""
    rows = []
    prices = mde.get_all_prices()

    for symbol in mde.symbols:
        price = prices.get(symbol)
        if not price:
            continue

        pos = trader.positions.get(symbol)
        if pos:
            upnl     = trader.unrealized_pnl(symbol, price) or 0
            upnl_pct = trader.unrealized_pnl_pct(symbol, price) or 0
            sl_dist  = ((price - pos.stop_loss) / price * 100) if pos.stop_loss else 0
            tp_dist  = ((pos.take_profit - price) / price * 100) if pos.take_profit else 0
            status   = (
                f"AÇIK [{pos.candles_held}mum] | "
                f"${pos.entry_price:,.2f}"
            )
            pnl_str = f"{Fore.GREEN if upnl >= 0 else Fore.RED}${upnl:+,.2f} ({upnl_pct:+.2f}%){Style.RESET_ALL}"
            rows.append([symbol, f"${price:,.4f}", status, pnl_str,
                         f"SL:{sl_dist:.1f}% TP:{tp_dist:.1f}%"])
        else:
            rows.append([symbol, f"${price:,.4f}", "Bekliyor", "-", "-"])

    print(f"\n{Fore.YELLOW}─── [{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] "
          f"Strateji: {strategy_name} ───{Style.RESET_ALL}")

    if rows:
        print(tabulate(rows,
                       headers=["Sembol", "Fiyat", "Durum", "Kâr/Zarar", "SL/TP Mesafe"],
                       tablefmt="rounded_outline"))

    port_val      = trader.portfolio_value(prices)
    funding_usdt  = _funding_usdt
    total_assets  = port_val + funding_usdt
    ref_balance   = trader.initial_balance if trader.initial_balance > 0 else port_val
    total_ret     = ((total_assets - ref_balance) / ref_balance) * 100
    ret_color     = Fore.GREEN if total_ret >= 0 else Fore.RED

    risk_info = ""
    if risk_status.get("kill_switch"):
        risk_info = f" | {Fore.RED}⛔ KILL SWITCH AKTİF{Style.RESET_ALL}"
    elif risk_status.get("consecutive_losses", 0) > 0:
        risk_info = f" | {Fore.YELLOW}⚠ Art arda kayıp: {risk_status['consecutive_losses']}{Style.RESET_ALL}"

    if funding_usdt > 0:
        print(
            f"  Trading: ${port_val:>9,.2f} USDT  |  "
            f"Funding: ${funding_usdt:>9,.2f} USDT  |  "
            f"Toplam: ${total_assets:>9,.2f} USDT  |  "
            f"Getiri: {ret_color}{total_ret:+.2f}%{Style.RESET_ALL}"
            f"{risk_info}\n"
        )
    else:
        print(
            f"  Bakiye: ${trader.balance:>10,.2f} USDT  |  "
            f"Portföy: ${port_val:>10,.2f} USDT  |  "
            f"Getiri: {ret_color}{total_ret:+.2f}%{Style.RESET_ALL}"
            f"{risk_info}\n"
        )


def print_report(trader: PaperTrader, prices: dict):
    r = trader.performance_report(prices)
    print(f"\n{Fore.CYAN}══════════════ PERFORMANS RAPORU ══════════════{Style.RESET_ALL}")
    data = [
        ["Başlangıç Bakiyesi",       f"${r['initial_balance']:>12,.2f}"],
        ["Mevcut Bakiye",             f"${r['current_balance']:>12,.2f}"],
        ["Portföy Değeri",            f"${r['portfolio_value']:>12,.2f}"],
        ["Toplam Getiri",             f"{r['total_return_pct']:>+11.2f}%"],
        ["Gerçekleşen PnL",           f"${r['realized_pnl']:>+11,.2f}"],
        ["Gerçekleşmemiş PnL",        f"${r.get('unrealized_pnl', 0):>+11,.2f}"],
        ["Toplam İşlem",              f"{r['total_trades']:>12}"],
        ["Kazanan / Kaybeden",        f"{r['winning_trades']:>6} / {r['losing_trades']:<6}"],
        ["Kazanma Oranı",             f"{r['win_rate_pct']:>11.1f}%"],
        ["Profit Factor",             f"{r.get('profit_factor', 0):>12.2f}"],
        ["Expectancy",                f"${r.get('expectancy', 0):>+11,.2f}"],
        ["Max Drawdown",              f"{r.get('max_drawdown_pct', 0):>11.2f}%"],
        ["Toplam Komisyon",           f"${r.get('total_fees_paid', 0):>11,.3f}"],
        ["Açık Pozisyon",             f"{r['open_positions']:>12}"],
    ]
    print(tabulate(data, tablefmt="rounded_outline"))
    print()


# ═══════════════════════════════════════════════════════════════════════════════
# PERFORMANS ÖZETİ LOGLAMA
# ═══════════════════════════════════════════════════════════════════════════════

def log_performance_summary(db, risk_mgr=None) -> None:
    """
    Son 24 saatteki işlem istatistiklerini loglar.
    Sembol bazlı başarı oranları, cooldown durumları ve genel özet.
    Her 30 döngüde (≈30 dakika) çağrılır.
    """
    dsn = os.getenv("DATABASE_URL", "")
    if not dsn:
        return
    try:
        import psycopg2
        conn = psycopg2.connect(dsn)
        with conn.cursor() as cur:
            # Son 24 saat genel özet
            cur.execute("""
                SELECT
                    COUNT(*) AS total,
                    SUM(CASE WHEN pnl > 0 THEN 1 ELSE 0 END) AS wins,
                    SUM(CASE WHEN pnl <= 0 THEN 1 ELSE 0 END) AS losses,
                    ROUND(SUM(pnl)::numeric, 2) AS total_pnl,
                    ROUND(AVG(EXTRACT(EPOCH FROM (closed_at - opened_at))/60)::numeric, 1) AS avg_min
                FROM trades
                WHERE status='closed' AND mode='live'
                  AND closed_at >= NOW() - INTERVAL '24 hours'
            """)
            row = cur.fetchone()
            # Sembol bazlı özet
            cur.execute("""
                SELECT symbol,
                    COUNT(*) AS trades,
                    SUM(CASE WHEN pnl > 0 THEN 1 ELSE 0 END) AS wins,
                    ROUND(SUM(pnl)::numeric, 2) AS pnl
                FROM trades
                WHERE status='closed' AND mode='live'
                  AND closed_at >= NOW() - INTERVAL '24 hours'
                GROUP BY symbol ORDER BY trades DESC LIMIT 8
            """)
            sym_rows = cur.fetchall()
        conn.close()

        if row and row[0]:
            total, wins, losses, total_pnl, avg_min = row
            win_rate = (wins / total * 100) if total else 0
            sep = "─" * 55
            logger.info(f"\n{sep}")
            logger.info(f"  📊 SON 24 SAAT PERFORMANS ÖZETİ")
            logger.info(f"{sep}")
            logger.info(f"  Toplam: {total} işlem | Kazanan: {wins} | Kaybeden: {losses}")
            logger.info(f"  Başarı: %{win_rate:.1f} | Net PnL: ${total_pnl:+.2f} | Ort. süre: {avg_min:.1f} dk")
            if sym_rows:
                logger.info(f"  {'Sembol':<12} {'İşlem':>6} {'Kazanan':>8} {'Başarı%':>8} {'PnL':>10}")
                logger.info(f"  {'─'*12} {'─'*6} {'─'*8} {'─'*8} {'─'*10}")
                for s, t, w, p in sym_rows:
                    wr = (w / t * 100) if t else 0
                    flag = " ❌" if wr == 0 and t >= 3 else (" ⚠" if wr < 30 else "")
                    logger.info(f"  {s:<12} {t:>6} {w:>8} {wr:>7.1f}% {p:>+10.2f}{flag}")
            # Cooldown durumu
            if risk_mgr:
                sym_status = risk_mgr.get_symbol_status()
                blocked = {s: v for s, v in sym_status.items() if v["cooldown_active"]}
                if blocked:
                    logger.info(f"  Cooldown: {', '.join(blocked.keys())} geçici bloke")
                logger.info(
                    f"  Risk: ard arda kayıp={risk_mgr._consecutive_losses}"
                    f" | Savunma={'AKTİF' if risk_mgr.defense_mode else 'devre dışı'}"
                )
            logger.info(sep)
        else:
            logger.info("[PERF] Son 24 saatte kayıtlı işlem yok.")
    except Exception as e:
        logger.warning(f"[PERF] Özet alınamadı: {e}")


# ═══════════════════════════════════════════════════════════════════════════════
# LARGE LOT MODE — Risk/Ödül Kapısı
# ═══════════════════════════════════════════════════════════════════════════════

_QUALITY_RANK = {"C": 1, "B": 2, "B+": 3, "A": 4, "A+": 5}


def _calc_large_lot_gate(quality: str, regime: "str | None" = None) -> "tuple[float, float, float] | None":
    """
    Large Lot Mode kapısı.

    Koşullar:
      1. config.LARGE_LOT_MODE_ENABLED = True
      2. LIVE_TEST_MODE = False  (test modunda devre dışı)
      3. quality >= LARGE_LOT_MIN_QUALITY (B+ ve üstü, skor >= 80)
      4. regime LARGE_LOT_ALLOWED_REGIMES içinde olmalı (PATCH-2)
      5. expected_profit = notional × tp_pct >= LARGE_LOT_MIN_PROFIT_USDT

    Döndürür: (notional_usdt, stop_pct, tp_pct) veya None
      - notional_usdt : slot notional yerine kullanılacak nihai notional
      - stop_pct      : sabit stop-loss yüzdesi  (ör. 0.0125 = %1.25)
      - tp_pct        : sabit take-profit yüzdesi (ör. 0.05   = %5.00)

    Hesap özeti (10x kaldıraçla):
      B+  → notional=400 USDT  margin=40  risk=5 USDT  kâr=20 USDT  R/R=4:1
      A   → notional=500 USDT  margin=50  risk=6.25 USDT kâr=25 USDT R/R=4:1
      A+  → notional=500 USDT  margin=50  risk=6.25 USDT kâr=25 USDT R/R=4:1
    """
    # LIVE_TEST_MODE aktifken devre dışı
    if getattr(config, "LIVE_TEST_MODE", False):
        return None

    if not getattr(config, "LARGE_LOT_MODE_ENABLED", False):
        return None

    # ── PATCH-2: Rejim filtresi — large lot yalnızca güçlü rejimlerde ──────
    _ll_allowed = getattr(config, "LARGE_LOT_ALLOWED_REGIMES",
                          ["TRENDING_UP", "STRONG_UP", "BULL_TREND", "TRENDING", "BREAKOUT_UP"])
    if regime and regime.upper() not in [r.upper() for r in _ll_allowed]:
        logger.info(
            f"[LARGE LOT REGIME BLOCKED] Kalite={quality} ama rejim={regime} → "
            f"large lot yalnızca güçlü rejimlerde aktif "
            f"({', '.join(_ll_allowed)}). Standart slot kullanıldı."
        )
        return None

    min_quality  = getattr(config, "LARGE_LOT_MIN_QUALITY",       "B+")
    pref_quality = getattr(config, "LARGE_LOT_PREFER_QUALITY",    "A")
    stop_pct     = getattr(config, "LARGE_LOT_STOP_PCT",          0.0125)
    tp_pct       = getattr(config, "LARGE_LOT_TP_PCT",            0.05)
    risk_usdt    = getattr(config, "LARGE_LOT_RISK_USDT",         5.0)
    min_profit   = getattr(config, "LARGE_LOT_MIN_PROFIT_USDT",   20.0)
    min_notional = getattr(config, "LARGE_LOT_MIN_NOTIONAL",      400.0)
    std_notional = getattr(config, "LARGE_LOT_STANDARD_NOTIONAL", 500.0)

    # Kalite kapısı: min_quality'nin altındakiler reddedilir
    q_rank = _QUALITY_RANK.get(quality.upper() if quality else "B", 0)
    if q_rank < _QUALITY_RANK.get(min_quality, 3):
        # B+ kalite eski eşiği karşılıyor ama yeni A eşiğini karşılamıyorsa bildir
        if q_rank >= _QUALITY_RANK.get("B+", 3):
            logger.info(
                f"[LARGE LOT BLOCKED] Kalite={quality} → min kalite {min_quality} (skor≥85) "
                f"gerekli. B+ eşiği yeterli değil. Normal slot ile devam."
            )
        return None

    # Notional hesapla: 5 / 0.0125 = 400 USDT
    notional = max(risk_usdt / stop_pct, min_notional)

    # A ve A+ kalite: standart notional kullan (500 USDT)
    if q_rank >= _QUALITY_RANK.get(pref_quality, 4):
        notional = max(notional, std_notional)

    # Kâr kapısı: expected_profit >= min_profit
    expected_profit = notional * tp_pct
    if expected_profit < min_profit:
        return None

    return (notional, stop_pct, tp_pct)


# ═══════════════════════════════════════════════════════════════════════════════
# CANLI BAKİYE SENKRONİZASYONU
# ═══════════════════════════════════════════════════════════════════════════════

def _sync_live_balance(
    client,
    trader:    PaperTrader,
    db,
    mode:      str,
    day_start: float,
) -> float:
    """
    OKX'ten gerçek bakiyeyi çekip hem trader nesnesini hem de DB'yi günceller.
    Döndürür: güncel toplam portföy değeri (float)

    Portföy değeri = Kullanılabilir USDT + Açık pozisyonların teminatı + Gerçekleşmemiş PnL
    """
    from exchange.okx_live_client import OKXLiveClient
    if not isinstance(client, OKXLiveClient) or not client.is_authenticated():
        # Paper trading veya bağlantısız — mevcut değerleri kullan
        prices = {}
        return trader.portfolio_value(prices)

    try:
        # 1. Kullanılabilir USDT bakiyesi
        available_usdt = client.get_usdt_balance()

        # 2. Açık pozisyonlar (futures/swap) — SADECE BOT POZİSYONLARI
        # Manuel pozisyonların PnL/marjini kill-switch hesabına dahil EDİLMEZ
        positions = client.get_positions()

        # Manuel sembol kümesini trader.positions'tan al
        _manual_syms: set = {
            sym for sym, _p in trader.positions.items()
            if getattr(_p, 'is_manual', False)
        }

        # instId → symbol dönüşümü (OKX formatı: MON-USDT-SWAP → MONUSDT)
        def _inst_to_sym(inst: str) -> str:
            return inst.replace("-USDT-SWAP", "USDT").replace("-USDT", "USDT").replace("-", "").upper()

        bot_margin = sum(
            float(p.get("margin", 0)) for p in positions
            if _inst_to_sym(p.get("instId", "")) not in _manual_syms
        )
        bot_upnl = sum(
            float(p.get("pnl", 0)) for p in positions
            if _inst_to_sym(p.get("instId", "")) not in _manual_syms
        )

        # 3. Toplam portföy = kullanılabilir + BOT pozisyonlarının marjin + PnL
        # Manuel pozisyonlar (PUMP vb.) dahil edilmez — bot onları kontrol etmiyor
        total_portfolio = available_usdt + bot_margin + bot_upnl

        # 4. Trader nesnesini güncelle (risk motoru için)
        trader.balance        = total_portfolio if total_portfolio > 0 else available_usdt
        trader.available_usdt = available_usdt   # Emir boyutlandırmada serbest bakiye

        # 5. PnL hesapla
        initial = trader.initial_balance if trader.initial_balance > 0 else total_portfolio
        total_pnl = total_portfolio - initial
        daily_pnl = total_portfolio - day_start

        # 6. DB'ye yaz
        if db:
            db.write_balance(
                total_balance     = total_portfolio,
                available_balance = available_usdt,
                daily_pnl         = daily_pnl,
                total_pnl         = total_pnl,
                mode              = mode,
            )

        logger.debug(
            f"[CANLI] Bakiye: ${available_usdt:,.2f} USDT | "
            f"Pozisyon PnL: ${total_upnl:+,.2f} | "
            f"Toplam: ${total_portfolio:,.2f}"
        )
        return total_portfolio

    except Exception as e:
        logger.warning(f"Canlı bakiye senkronizasyon hatası: {e}")
        return trader.balance


# ═══════════════════════════════════════════════════════════════════════════════
# OKX → DB POZİSYON SYNC — Gerçek OKX Pozisyonlarını Panele Yansıt
# ═══════════════════════════════════════════════════════════════════════════════

# Toz pozisyon / hayalet önleyici: force-delete yapılan semboller tekrar sync'e alınmaz
_ghost_sync_blacklist: set = set()

# Toz pozisyon eşiği: bu USD değerinden küçük pozisyonlar sync'e alınmaz
_MIN_SYNC_NOTIONAL_USD = 0.5   # SUI gibi düşük değerli kontratlar ($0.88) geçebilsin

# OKX'te gerçekten açık olan semboller — PnL thread phantom döngüsünü önler.
# _sync_okx_positions_to_db her çalıştığında güncellenir.
# Boşken (henüz sync yapılmadı) PnL thread kısıtlama uygulamaz.
_okx_live_symbols: set = set()
_okx_sync_done: bool = False


def _sync_okx_positions_to_db(
    client,
    trader:    "PaperTrader",
    db,
    mode:      str,
    trade_ids: Dict[str, int],
    prices:    Dict[str, float],
    slot_mgr   = None,
    strategy   = None,
    closed_symbols_cooldown: Optional[Dict[str, float]] = None,
    trade_meta: Optional[Dict] = None,
    reporter_fn = None,
) -> None:
    """
    OKX'teki gerçek açık pozisyonları DB'ye ve trader.positions'a yazar.
    Her N loop iterasyonunda çağrılır — dashboard'un güncel kalmasını sağlar.

    Toz (dust) pozisyon koruması:
      - Notional değeri < _MIN_SYNC_NOTIONAL_USD olan pozisyonlar atlanır
      - _ghost_sync_blacklist'e alınan semboller kalıcı olarak atlanır

    Yanlış silme koruması:
      - get_positions() boş dönerse (API hatası) temizleme adımı atlanır
      - Silinen semboller için slot serbest bırakılır ve cooldown eklenir
    """
    from exchange.okx_live_client import OKXLiveClient
    if not isinstance(client, OKXLiveClient) or not client.is_authenticated():
        return
    if not db:
        return

    try:
        okx_positions = client.get_positions()   # [{"symbol","side","qty","entry_price","pnl","margin",...}]
    except Exception as e:
        logger.warning(f"[OKX SYNC] Pozisyon çekme hatası: {e}")
        return

    # DB'deki ghost blacklist kayıtlarını oku ve belleğe al
    try:
        _cur = db._exec(
            "SELECT message FROM logs WHERE message LIKE 'GHOST_BLACKLIST:%%'"
        )
        if _cur:
            _rows = []
            try:
                _rows = _cur.fetchall() or []
            except Exception:
                pass
            for _row in _rows:
                try:
                    _msg = _row[0] if _row else ""
                    if _msg and _msg.startswith("GHOST_BLACKLIST:"):
                        _gs = _msg.split(":", 1)[1].strip()
                        if _gs:
                            _ghost_sync_blacklist.add(_gs)
                except Exception:
                    pass
    except Exception as _ge:
        logger.debug(f"[OKX SYNC] Ghost blacklist DB okuma (önemsiz): {_ge}")

    okx_symbols: set = set()

    for p in okx_positions:
        raw_symbol  = p.get("symbol", "")
        if not raw_symbol:
            continue
        # OKX SWAP formatını bot iç formatına dönüştür:
        # BTC-USDT-SWAP → BTC-USDT → BTCUSDT  (bot içi hep tiresiz)
        _s = raw_symbol[:-5] if raw_symbol.endswith("-SWAP") else raw_symbol
        symbol = _s.replace("-", "")  # BTC-USDT → BTCUSDT

        # Ghost blacklist kontrolü — force-delete yapılan sembolleri atla
        if symbol in _ghost_sync_blacklist:
            logger.debug(f"[OKX SYNC] {symbol} ghost blacklist'te — atlandı")
            continue

        side        = p.get("side", "long")       # "long" / "short"
        qty         = float(p.get("qty", 0))
        entry_price = float(p.get("entry_price", 0))
        pnl         = float(p.get("pnl", 0))
        margin      = float(p.get("margin", 0))

        if qty <= 0 or entry_price <= 0:
            continue

        # Toz (dust) pozisyon filtresi — minimum notional değeri kontrol et
        _notional = qty * entry_price
        if _notional < _MIN_SYNC_NOTIONAL_USD:
            logger.warning(
                f"[OKX SYNC] {symbol} toz pozisyon atlandı: "
                f"qty={qty:.8f} × fiyat={entry_price:.4f} = ${_notional:.6f} "
                f"(min=${_MIN_SYNC_NOTIONAL_USD}). OKX'te kapatılamayan dust."
            )
            # Eğer trader'da varsa oradan da çıkar
            if symbol in trader.positions:
                trader.positions.pop(symbol, None)
                try:
                    db.delete_position(symbol)
                except Exception:
                    pass
            continue

        okx_symbols.add(symbol)
        current_price = prices.get(symbol, entry_price)
        pnl_pct = (pnl / (margin * max(1, config.LEVERAGE))) * 100 if margin > 0 else 0

        # DB'ye yaz
        trade_id = trade_ids.get(symbol)
        try:
            db.upsert_position(
                symbol        = symbol,
                entry_price   = entry_price,
                current_price = current_price,
                quantity      = qty,
                pnl           = pnl,
                pnl_pct       = pnl_pct,
                stop_loss     = trader.positions[symbol].stop_loss if symbol in trader.positions else 0.0,
                take_profit   = trader.positions[symbol].take_profit if symbol in trader.positions else 0.0,
                strategy_name = trader.positions[symbol].strategy_name if symbol in trader.positions else "Signal Engine",
                trade_id      = trade_id,
                mode          = mode,
                side          = side,
                leverage      = int(config.LEVERAGE),
            )
        except Exception as e:
            logger.warning(f"[OKX SYNC] DB upsert hatası ({symbol}): {e}")

        # trader.positions'ta yoksa ekle (bot restart sonrası recovery)
        if symbol not in trader.positions:
            try:
                from trader.paper_trader import PaperTrader as _PT
                if isinstance(trader, _PT):
                    # Varsayılan SL/TP: config yüzdelerine göre hesapla
                    _sl_pct = getattr(config, "STOP_LOSS_PCT", 0.02)
                    _tp_pct = getattr(config, "TAKE_PROFIT_PCT", 0.04)
                    if side == "short":
                        _default_sl = entry_price * (1 + _sl_pct)  # SHORT: SL = giriş üstü
                        _default_tp = entry_price * (1 - _tp_pct)  # SHORT: TP = giriş altı
                        trader.open_short_position(
                            symbol            = symbol,
                            price             = entry_price,
                            quantity_override = qty,
                            stop_loss         = _default_sl,
                            take_profit       = _default_tp,
                            is_live_tracking  = True,
                        )
                    else:
                        _default_sl = entry_price * (1 - _sl_pct)  # LONG: SL = giriş altı
                        _default_tp = entry_price * (1 + _tp_pct)  # LONG: TP = giriş üstü
                        trader.open_position(
                            symbol            = symbol,
                            price             = entry_price,
                            quantity_override = qty,
                            stop_loss         = _default_sl,
                            take_profit       = _default_tp,
                            is_live_tracking  = True,
                        )
                    logger.info(
                        f"[OKX SYNC] {symbol} pozisyonu trader'a eklendi "
                        f"({side}, qty={qty:.4f}, SL={_default_sl:.4f}, TP={_default_tp:.4f})"
                    )

                    # ── Akıllı Zaman Bazlı Çıkış: Recovery pozisyona profil uygula ──
                    # open_position/open_short_position max_bars=0 ile oluşturur.
                    # Profilsiz kalırsa eski 6-mum fallback devreye girer.
                    # Çözüm: profil uygula, ardından large/small lot max_bars'ı set et.
                    try:
                        from bots.bot_profiles import get_profile as _sync_get_prof
                        _sync_pos = trader.positions.get(symbol)
                        if _sync_pos:
                            # Side'a göre doğru profili seç
                            _sync_prof_name = "Pullback Short" if side == "short" else "Pullback Long"
                            _sync_prof = _sync_get_prof(_sync_prof_name)
                            _sync_prof.apply_to_position(_sync_pos)
                            # Large lot tespiti: notional >= LARGE_LOT_MIN_NOTIONAL
                            _sync_notional = qty * entry_price
                            _ll_min        = getattr(config, "LARGE_LOT_MIN_NOTIONAL", 400.0)
                            _sync_is_ll    = _sync_notional >= _ll_min
                            if _sync_is_ll:
                                _sync_max_bars = max(
                                    _sync_prof.max_bars,
                                    getattr(config, "SMART_EXIT_LARGE_LOT_MAX_BARS", 10),
                                )
                                _sync_pos.max_bars = _sync_max_bars
                            # else: profil değeri korunur
                            _sync_pos.is_large_lot = _sync_is_ll
                            # Bot'un açmadığı pozisyonları manuel olarak işaretle
                            _sync_pos.is_manual = True
                            logger.info(
                                f"[OKX SYNC] {symbol} profil uygulandı (recovery) → "
                                f"MaxBars:{_sync_pos.max_bars} "
                                f"({'large lot' if _sync_is_ll else 'small lot'}, "
                                f"notional=${_sync_notional:.1f}) | "
                                f"[MANUEL] Bot yönetmeyecek, sadece izleyecek"
                            )
                    except Exception as _spe:
                        logger.debug(f"[OKX SYNC] {symbol} profil uygulama hatası (önemsiz): {_spe}")

            except Exception as e:
                logger.warning(f"[OKX SYNC] trader pozisyon ekleme hatası ({symbol}): {e}")

    # OKX'te gerçekten açık olan semboller kümesini güncelle (PnL thread için)
    global _okx_live_symbols, _okx_sync_done
    _okx_live_symbols = set(okx_symbols)
    _okx_sync_done = True

    # DB'de olup OKX'te olmayan pozisyonları temizle
    # KORUMA: OKX boş liste döndürdüyse (API hatası/geçici kesinti) temizleme atlanır.
    # Yalnızca OKX en az 1 pozisyon döndürdüğünde eksik olanlar silinir.
    if len(okx_symbols) == 0 and len(trader.positions) > 0:
        logger.warning(
            f"[OKX SYNC] OKX 0 pozisyon döndürdü ama yerel {len(trader.positions)} pozisyon var — "
            f"API hatası olabilir, temizleme atlandı."
        )
    else:
        import time as _sync_time
        for symbol in list(trader.positions.keys()):
            if symbol not in okx_symbols:
                logger.info(f"[OKX SYNC] {symbol} OKX'te yok — DB ve trader'dan siliniyor")
                # Rapor için pozisyon snapshot'ını ÖNCE al (pop'dan önce)
                _sync_pos_snap = trader.positions.get(symbol)
                _sync_trade_id = trade_ids.pop(symbol, None)
                try:
                    db.delete_position(symbol)
                except Exception:
                    pass
                trader.positions.pop(symbol, None)
                # Slot serbest bırak (SlotManager tutarlılığı)
                if slot_mgr is not None:
                    try:
                        slot_mgr.release_slot(symbol)
                    except Exception:
                        pass
                # Strateji cooldown tetikle (hemen yeniden girişi engelle)
                if strategy is not None:
                    try:
                        strategy.on_trade_closed(symbol, pnl=0.0)
                    except Exception:
                        pass
                # PATCH-4: Genel re-entry cooldown — config'den alınan süre
                if closed_symbols_cooldown is not None:
                    _sync_reentry_cd = getattr(config, "SAME_COIN_REENTRY_COOLDOWN_SEC", 600)
                    closed_symbols_cooldown[symbol] = _sync_time.time() + _sync_reentry_cd
                    logger.info(f"[OKX SYNC] {symbol} için {_sync_reentry_cd//60}dk yeniden giriş kilidi eklendi")

                # ── Standart Canlı İşlem Raporu (OKX Sync kapanış) ──────────
                if reporter_fn is not None and _sync_pos_snap is not None:
                    try:
                        from datetime import datetime as _dt, timezone as _tz
                        _sm_meta   = (trade_meta or {}).pop(symbol, {})
                        _sm_price  = prices.get(symbol, _sync_pos_snap.entry_price)
                        _sm_lev    = getattr(_sync_pos_snap, "leverage", 10) or 10
                        _sm_margin = _sync_pos_snap.margin if _sync_pos_snap.margin > 0 else (_sync_pos_snap.quantity * _sync_pos_snap.entry_price / _sm_lev)
                        _sm_fee    = getattr(_sync_pos_snap, "entry_fee", 0.0) or 0.0
                        _sm_pnl    = (_sm_price - _sync_pos_snap.entry_price) * _sync_pos_snap.quantity if _sync_pos_snap.side == "long" else (_sync_pos_snap.entry_price - _sm_price) * _sync_pos_snap.quantity
                        _sm_cost   = _sync_pos_snap.quantity * _sync_pos_snap.entry_price
                        _sm_pnl_pct = (_sm_pnl / _sm_cost * 100) if _sm_cost > 0 else 0
                        _sm_risk   = abs(_sync_pos_snap.entry_price - _sync_pos_snap.stop_loss)
                        _sm_tp2    = (_sync_pos_snap.entry_price + _sm_risk * 3.6) if _sm_risk > 0 and _sync_pos_snap.side == "long" else None
                        reporter_fn(
                            symbol               = symbol,
                            strategy_name        = _sync_pos_snap.strategy_name or "Pullback Long",
                            side                 = _sync_pos_snap.side,
                            trade_id             = _sync_trade_id,
                            mode                 = mode,
                            paper_trading        = False,
                            opened_at            = _sm_meta.get("opened_at"),
                            closed_at            = _dt.now(_tz.utc),
                            regime               = _sm_meta.get("regime"),
                            signal_score         = _sm_meta.get("signal_score"),
                            signal_score_max     = _sm_meta.get("signal_score_max", 10.0),
                            norm_score           = _sm_meta.get("norm_score"),
                            quality              = _sm_meta.get("quality"),
                            slot_id              = _sm_meta.get("slot_id"),
                            slot_notional        = _sm_meta.get("slot_notional"),
                            leverage             = _sm_lev,
                            sent_qty             = _sync_pos_snap.quantity,
                            filled_qty           = _sm_meta.get("filled_qty") or _sync_pos_snap.quantity,
                            filled_price         = _sm_meta.get("filled_price") or _sync_pos_snap.entry_price,
                            filled_notional      = _sm_meta.get("actual_notional") or (_sync_pos_snap.quantity * _sync_pos_snap.entry_price),
                            filled_margin        = _sm_margin,
                            exchange_order_id    = _sm_meta.get("exchange_order_id"),
                            entry_price          = _sync_pos_snap.entry_price,
                            stop_loss            = _sync_pos_snap.stop_loss,
                            take_profit          = _sync_pos_snap.take_profit,
                            tp2_price            = _sm_tp2,
                            break_even_trigger   = getattr(_sync_pos_snap, "break_even_trigger_price", 0) or None,
                            trailing_stop_pct    = getattr(_sync_pos_snap, "trailing_stop_pct", 0) or None,
                            min_profit_bar       = getattr(_sync_pos_snap, "min_profit_bar", 0) or None,
                            max_bars             = getattr(_sync_pos_snap, "max_bars", 0) or None,
                            exit_price           = _sm_price,
                            exit_reason          = "okx_sync_closed",
                            gross_pnl            = _sm_pnl + _sm_fee,
                            commission           = _sm_fee,
                            net_pnl              = _sm_pnl,
                            pnl_pct              = _sm_pnl_pct,
                            candles_held         = getattr(_sync_pos_snap, "candles_held", 0),
                            okx_open_confirmed   = _sm_meta.get("okx_open_confirmed", True),
                            okx_close_confirmed  = True,
                            db_recorded          = db is not None and _sync_trade_id is not None,
                            on_trade_closed_ran  = strategy is not None,
                            cooldown_set         = closed_symbols_cooldown is not None,
                            risk_mgr_updated     = False,
                            is_adopted           = True,  # PATCH-5: OKX sync → organik değil
                        )
                    except Exception as _sync_rpt_err:
                        logger.warning(f"[RAPOR] OKX sync kapanış raporu hatası: {_sync_rpt_err}")


# ═══════════════════════════════════════════════════════════════════════════════
# POZİSYON ROTASYONU — Yüksek Puanlı Sinyal İçin En Zayıf Pozisyonu Kapat
# ═══════════════════════════════════════════════════════════════════════════════

def _try_rotate_position(
    trader,
    exe,
    db,
    trade_ids: Dict[str, int],
    new_symbol: str,
    new_score:  float,
    prices:     Dict[str, float],
    mode:       str,
    logger_ref,
) -> bool:
    """
    Yeni yüksek puanlı sinyal geldiğinde en kötü performanslı pozisyonu kapat.
    Böylece limit dolu olsa bile daha iyi fırsatlara yer açılır.

    Kural:
      - En az -%1 zarardaki bir pozisyon olmalı
      - Yeni sinyalin skoru ROTATION_MIN_SCORE üzerinde olmalı
    Returns: True → rotasyon yapıldı (yeni sinyal açılabilir)
    """
    if not trader.positions:
        return False

    worst_symbol: Optional[str] = None
    worst_pnl_pct: float = -1.0  # sadece -%1 üzeri zarar olanları seç

    for sym, pos in list(trader.positions.items()):
        cur = prices.get(sym, 0.0)
        if cur <= 0 or pos.entry_price <= 0:
            continue
        if pos.side == "long":
            pnl_pct = (cur - pos.entry_price) / pos.entry_price * 100.0
        else:
            pnl_pct = (pos.entry_price - cur) / pos.entry_price * 100.0

        if pnl_pct < worst_pnl_pct:
            worst_pnl_pct = pnl_pct
            worst_symbol  = sym

    if worst_symbol is None:
        logger_ref.debug(f"[ROTASYON] {new_symbol} için yer açılamadı — tüm pozisyonlar ≥ -%1")
        return False

    close_price = prices.get(worst_symbol, 0.0)
    if close_price <= 0:
        return False

    pos_snap  = trader.positions[worst_symbol]
    logger_ref.info(
        f"[ROTASYON] {worst_symbol} kapatılıyor "
        f"(PnL: {worst_pnl_pct:.2f}%) → skor {new_score:.0f} olan {new_symbol} için yer açılıyor"
    )

    # Paper trader pozisyonu kapat
    pnl = trader.close_position(worst_symbol, close_price, reason="rotasyon")
    if pnl is None:
        return False

    # Canlı modda OKX'e gerçek kapatma emri gönder
    if not config.PAPER_TRADING:
        exe.submit_force_close(
            symbol        = worst_symbol,
            side          = pos_snap.side,
            quantity      = pos_snap.quantity,
            price         = close_price,
            reason        = "rotasyon",
            strategy_name = pos_snap.strategy_name,
        )

    # DB güncelle
    trade_id = trade_ids.pop(worst_symbol, None)
    if db:
        cost      = pos_snap.quantity * pos_snap.entry_price
        pnl_pct_v = (pnl / cost) * 100.0 if cost > 0 else 0.0
        if trade_id:
            db.close_trade(trade_id, close_price, pnl, pnl_pct_v, "rotasyon")
        db.delete_position(worst_symbol)

    return True


# ═══════════════════════════════════════════════════════════════════════════════
# DB POZİSYON SAHİPLENME — Manuel Açılan Pozisyonları Bota Tanıt
# ═══════════════════════════════════════════════════════════════════════════════

def _adopt_db_positions(
    db,
    trader:    PaperTrader,
    trade_ids: Dict[str, int],
    client=None,
    live_mode: bool = False,
) -> int:
    """
    Positions tablosundaki pozisyonları okur ve bota tanıtır.

    LIVE modda: OKX'teki pozisyonlar DB ile çift yönlü senkronize edilir.
      - OKX'te VAR, DB'de YOK → DB'ye yaz ve bota tanıt (restart recovery)
      - DB'de VAR, OKX'te YOK → phantom kayıt, atla (bota alma)
    PAPER modda: DB'deki tüm pozisyonları doğrudan bota tanıt.

    Döndürür: Yeni sahiplenilen pozisyon sayısı.
    """
    if not db:
        return 0

    try:
        db_positions = db.load_positions()
    except Exception as e:
        logger.warning(f"DB pozisyon yüklenemedi: {e}")
        return 0

    # LIVE modda OKX'teki gerçek pozisyonları al
    okx_raw_positions: list = []
    okx_symbols: set = set()
    if live_mode and client and client.is_authenticated():
        try:
            okx_raw_positions = client.get_positions() or []
            for p in okx_raw_positions:
                # get_positions() "symbol" anahtarını kullanır (instId içerir)
                raw = p.get("symbol", "")
                # BTC-USDT-SWAP → BTCUSDT  (bot iç formatı)
                _stripped = raw[:-5] if raw.endswith("-SWAP") else raw
                sym = _stripped.replace("-", "")
                if sym:
                    okx_symbols.add(sym.upper())
        except Exception as e:
            logger.warning(f"[ADOPT] OKX pozisyon listesi alınamadı: {e}")

    # DB pozisyon setini oluştur (hızlı lookup için)
    db_symbols = {row["symbol"] for row in db_positions}

    # ── Phantom pozisyon tespiti ───────────────────────────────────────────────
    if live_mode and db_positions:
        phantom_symbols = [row["symbol"] for row in db_positions if row["symbol"] not in okx_symbols]
        if phantom_symbols:
            logger.warning(
                f"[PHANTOM] DB'de açık görünen ama OKX'te OLMAYAN pozisyonlar "
                f"({len(phantom_symbols)} adet): {phantom_symbols} — "
                f"Bu kayıtlar atlanacak (phantom / stale DB kaydı)."
            )
        real_symbols = [row["symbol"] for row in db_positions if row["symbol"] in okx_symbols]
        if real_symbols:
            logger.info(
                f"[PHANTOM] DB ↔ OKX eşleşen pozisyonlar "
                f"({len(real_symbols)} adet): {real_symbols}"
            )

    adopted = 0
    from trader.paper_trader import Position

    # ── Adım 1: DB pozisyonlarını bota tanıt (OKX doğrulaması ile) ──────────
    for row in db_positions:
        symbol = row["symbol"]
        if symbol in trader.positions:
            if row["trade_id"] and symbol not in trade_ids:
                trade_ids[symbol] = row["trade_id"]
            elif not row["trade_id"] and symbol not in trade_ids and db:
                try:
                    _existing_row = db.get_open_trade(symbol)
                    if _existing_row:
                        trade_ids[symbol] = _existing_row["id"]
                        trader.positions[symbol].trade_id = _existing_row["id"]
                        if not getattr(trader.positions[symbol], "strategy_name", "") or \
                                trader.positions[symbol].strategy_name == "signal_engine":
                            trader.positions[symbol].strategy_name = _existing_row["strategy_name"] or trader.positions[symbol].strategy_name
                except Exception:
                    pass
            continue

        # LIVE modda: OKX'te yoksa phantom kayıt — atla
        if live_mode and symbol not in okx_symbols:
            logger.debug(f"[ADOPT] SKIP {symbol}: OKX'te pozisyon yok (phantom DB kaydı)")
            continue

        # trade_id veya strategy_name positions tablosunda eksikse trades tablosundan doldur
        _adopt_trade_id     = row["trade_id"]
        _adopt_strategy     = row["strategy_name"] or ""
        if not _adopt_trade_id and db:
            try:
                _open_row = db.get_open_trade(symbol)
                if _open_row:
                    _adopt_trade_id = _open_row["id"]
                    if not _adopt_strategy or _adopt_strategy == "signal_engine":
                        _adopt_strategy = _open_row["strategy_name"] or _adopt_strategy
                    logger.info(
                        f"[ADOPT] {symbol}: positions.trade_id eksikti → "
                        f"trades tablosundan kurtarıldı (id={_adopt_trade_id}, strateji={_adopt_strategy!r})"
                    )
            except Exception as _ae:
                logger.debug(f"[ADOPT] {symbol} trade_id kurtarma hatası: {_ae}")

        pos = Position(
            symbol        = symbol,
            quantity      = row["quantity"],
            entry_price   = row["entry_price"],
            raw_price     = row["entry_price"],
            side          = row["side"] or "long",
            stop_loss     = row["stop_loss"],
            take_profit   = row["take_profit"],
            strategy_name = _adopt_strategy,
            trade_id      = _adopt_trade_id,
            live_tracking = True,
        )
        # Pozisyona profil uygula (max_bars ve min_profit_bar için)
        # Böylece adopted pozisyonlar da yeni akıllı zaman bazlı çıkış mantığından yararlanır.
        try:
            from bots.bot_profiles import get_profile as _get_prof
            _adopt_side = row.get("side", "long")
            # Side'a göre doğru profili seç — SHORT pozisyonlara "Pullback Short" uygula
            if _adopt_side == "short":
                _adopt_prof_name = "Pullback Short"
            else:
                _adopt_prof_name = _adopt_strategy  # "Pullback Long" veya başka strateji adı
            _adopt_prof = _get_prof(_adopt_prof_name)
            _adopt_prof.apply_to_position(pos)
            # max_bars: profil değeri korunur (apply_to_position zaten set etti)
        except Exception:
            pass

        # Manuel pozisyon tespiti: trade_id yoksa VE notional >= büyük lot eşiği
        # Bot her zaman trade_id ile kaydeder; büyük notional'lı adsız pozisyon = kullanıcı açtı
        _adopt_notional = pos.quantity * pos.entry_price
        _ll_threshold   = getattr(config, "LARGE_LOT_MIN_NOTIONAL", 400.0)
        if not _adopt_trade_id and _adopt_notional >= _ll_threshold:
            pos.is_manual = True

        trader.positions[symbol] = pos
        if _adopt_trade_id:
            trade_ids[symbol] = _adopt_trade_id

        _manual_tag = " [MANUEL — bot yönetmeyecek]" if pos.is_manual else ""
        logger.info(
            f"[ADOPT] DB'den pozisyon sahiplenildi: {symbol} {pos.side.upper()} "
            f"| Giriş: ${pos.entry_price:,.4f} | Miktar: {pos.quantity:.6f} "
            f"| trade_id={_adopt_trade_id} | strateji={_adopt_strategy!r}{_manual_tag}"
        )
        adopted += 1

    # ── Adım 2: OKX'te var, DB'de yok → kurtarma (restart recovery) ────────
    if live_mode and okx_raw_positions:
        for p in okx_raw_positions:
            try:
                inst = p.get("instId", "")
                sym = inst.replace("-USDT-SWAP", "USDT").replace("-USDT", "USDT").replace("-", "").upper()

                if sym in db_symbols or sym in trader.positions:
                    continue  # Zaten var

                pos_side_raw = p.get("posSide", "")  # "long" / "short" / "net"
                side = "short" if pos_side_raw == "short" else "long"
                avg_px      = float(p.get("avgPx", 0) or 0)
                contracts   = abs(float(p.get("pos", 0) or 0))
                liq_px      = float(p.get("liqPx", 0) or 0)
                upl         = float(p.get("upl", 0) or 0)

                # OKX pos = kontrat sayısı (ör. BNB'de ctVal=0.01 → 20 kontrat = 0.20 BNB).
                # notionalUsd / avgPx ile gerçek coin miktarına dönüştür.
                notional_usd = abs(float(p.get("notionalUsd", 0) or 0))
                if avg_px > 0 and notional_usd > 0:
                    pos_qty = notional_usd / avg_px  # gerçek coin miktarı
                else:
                    pos_qty = contracts  # fallback

                if avg_px <= 0 or pos_qty <= 0:
                    continue

                pos = Position(
                    symbol        = sym,
                    quantity      = pos_qty,
                    entry_price   = avg_px,
                    raw_price     = avg_px,
                    side          = side,
                    stop_loss     = liq_px if liq_px > 0 else 0.0,
                    take_profit   = 0.0,
                    live_tracking = True,
                )
                trader.positions[sym] = pos

                # DB'ye yaz (bir sonraki senkronizasyon için)
                db.upsert_position(
                    symbol        = sym,
                    entry_price   = avg_px,
                    current_price = avg_px,
                    quantity      = pos_qty,
                    side          = side,
                    pnl           = upl,
                    pnl_pct       = 0.0,
                    stop_loss     = pos.stop_loss,
                    take_profit   = 0.0,
                    leverage      = int(p.get("lever", 5) or 5),
                    strategy_name = "RECOVERED",
                    trade_id      = None,
                )

                logger.info(
                    f"[ADOPT] OKX→DB KURTARILDI: {sym} {side.upper()} "
                    f"| Giriş: ${avg_px:,.4f} | Miktar: {pos_qty:.6f} | UPL: ${upl:.2f}"
                )
                adopted += 1
            except Exception as e:
                logger.warning(f"[ADOPT] OKX pozisyon kurtarma hatası ({p}): {e}")

    if adopted:
        logger.info(f"[ADOPT] Toplam {adopted} yeni pozisyon bota eklendi.")
    return adopted


# ═══════════════════════════════════════════════════════════════════════════════
# ANA DÖNGÜ
# ═══════════════════════════════════════════════════════════════════════════════

def run_loop(
    client,
    mde:      MarketDataEngine,
    trader:   PaperTrader,
    strategy,
    risk_mgr: RiskManager,
    pos_sizer: PositionSizer,
    exe:      ExecutionEngine,
    db,
    once:     bool = False,
    slot_mgr: "SlotManager" = None,
):
    mode = "paper" if config.PAPER_TRADING else "live"

    # Rejim filtresi
    regime_filter = None
    if getattr(config, "REGIME_ENABLED", True):
        regime_filter = MarketRegimeFilter(
            trend_strong_adx  = getattr(config, "REGIME_TREND_ADX", 22.0),
            high_vol_threshold = getattr(config, "REGIME_HIGH_VOL_RATIO", 0.04),
            low_vol_threshold  = getattr(config, "REGIME_LOW_VOL_RATIO", 0.005),
            min_volume_ratio   = getattr(config, "REGIME_MIN_VOL_RATIO", 0.35),
        )
        logger.info("Piyasa rejim filtresi aktif")

    # ── Market Scanner (Coin Seçim Motoru) ────────────────────────────────────
    scanner = None
    if getattr(config, "SCANNER_ENABLED", True):
        from engine.market_scanner import MarketScanner
        scanner = MarketScanner(client, config)
        logger.info(
            f"[SCAN] Market scanner aktif | "
            f"Shortlist boyutu: {getattr(config, 'SCANNER_SHORTLIST_SIZE', 12)} | "
            f"Min hacim: ${getattr(config, 'SCANNER_MIN_VOLUME_24H', 5_000_000):,}"
        )

    # ── Momentum Scanner (Momentum Coin Seçim Motoru) ─────────────────────────
    momentum_scanner = None
    if getattr(config, "MOMENTUM_SCANNER_ENABLED", True):
        from engine.momentum_scanner import MomentumScanner
        momentum_scanner = MomentumScanner(client, config)
        logger.info(
            f"[MSCAN] Momentum scanner aktif | "
            f"Shortlist boyutu: {getattr(config, 'MOMENTUM_SHORTLIST_SIZE', 10)} | "
            f"Min hacim: ${getattr(config, 'MOMENTUM_MIN_VOLUME_24H', 10_000_000):,}"
        )

    is_signal_engine = isinstance(strategy, SignalEngine)
    is_pullback      = isinstance(strategy, PullbackLongStrategy)

    # Pullback Short — ikincil strateji (feature flag ile açılır/kapanır)
    _short_strategy_enabled = getattr(config, "USE_PULLBACK_SHORT_STRATEGY", False)
    short_strategy: Optional["PullbackShortStrategy"] = None
    if _short_strategy_enabled:
        short_strategy = PullbackShortStrategy(
            min_score=getattr(config, "PULLBACK_SHORT_MIN_SCORE", 7),
        )
        logger.info(
            f"[SHORT] Pullback Short stratejisi aktif | "
            f"Min puan: {short_strategy.min_score} | "
            f"Aktif rejimler: {getattr(config, 'PULLBACK_SHORT_ACTIVE_REGIMES', ['BEAR_TREND'])}"
        )

    # Pullback strateji için son sinyal sonucu (SL/TP override'ı için)
    _pullback_result = None

    # Market-wide rejim takibi (BEAR_TREND, BULL_TREND, MIXED vb.)
    # Her scan_result güncellemesinde set edilir — döngüler boyunca persist
    _current_market_regime: str = "UNKNOWN"

    logger.info(
        f"Bot başlatıldı — Strateji: {strategy.name} | "
        f"Çiftler: {mde.symbols} | Mod: {mode.upper()}"
    )
    # Canlı modda gerçek OKX bakiyesini başlangıç bakiyesi olarak kullan
    if not config.PAPER_TRADING:
        from exchange.okx_live_client import OKXLiveClient
        if isinstance(client, OKXLiveClient) and client.is_authenticated():
            free_bal  = client.get_usdt_balance()
            total_eq  = client.get_total_equity()   # margin'deki pozisyonlar dahil (bilgi)
            # Kill-switch referansı için SADECE serbest bakiyeyi kullan.
            # Manuel pozisyonların (PUMP vb.) kayıpları bot kill-switch'ini etkilemez.
            reference = free_bal if free_bal > 0 else total_eq
            if reference > 0:
                trader.balance         = reference   # portfolio_value için doğru referans
                trader.initial_balance = reference
                trader.available_usdt  = free_bal    # İlk iterasyonda doğru serbest bakiye
                logger.info(
                    f"[CANLI] OKX bakiyesi yüklendi: "
                    f"Serbest=${free_bal:,.2f} | Toplam (equity)=${total_eq:,.2f} USDT"
                )

    logger.info(f"Başlangıç bakiyesi: ${trader.initial_balance:,.2f} USDT")

    if db:
        db.set_bot_running(True)
        db.sync_initial_balance(trader.initial_balance)
        db.write_log(
            "info", "system",
            f"Bot başlatıldı — Strateji: {strategy.name}",
            f"Çiftler: {mde.symbols} | Bakiye: ${trader.initial_balance:,.2f}"
        )
        db.write_balance(trader.initial_balance, trader.initial_balance, 0.0, 0.0, mode)

    # trade_id takibi: symbol → DB trade_id
    trade_ids: Dict[str, int] = {}

    # ── Trade Reporter için açılış metadata'sı (symbol → dict) ──────────────
    _trade_meta: Dict[str, dict] = {}

    # ── Trade Reporter import ────────────────────────────────────────────────
    from engine.trade_reporter import generate_trade_report as _gen_trade_report

    # Günlük PnL takibi
    day_start_balance = trader.initial_balance
    current_day       = date.today()
    risk_mgr.set_day_start_value(day_start_balance)

    iteration = 0
    # Yeniden giriş kilidi: {symbol → unlock_timestamp}
    # OKX sync veya SL/TP kapatmalarından sonra 5 dk giriş engeli
    _closed_symbols_cooldown: Dict[str, float] = {}

    # B+ kalite hacimsiz "ikinci teyit" bekleyenleri tut: {symbol → first_seen_timestamp}
    # Bir sonraki scan aynı sinyali tekrar verirse açılmasına izin verilir
    _wv_pending_signals: Dict[str, float] = {}

    # Yön takibi: {symbol → ("long"/"short", close_timestamp)}
    # Yön değiştirme engelinde kullanılır
    _last_trade_direction: Dict[str, tuple] = {}

    try:
        while True:
            iteration += 1
            logger.debug(f"─── Döngü #{iteration} ───")

            # Her 5 döngüde DB'den mod kontrolü (UI değişikliklerini yakalar)
            if iteration % 5 == 0:
                old_paper = config.PAPER_TRADING
                load_mode_from_db(risk_mgr)   # risk_mgr parametreleri de eş zamanlı güncellenir
                if old_paper != config.PAPER_TRADING:
                    mode = "paper" if config.PAPER_TRADING else "live"
                    mode_str = "PAPER" if config.PAPER_TRADING else "🔴 LIVE"
                    logger.info(f"[MOD DEĞİŞİKLİĞİ] Trading modu değişti: {mode_str}")

                    # Execution engine'i güncelle — paper↔live geçişte kritik
                    if not config.PAPER_TRADING and client.is_authenticated():
                        exe.update_live_mode(live_mode=True, client=client)
                        _free = client.get_usdt_balance()
                        _total = client.get_total_equity()
                        _ref = _total if _total > 0 else _free
                        if _ref > 0:
                            trader.balance         = _ref
                            trader.initial_balance = _ref
                            day_start_balance      = _ref
                            risk_mgr.set_day_start_value(day_start_balance)
                            risk_mgr.reset_kill_switch()
                            logger.info(
                                f"[CANLI] Kill-switch sıfırlandı. "
                                f"Günlük başlangıç bakiyesi: ${_ref:,.2f} USDT "
                                f"(serbest=${_free:,.2f})"
                            )
                    else:
                        exe.update_live_mode(live_mode=False)

            # Gün değiştiyse sıfırla
            today = date.today()
            if today != current_day:
                if not config.PAPER_TRADING:
                    _total = client.get_total_equity() if client.is_authenticated() else 0
                    day_start_balance = _total if _total > 0 else (client.get_usdt_balance() if client.is_authenticated() else trader.balance)
                else:
                    prices = mde.get_all_prices()
                    day_start_balance = trader.portfolio_value(prices)
                current_day = today
                risk_mgr.set_day_start_value(day_start_balance)

            # ── -1. Performans Özeti (her 30 döngü ≈ 30 dk) ────────────────────
            if iteration % 30 == 0:
                log_performance_summary(db, risk_mgr)

            # ── Funding bakiyesi güncelle (her 60 döngü ≈ 60 dk) ───────────────
            if iteration % 60 == 0 and not config.PAPER_TRADING:
                try:
                    global _funding_usdt
                    _fund_bal = client.get_funding_balance() if client.is_authenticated() else {}
                    _funding_usdt = _fund_bal.get("USDT", {}).get("free", 0.0) if _fund_bal else 0.0
                except Exception:
                    pass

            # ── 0. Market Scanner — Coin Shortlist Güncelle ────────────────────
            scan_interval = getattr(config, "SCANNER_INTERVAL_LOOPS", 20)
            if scanner and (iteration == 1 or iteration % scan_interval == 0):
                try:
                    scan_result = scanner.scan()
                    if scan_result.shortlist_symbols:
                        # Açık pozisyonların sembollerini her zaman koru
                        active = set(trader.positions.keys())
                        merged = list(dict.fromkeys(
                            list(active) + scan_result.shortlist_symbols
                        ))
                        mde.symbols = merged
                    # Piyasa geneli rejimi güncelle (SHORT strateji kararları için)
                    _current_market_regime = getattr(scan_result, "market_regime", "UNKNOWN")
                    if db:
                        db.write_scanner_result(scan_result, scanner_type="GENERAL")
                except Exception as _scan_err:
                    logger.warning(f"[SCAN] Tarama hatası: {_scan_err}")

            # ── 0b. Momentum Scanner — Momentum Coin Shortlist Güncelle ────────
            mscan_interval = getattr(config, "MOMENTUM_SCANNER_INTERVAL", 25)
            if momentum_scanner and (iteration == 2 or iteration % mscan_interval == 0):
                try:
                    mscan_result = momentum_scanner.scan()
                    if db:
                        db.write_scanner_result(mscan_result, scanner_type="MOMENTUM")
                except Exception as _mscan_err:
                    logger.warning(f"[MSCAN] Momentum tarama hatası: {_mscan_err}")

            # ── 1. Piyasa Verisi Güncelle ──────────────────────────────────────
            mde.refresh()

            prices = mde.get_all_prices()
            port_val = trader.portfolio_value(prices)

            # ── 1b. DB Pozisyonlarını Sahiplen ─────────────────────────────────
            # PAPER modda: DB'deki tüm pozisyonları sahiplen.
            # LIVE modda: Yalnızca OKX'te gerçekten var olan pozisyonları sahiplen.
            _adopt_db_positions(
                db, trader, trade_ids,
                client=client,
                live_mode=not config.PAPER_TRADING,
            )

            # ── 1c. OKX → DB Pozisyon Sync ─────────────────────────────────────
            # Canlı modda OKX'teki gerçek pozisyonları her 5 iterasyonda
            # DB'ye yansıt (dashboard'un güncel kalması için kritik).
            if not config.PAPER_TRADING and (iteration == 1 or iteration % 5 == 0):
                _sync_okx_positions_to_db(
                    client, trader, db, mode, trade_ids, prices,
                    slot_mgr=slot_mgr,
                    strategy=strategy,
                    closed_symbols_cooldown=_closed_symbols_cooldown,
                    trade_meta=_trade_meta,
                    reporter_fn=_gen_trade_report,
                )

            # ── 2. Her Sembol İçin İşlem Döngüsü ──────────────────────────────
            _readiness_per_coin: dict = {}  # Dashboard için per-coin readiness verisi
            for symbol in mde.symbols:
                # Her iterasyonda sıfırla (UnboundLocalError önlemi)
                atr           = None
                signal        = Signal.HOLD
                reasons       = []
                engine_result = None
                _short_result = None   # Pullback Short sinyal sonucu (her sembol için temizle)
                sizing        = None   # Pozisyon boyutlandırma sonucu

                price = mde.get_price(symbol)
                if not price:
                    continue

                # Mum sayacını artır (max holding time için)
                if symbol in trader.positions:
                    trader.positions[symbol].candles_held += 1

                # ── 2a-pre. Trend Güç Değerlendirmesi (Akıllı Zaman Bazlı Çıkış) ──
                # max_bars dolduğunda trend_is_strong, süre uzatma kararını etkiler.
                if symbol in trader.positions:
                    _pos_te = trader.positions[symbol]
                    if _pos_te.max_bars > 0 and _pos_te.candles_held >= _pos_te.max_bars:
                        try:
                            _df_te = mde.get_ohlcv(symbol)
                            if _df_te is not None and len(_df_te) >= 20:
                                from strategies.pullback_long import _extract_indicators as _ext_ind_te
                                _ind_te = _ext_ind_te(_df_te)
                                if _ind_te:
                                    _adx_te = getattr(config, "SMART_EXIT_ADX_STRONG_MIN", 25)
                                    _pos_te.trend_is_strong = (
                                        _ind_te.get("adx", 0) >= _adx_te
                                        and _ind_te.get("ema9", 0) > _ind_te.get("ema21", 0) > _ind_te.get("ema50", 0)
                                        and price > _ind_te.get("ema50", 0)
                                    )
                        except Exception:
                            pass

                # ── 2a. Triple-Barrier Çıkış Kontrolü ─────────────────────────
                if symbol in trader.positions:
                    pos_snap = trader.positions[symbol]
                    pnl = trader.check_exits(symbol, price)
                    if pnl is not None:
                        cost    = pos_snap.quantity * pos_snap.entry_price
                        pnl_pct = (pnl / cost) * 100 if cost > 0 else 0
                        trade_id = trade_ids.pop(symbol, None)
                        exit_reason = getattr(pos_snap, "exit_reason", "exit") or "exit"

                        # ── CANLI MOD: OKX'e gerçek kapatma emri gönder ────────
                        okx_close_ok = True  # paper modda her zaman başarılı say
                        if not config.PAPER_TRADING:
                            okx_close_ok = exe.submit_force_close(
                                symbol        = symbol,
                                side          = pos_snap.side,
                                quantity      = pos_snap.quantity,
                                price         = price,
                                reason        = exit_reason,
                                strategy_name = pos_snap.strategy_name,
                            )
                            if okx_close_ok:
                                _sync_live_balance(client, trader, db, mode, day_start_balance)
                            else:
                                phantom_confirmed = symbol in getattr(exe, "_confirmed_phantom_symbols", set())
                                if phantom_confirmed:
                                    # OKX kesin olarak "pozisyon yok" dedi — hafızadan sil, döngüyü kır
                                    logger.warning(
                                        f"[PHANTOM-CLEAR] {symbol}: OKX bu pozisyonun var olmadığını doğruladı. "
                                        f"Hafızadan ve DB'den siliniyor."
                                    )
                                    trader.positions.pop(symbol, None)
                                    if slot_mgr is not None:
                                        slot_mgr.release_slot(symbol)
                                    if db:
                                        db.delete_position(symbol)
                                        db.write_log(
                                            "warning", "system",
                                            f"Phantom pozisyon temizlendi: {symbol}",
                                            f"OKX bu pozisyonun var olmadığını bildirdi. Otomatik silindi."
                                        )
                                else:
                                    # Geçici OKX hatası — pozisyonu geri yükle, sonraki iterasyonda tekrar dene
                                    trader.positions[symbol] = pos_snap
                                    if db:
                                        db.write_log(
                                            "error", "order",
                                            f"OKX kapatma BAŞARISIZ: {symbol}",
                                            f"Pozisyon DB'de korunuyor, manuel kontrol gerekebilir."
                                        )
                                    logger.error(
                                        f"[EXIT] {symbol} OKX kapatma başarısız — "
                                        f"pozisyon geri yüklendi, bu iterasyon atlanıyor."
                                    )

                        if okx_close_ok:
                            if db:
                                if trade_id:
                                    db.close_trade(trade_id, price, pnl, pnl_pct, exit_reason)
                                db.delete_position(symbol)
                                db.write_log(
                                    "info" if pnl >= 0 else "warning",
                                    "order",
                                    f"Pozisyon kapandı: {symbol}",
                                    f"Çıkış: ${price:,.4f} | PnL: ${pnl:+,.2f} ({pnl_pct:+.2f}%)"
                                )
                            risk_mgr.record_trade_result(pnl, symbol=symbol)
                            if slot_mgr is not None:
                                slot_mgr.release_slot(symbol)
                            # Strateji callback — cooldown ve loss streak güncelle
                            if is_pullback:
                                strategy.on_trade_closed(symbol, pnl)
                            # Short strateji callback — short pozisyon kapandığında
                            if short_strategy is not None and pos_snap.side == "short":
                                short_strategy.on_trade_closed(symbol, pnl)
                            # PATCH-4: Genel yeniden giriş kilidi — config'den alınan süre
                            import time as _exit_time
                            _reentry_cd = getattr(config, "SAME_COIN_REENTRY_COOLDOWN_SEC", 600)
                            _closed_symbols_cooldown[symbol] = _exit_time.time() + _reentry_cd
                            # Yön takibi — direction flip için
                            _last_trade_direction[symbol] = (pos_snap.side if hasattr(pos_snap, "side") else "long", _exit_time.time())

                            # ══ CANLI DOĞRULAMA — İŞLEM KAPANDI TAM ÖZET ═════════════
                            if not config.PAPER_TRADING:
                                _exit_fee = getattr(pos_snap, "fee", 0.0) or 0.0
                                _entry_cost = pos_snap.quantity * pos_snap.entry_price
                                _gross_pnl  = pnl + _exit_fee
                                _verdict    = "✅ Strateji beklenen şekilde çalıştı" if pnl >= 0 else "⚠️  Kayıp işlem — SL devreye girdi"
                                if "TP" in exit_reason.upper():
                                    _verdict = "✅ TP hedefine ulaşıldı — strateji başarılı"
                                elif "SL" in exit_reason.upper() or "stop" in exit_reason.lower():
                                    _verdict = "🛑 Stop-Loss çalıştı — risk yönetimi devreye girdi (beklenen)"
                                elif "trailing" in exit_reason.lower():
                                    _verdict = "✅ Trailing stop kâr kilitledi"
                                elif "max_bar" in exit_reason.lower() or "zaman" in exit_reason.lower():
                                    _verdict = "⏱️  Zaman limiti doldu — zorla çıkış"
                                logger.info(
                                    f"\n{'═'*60}\n"
                                    f"  🔴 CANLI POZİSYON KAPANDI — {symbol}\n"
                                    f"{'─'*60}\n"
                                    f"  Çıkış Fiyatı  : ${price:,.4f}\n"
                                    f"  Giriş Fiyatı  : ${pos_snap.entry_price:,.4f}\n"
                                    f"  Çıkış Nedeni  : {exit_reason}\n"
                                    f"  Brüt PnL      : ${_gross_pnl:+,.2f} USDT\n"
                                    f"  Komisyon (est): ${_exit_fee:,.4f} USDT\n"
                                    f"  Net PnL       : ${pnl:+,.2f} USDT (%{pnl_pct:+.2f})\n"
                                    f"  Strateji Değ. : {_verdict}\n"
                                    f"  Açık Pos.     : {len(trader.positions)} adet kaldı\n"
                                    f"  Güncel Bakiye : ${trader.balance:,.2f} USDT\n"
                                    f"{'═'*60}"
                                )

                        # ── Standart Canlı İşlem Raporu ─────────────────────────
                        try:
                            _r_meta   = _trade_meta.pop(symbol, {})
                            _r_fee    = getattr(pos_snap, "entry_fee", 0.0) or 0.0
                            _r_ep     = pos_snap.entry_price
                            _r_sl     = pos_snap.stop_loss
                            _r_tp     = pos_snap.take_profit
                            _r_risk   = _r_ep - _r_sl if pos_snap.side == "long" and _r_ep > _r_sl else (_r_sl - _r_ep if _r_sl > _r_ep else 0)
                            _r_tp2    = (_r_ep + _r_risk * 3.6) if _r_risk > 0 and pos_snap.side == "long" else None
                            _r_be     = getattr(pos_snap, "break_even_trigger_price", 0) or None
                            _r_gross  = pnl + _r_fee
                            _r_margin = pos_snap.margin if pos_snap.margin > 0 else (pos_snap.quantity * _r_ep / getattr(config, "LEVERAGE", 10))
                            _gen_trade_report(
                                symbol               = symbol,
                                strategy_name        = pos_snap.strategy_name or strategy.name,
                                side                 = pos_snap.side,
                                trade_id             = trade_id,
                                mode                 = mode,
                                paper_trading        = config.PAPER_TRADING,
                                opened_at            = _r_meta.get("opened_at"),
                                closed_at            = __import__("datetime").datetime.now(__import__("datetime").timezone.utc),
                                regime               = _r_meta.get("regime"),
                                signal_score         = _r_meta.get("signal_score"),
                                signal_score_max     = _r_meta.get("signal_score_max", 10.0),
                                norm_score           = _r_meta.get("norm_score"),
                                quality              = _r_meta.get("quality"),
                                slot_id              = _r_meta.get("slot_id"),
                                slot_notional        = _r_meta.get("slot_notional"),
                                leverage             = getattr(config, "LEVERAGE", 10),
                                sent_qty             = pos_snap.quantity,
                                filled_qty           = _r_meta.get("filled_qty") or pos_snap.quantity,
                                filled_price         = _r_meta.get("filled_price") or _r_ep,
                                filled_notional      = _r_meta.get("actual_notional") or (pos_snap.quantity * _r_ep),
                                filled_margin        = _r_margin,
                                exchange_order_id    = _r_meta.get("exchange_order_id"),
                                entry_price          = _r_ep,
                                stop_loss            = _r_sl,
                                take_profit          = _r_tp,
                                tp2_price            = _r_tp2,
                                break_even_trigger   = _r_be,
                                trailing_stop_pct    = getattr(pos_snap, "trailing_stop_pct", 0) or None,
                                min_profit_bar       = getattr(pos_snap, "min_profit_bar", 0) or None,
                                max_bars             = getattr(pos_snap, "max_bars", 0) or None,
                                exit_price           = price,
                                exit_reason          = exit_reason,
                                gross_pnl            = _r_gross,
                                commission           = _r_fee,
                                net_pnl              = pnl,
                                pnl_pct              = pnl_pct,
                                candles_held         = pos_snap.candles_held,
                                okx_open_confirmed   = _r_meta.get("okx_open_confirmed", not config.PAPER_TRADING),
                                okx_close_confirmed  = okx_close_ok and not config.PAPER_TRADING,
                                db_recorded          = db is not None and trade_id is not None,
                                on_trade_closed_ran  = is_pullback or (short_strategy is not None and pos_snap.side == "short"),
                                cooldown_set         = True,
                                risk_mgr_updated     = True,
                            )
                        except Exception as _rpt_err:
                            logger.warning(f"[RAPOR] Rapor üretim hatası: {_rpt_err}")

                        continue

                # ── 2b. OHLCV, Rejim ve Sinyal ─────────────────────────────────
                df = mde.get_ohlcv(symbol)
                if df is None or len(df) < 30:
                    logger.warning(f"{symbol}: Yetersiz OHLCV verisi, atlanıyor.")
                    continue

                # Piyasa rejimini tespit et
                regime = None
                if regime_filter is not None:
                    try:
                        regime = regime_filter.detect(df)
                        logger.debug(f"{symbol} rejim: {regime.regime} | Güç: {regime.trend_strength:.1f}")
                    except Exception as e:
                        logger.warning(f"{symbol} rejim tespiti başarısız: {e}")

                # Pullback Long Strategy → kendi sinyal + SL/TP hesabı
                _pullback_result = None
                if is_pullback:
                    from datetime import datetime, timezone as _tz
                    _hour_utc = datetime.now(_tz.utc).hour
                    _pullback_result = strategy.generate(df, symbol=symbol, hour_utc=_hour_utc)
                    signal  = Signal.BUY if _pullback_result.should_enter else Signal.HOLD
                    # ATR'yi pullback sonucundan türet (SL mesafesi / 1.8)
                    if _pullback_result.entry_price and _pullback_result.stop_loss:
                        atr = (_pullback_result.entry_price - _pullback_result.stop_loss) / 1.8
                    else:
                        atr = 0.0
                    reasons = [_pullback_result.reason] if _pullback_result.reason else []
                    # Dashboard readiness verisi — her sembol için koşul detayları
                    if strategy.last_conditions is not None:
                        _readiness_per_coin[symbol] = strategy.last_conditions
                    if signal == Signal.BUY:
                        logger.info(
                            f"{symbol} | BUY | Pullback Puan:{_pullback_result.score}/10 | "
                            f"Giriş:{_pullback_result.entry_price:.4f} | "
                            f"SL:{_pullback_result.stop_loss:.4f} | "
                            f"TP:{_pullback_result.take_profit:.4f}"
                        )

                # ── Pullback Short Strategy — BEAR_TREND rejiminde ikincil strateji ──
                # Yalnızca uzun stratejiden HOLD geldiğinde ve sembol pozisyonsuzsa çalışır.
                _short_result = None
                if (
                    short_strategy is not None
                    and signal == Signal.HOLD
                    and symbol not in trader.positions
                ):
                    _short_active_regimes = getattr(
                        config, "PULLBACK_SHORT_ACTIVE_REGIMES", ["BEAR_TREND"]
                    )
                    if _current_market_regime in _short_active_regimes:
                        from datetime import datetime, timezone as _tz
                        _hour_utc = datetime.now(_tz.utc).hour
                        _short_result = short_strategy.generate(
                            df, symbol=symbol, hour_utc=_hour_utc
                        )
                        if _short_result.should_enter:
                            signal = Signal.SELL
                            # ATR: SL mesafesi / 1.8 (yukarı yönlü)
                            if _short_result.entry_price and _short_result.stop_loss:
                                atr = (_short_result.stop_loss - _short_result.entry_price) / 1.8
                            else:
                                atr = 0.0
                            reasons = [_short_result.reason] if _short_result.reason else []
                            logger.info(
                                f"{symbol} | SHORT | Pullback Short Puan:{_short_result.score}/10 | "
                                f"Giriş:{_short_result.entry_price:.4f} | "
                                f"SL:{_short_result.stop_loss:.4f} | "
                                f"TP:{_short_result.take_profit:.4f} | "
                                f"Rejim:{_current_market_regime}"
                            )
                        else:
                            logger.debug(
                                f"[SHORT] {symbol} HOLD | Puan:{_short_result.score}/10 | "
                                f"{_short_result.reason[:80]}"
                            )
                    else:
                        logger.debug(
                            f"[SHORT] {symbol} atlandı — rejim {_current_market_regime} "
                            f"short için uygun değil (beklenen: {_short_active_regimes})"
                        )

                    # ── PATCH-5C: SHORT Zayıf Rejim Min Puan Filtresi ─────────
                    # RANGING / MIXED rejimde SHORT için min 8 puan gerekli
                    if signal == Signal.SELL and _short_result is not None:
                        _s_weak_r = getattr(config, "SHORT_WEAK_REGIMES", ["RANGING", "MIXED"])
                        _s_min_w  = getattr(config, "PULLBACK_SHORT_MIN_SCORE_WEAK", 8)
                        if _current_market_regime in _s_weak_r and _short_result.score < _s_min_w:
                            logger.info(
                                f"[SHORT WEAK REGIME] {symbol} → rejim={_current_market_regime}: "
                                f"min {_s_min_w} puan gerekli, var={_short_result.score} → HOLD"
                            )
                            signal = Signal.HOLD

                    # ── PATCH-5B SHORT: Yön Değiştirme Engeli (LONG → SHORT) ──
                    if signal == Signal.SELL and symbol in _last_trade_direction:
                        import time as _sflip_time
                        _sflip_cd  = getattr(config, "DIRECTION_FLIP_COOLDOWN_SEC", 0)
                        _slast_dir, _slast_close_ts = _last_trade_direction[symbol]
                        _sflip_age = _sflip_time.time() - _slast_close_ts
                        if _slast_dir == "long" and _sflip_cd > 0 and _sflip_age < _sflip_cd:
                            logger.info(
                                f"[DIRECTION FLIP BLOCKED] {symbol} LONG → SHORT: "
                                f"son kapanıştan {int(_sflip_age//60)}dk {int(_sflip_age%60)}s geçti "
                                f"(beklenen: {_sflip_cd//60}dk) → giriş engellendi."
                            )
                            signal = Signal.HOLD

                # Signal Engine → rejim bilgisini sinyale ilet
                elif is_signal_engine:
                    engine_result = strategy.generate(df, regime=regime)
                    signal  = engine_result.signal
                    atr     = engine_result.atr
                    reasons = engine_result.reasons
                    # Sinyal skorunu log'la
                    if signal != Signal.HOLD:
                        logger.info(
                            f"{symbol} | {signal} | Puan: {engine_result.score:.1f} | "
                            f"Rejim: {engine_result.regime} | "
                            f"Onaylar: {'; '.join(reasons[:3])}"
                        )
                    else:
                        buy_s  = engine_result.buy_score  if hasattr(engine_result, 'buy_score')  else None
                        sell_s = engine_result.sell_score if hasattr(engine_result, 'sell_score') else None
                        if buy_s is not None and sell_s is not None:
                            logger.debug(
                                f"[HOLD] {symbol} | BUY:{buy_s:.1f} SELL:{sell_s:.1f} | min={strategy.min_score:.0f}"
                            )
                else:
                    signal  = strategy.generate_signal(df)
                    atr     = getattr(strategy, "last_atr", None)
                    reasons = getattr(strategy, "last_reasons", [])

                # ── 2b-bis. Saat Filtresi ──────────────────────────────────────
                if signal == Signal.BUY and getattr(config, "TRADING_HOURS_ENABLED", False):
                    _allowed_hours = getattr(config, "TRADING_HOURS_UTC", [])
                    if _allowed_hours:
                        _cur_hour = datetime.utcnow().hour
                        if _cur_hour not in _allowed_hours:
                            signal = Signal.HOLD
                            logger.debug(
                                f"{symbol} saat filtresi: {_cur_hour}:xx UTC → işlem yasak "
                                f"(izin: {_allowed_hours})"
                            )

                # ── 2c. Risk Kontrolü ──────────────────────────────────────────
                risk_ok, risk_reason = risk_mgr.check_signal(
                    symbol, signal, port_val, trader.positions, trader.initial_balance
                )

                # ── 2c-bis. Pozisyon Rotasyonu ─────────────────────────────────
                # Pozisyon limiti dolu + sinyal çok güçlü → en zayıf pozisyonu kapat
                _rotation_min_score = getattr(config, "ROTATION_MIN_SCORE", 78)
                if (
                    not risk_ok
                    and signal == Signal.BUY
                    and symbol not in trader.positions
                    and sum(1 for _p in trader.positions.values() if not getattr(_p, 'is_manual', False)) >= config.MAX_OPEN_POSITIONS
                    and is_signal_engine
                    and engine_result.score >= _rotation_min_score
                ):
                    rotated = _try_rotate_position(
                        trader    = trader,
                        exe       = exe,
                        db        = db,
                        trade_ids = trade_ids,
                        new_symbol = symbol,
                        new_score  = engine_result.score,
                        prices     = prices,
                        mode       = mode,
                        logger_ref = logger,
                    )
                    if rotated:
                        # Risk kontrolünü yeniden yap — pozisyon sayısı azaldı
                        risk_ok, risk_reason = risk_mgr.check_signal(
                            symbol, signal, port_val, trader.positions, trader.initial_balance
                        )

                # Sinyali kaydet
                if db and signal in (Signal.BUY, Signal.SELL):
                    acted = "no"
                    if signal == Signal.BUY and risk_ok:
                        acted = "yes"
                    elif signal == Signal.SELL and symbol in trader.positions:
                        acted = "yes"
                    elif not risk_ok:
                        acted = "blocked"

                    db.write_signal(
                        symbol        = symbol,
                        signal        = signal,
                        strategy_name = strategy.name,
                        price         = price,
                        atr           = atr,
                        reasons       = reasons,
                        acted         = acted,
                        blocked_reason = "" if risk_ok else risk_reason,
                        mode          = mode,
                    )

                    if not risk_ok and signal == Signal.BUY:
                        event_type = "max_positions" if len(trader.positions) >= config.MAX_OPEN_POSITIONS else "risk"
                        db.write_risk_event(
                            symbol             = symbol,
                            event_type         = event_type,
                            blocked            = True,
                            reason             = risk_reason,
                            portfolio_value    = port_val,
                            open_positions     = len(trader.positions),
                            consecutive_losses = risk_mgr._consecutive_losses,
                            mode               = mode,
                        )

                # ── 2d. Emir Çalıştırma ───────────────────────────────────────
                pos_in_market = trader.positions.get(symbol)
                pos_side = pos_in_market.side if pos_in_market else None

                # BUY → Açık SHORT pozisyonu kapat
                if signal == Signal.BUY and pos_side == "short":
                    _short_close_label = short_strategy.name if short_strategy else strategy.name + " (SHORT)"
                    order = exe.submit_short_close(
                        symbol        = symbol,
                        price         = price,
                        reason        = "BUY sinyali ile short kapatıldı",
                        strategy_name = _short_close_label,
                    )
                    if order and order.status == "filled":
                        pnl = trader.unrealized_pnl(symbol, price) or 0
                        cost_basis = pos_in_market.quantity * pos_in_market.entry_price if pos_in_market else 0
                        pnl_pct = (pnl / cost_basis * 100) if cost_basis > 0 else 0
                        trade_id = trade_ids.pop(symbol, None)
                        if db:
                            if trade_id:
                                db.close_trade(trade_id, price, pnl, pnl_pct, "BUY sinyal ile short kapatıldı")
                            db.delete_position(symbol)
                            db.write_log(
                                "info" if pnl >= 0 else "warning",
                                "order",
                                f"SHORT pozisyon kapandı (BUY sinyal): {symbol}",
                                f"Çıkış: ${price:,.4f} | PnL: ${pnl:+,.2f} ({pnl_pct:+.2f}%)"
                            )
                        risk_mgr.record_trade_result(pnl, symbol=symbol)
                        if slot_mgr is not None:
                            slot_mgr.release_slot(symbol)
                        # Short strateji: cooldown ve loss streak güncelle
                        if short_strategy is not None:
                            short_strategy.on_trade_closed(symbol, pnl)
                        _closed_symbols_cooldown[symbol] = time.time() + getattr(config, "SAME_COIN_REENTRY_COOLDOWN_SEC", 600)
                        # Yön takibi — direction flip için
                        _last_trade_direction[symbol] = ("short", time.time())

                # SELL → Açık LONG pozisyonu kapat, sonra short'a gir
                elif signal == Signal.SELL and pos_side == "long":
                    pass  # Mevcut SELL → LONG kapatma mantığı aşağıda işlenir

                # BUY → Yeni LONG pozisyon aç (pozisyon yoksa)
                if signal == Signal.BUY and symbol not in trader.positions and risk_ok:
                    # ── Açık Risk Limiti Kontrolü ─────────────────────────────
                    free_bal = getattr(trader, "available_usdt", trader.balance)
                    _open_risk_ok, _open_risk_reason = risk_mgr.check_open_risk_limit(free_bal)
                    if not _open_risk_ok:
                        logger.info(
                            f"[OPEN-RISK] {symbol} BUY atlandı — {_open_risk_reason} | "
                            f"Toplam açık risk: ${risk_mgr.get_total_open_risk():.2f}"
                        )
                        signal = Signal.HOLD

                if signal == Signal.BUY and symbol not in trader.positions and risk_ok:
                    # ── Sinyal Kalitesi Tespiti (A+/A/B+/B/C) ─────────────────
                    # Pullback: gate=10→A+, 9→A, 8+skor≥80→B+, 8→B, 7→C
                    # SignalEngine: skor≥90→A+, ≥85→A, ≥80→B+, ≥75→B, ≥65→C
                    _sig_quality = "B"
                    _sig_score_raw = None
                    if is_pullback and _pullback_result:
                        _gate = getattr(_pullback_result, "gate_score", None) or \
                                getattr(_pullback_result, "score", None)
                        _sig_score_raw = getattr(_pullback_result, "score", None)
                        if _gate is not None:
                            _sig_quality = SlotManager.detect_quality(
                                gate_score=_gate,
                                signal_score=_sig_score_raw,
                                is_pullback=True,
                            )
                    elif is_signal_engine and engine_result:
                        _sc = getattr(engine_result, "score", 0)
                        _sig_score_raw = _sc
                        _sig_quality = SlotManager.detect_quality(
                            gate_score=None,
                            signal_score=_sc,
                            is_pullback=False,
                        )

                    # ── Minimum Skor Kapısı: < 75 → işlem açılmaz ─────────────
                    # skor 70-74 → C (izleme listesi), skor < 70 → reddedildi
                    _entry_min_score = getattr(config, "SLOT_ENTRY_MIN_SCORE", 75)
                    if (
                        is_signal_engine
                        and _sig_score_raw is not None
                        and _sig_score_raw < _entry_min_score
                    ):
                        _reject_reason = (
                            "izleme listesi (skor 70-74)"
                            if _sig_score_raw >= 70
                            else "reddedildi (skor < 70)"
                        )
                        logger.info(
                            f"[SKOR KAPI] {symbol} BUY ENGELLENDI: "
                            f"skor={_sig_score_raw:.1f} < {_entry_min_score} → {_reject_reason}"
                        )
                        signal = Signal.HOLD

                    # ── Yeniden Giriş Cooldown Kontrolü ───────────────────────
                    if signal == Signal.BUY and symbol in _closed_symbols_cooldown:
                        import time as _cd_time
                        _unlock_at = _closed_symbols_cooldown[symbol]
                        _remaining_secs = _unlock_at - _cd_time.time()
                        if _remaining_secs > 0:
                            logger.info(
                                f"[COOLDOWN] {symbol} yeniden giriş kilidi: "
                                f"kalan {int(_remaining_secs//60)}dk {int(_remaining_secs%60)}s"
                            )
                            signal = Signal.HOLD
                        else:
                            # Kilit süresi doldu — temizle
                            del _closed_symbols_cooldown[symbol]

                    # ── 5-Slot Motor: Slot Atama ───────────────────────────────
                    _slot_override_notional = None
                    _slot_id = None
                    _regime_str = regime.regime if regime else "UNKNOWN"

                    # ── PATCH-5A: LONG Rejim Yön Filtresi ─────────────────────
                    # BEAR/TRENDING_DOWN → LONG açılmaz; RANGING/WEAK → +1 puan gerekli
                    if signal == Signal.BUY and is_pullback:
                        _long_blocked = getattr(config, "LONG_BLOCKED_REGIMES", [])
                        _long_weak    = getattr(config, "LONG_WEAK_REGIMES", [])
                        _long_bonus   = getattr(config, "LONG_WEAK_MIN_SCORE_BONUS", 1)
                        if _regime_str in _long_blocked:
                            logger.info(
                                f"[LONG REGIME BLOCKED] {symbol} → rejim={_regime_str}: "
                                f"yükseliş yönü piyasaya karşı → giriş engellendi."
                            )
                            signal = Signal.HOLD
                        elif _regime_str in _long_weak and _pullback_result is not None:
                            _long_min_req = getattr(config, "PULLBACK_LONG_MIN_SCORE", 7) + _long_bonus
                            if _pullback_result.score < _long_min_req:
                                logger.info(
                                    f"[LONG REGIME WEAK] {symbol} → rejim={_regime_str}: "
                                    f"min {_long_min_req} puan gerekli, var={_pullback_result.score} → giriş engellendi."
                                )
                                signal = Signal.HOLD

                    # ── PATCH-5B: Yön Değiştirme Engeli ──────────────────────
                    # Son kapanıştan DIRECTION_FLIP_COOLDOWN_SEC içinde karşı yöne giriş yok
                    if signal == Signal.BUY and symbol in _last_trade_direction:
                        import time as _flip_time
                        _flip_cd  = getattr(config, "DIRECTION_FLIP_COOLDOWN_SEC", 0)
                        _last_dir, _last_close_ts = _last_trade_direction[symbol]
                        _flip_age = _flip_time.time() - _last_close_ts
                        if _last_dir == "short" and _flip_cd > 0 and _flip_age < _flip_cd:
                            logger.info(
                                f"[DIRECTION FLIP BLOCKED] {symbol} SHORT → LONG: "
                                f"son kapanıştan {int(_flip_age//60)}dk {int(_flip_age%60)}s geçti "
                                f"(beklenen: {_flip_cd//60}dk) → giriş engellendi."
                            )
                            signal = Signal.HOLD

                    if slot_mgr is not None and getattr(config, "USE_QUALITY_WEIGHTED_SLOT_STRATEGY", True) and signal == Signal.BUY:
                        _slot_result = slot_mgr.assign_slot(
                            symbol            = symbol,
                            quality           = _sig_quality,
                            regime            = _regime_str,
                            available_balance = free_bal,
                        )
                        if _slot_result is None:
                            logger.info(
                                f"[SLOT] {symbol} BUY ATILDI — "
                                f"Kalite={_sig_quality} Rejim={_regime_str}: slot yok"
                            )
                            signal = Signal.HOLD
                        else:
                            _slot_id, _slot_override_notional, _slot_reason = _slot_result

                            # ── FORCE MAX SLOT TEST MODE ──────────────────────────
                            # Slot filtreleri (kalite/rejim/reserve) zaten geçildi.
                            # Şimdi notional'ı SLOT_CONFIG'deki en yüksek değere çek.
                            if getattr(config, "FORCE_MAX_SLOT_TEST_MODE", False):
                                _slots_cfg = getattr(config, "SLOT_CONFIG", [])
                                _fms_max = max(
                                    (s["notional"] for s in _slots_cfg),
                                    default=_slot_override_notional,
                                )
                                if _fms_max != _slot_override_notional:
                                    logger.info(
                                        f"[FORCE MAX SLOT TEST] {symbol} override edildi → "
                                        f"Slot {_slot_id} ${_slot_override_notional:.0f} → "
                                        f"Max Slot Notional: ${_fms_max:.0f}"
                                    )
                                    _slot_override_notional = _fms_max
                                else:
                                    logger.debug(
                                        f"[FORCE MAX SLOT TEST] {symbol} zaten max "
                                        f"(${_slot_override_notional:.0f})"
                                    )

                    # ── Large Lot Mode: Güçlü sinyal → büyük lot notional ───────
                    # LIVE_TEST_MODE aktifken _calc_large_lot_gate() otomatik None döner.
                    # Sadece slot başarıyla atandıysa ve BUY sinyali hâlâ geçerliyse çalışır.
                    _large_lot_active   = False
                    _large_lot_sl_pct   = None
                    _large_lot_tp_pct   = None
                    _large_lot_notional = None
                    if signal == Signal.BUY and _slot_override_notional is not None:
                        _ll_result = _calc_large_lot_gate(_sig_quality, regime=_regime_str)
                        if _ll_result is not None:
                            _large_lot_notional, _large_lot_sl_pct, _large_lot_tp_pct = _ll_result
                            _ll_exp_profit = _large_lot_notional * _large_lot_tp_pct
                            _ll_risk       = _large_lot_notional * _large_lot_sl_pct
                            logger.info(
                                f"[LARGE LOT] {symbol} AKTİF | "
                                f"Kalite={_sig_quality} | "
                                f"Notional=${_large_lot_notional:.0f} "
                                f"(slot'un ${_slot_override_notional:.0f} üzerinden) | "
                                f"SL=%{_large_lot_sl_pct*100:.2f} | "
                                f"TP=%{_large_lot_tp_pct*100:.1f} | "
                                f"Risk={_ll_risk:.2f} USDT | "
                                f"Hedef Kâr={_ll_exp_profit:.1f} USDT | "
                                f"R/R=1:{_ll_exp_profit/_ll_risk:.1f}"
                            )
                            _slot_override_notional = _large_lot_notional
                            _large_lot_active = True

                # ── Hacim Zayıf Filtresi ──────────────────────────────────────────
                # Hacim teyidi yoksa ve kalite WEAK_VOLUME_MIN_QUALITY altındaysa giriş engellenir.
                # Not: _sig_quality yalnızca risk_ok=True ve pozisyon yokken set edilir; aynı koşul burada da gerekli.
                if signal == Signal.BUY and is_pullback and _pullback_result is not None \
                        and risk_ok and symbol not in trader.positions:
                    if not getattr(_pullback_result, "volume_ok", True):
                        import time as _wv_time
                        _wv_min_q      = getattr(config, "WEAK_VOLUME_MIN_QUALITY", "A")
                        _wv_q_rank     = _QUALITY_RANK.get(_sig_quality, 0)
                        _wv_m_rank     = _QUALITY_RANK.get(_wv_min_q, 4)
                        _wv_bp_rank    = _QUALITY_RANK.get("B+", 3)
                        _wv_bp_chance  = getattr(config, "WEAK_VOLUME_BP_SECOND_CHANCE", True)
                        _wv_ttl        = getattr(config, "WEAK_VOLUME_PENDING_TTL_SEC", 900)
                        if _wv_q_rank < _wv_m_rank:
                            # B+ kalite için "ikinci teyit" sistemi
                            if _wv_q_rank == _wv_bp_rank and _wv_bp_chance:
                                _now_wv = _wv_time.time()
                                if symbol in _wv_pending_signals:
                                    _pending_age = _now_wv - _wv_pending_signals[symbol]
                                    if _pending_age <= _wv_ttl:
                                        # ✅ İkinci teyit alındı — işlem açılabilir
                                        logger.info(
                                            f"[WEAK VOLUME CONFIRMATION ACHIEVED] {symbol} | "
                                            f"Kalite={_sig_quality} | İkinci teyit alındı "
                                            f"({_pending_age/60:.0f}dk sonra) → İşlem açılıyor."
                                        )
                                        del _wv_pending_signals[symbol]
                                        # signal = BUY olarak kalır, filtre pass eder
                                    else:
                                        # ⌛ Süre doldu — yeniden başlat
                                        _wv_pending_signals[symbol] = _now_wv
                                        logger.warning(
                                            f"[WEAK VOLUME CONFIRMATION REQUIRED] {symbol} | "
                                            f"Kalite=B+ | Önceki pending süresi dolmuştu ({_pending_age/60:.0f}dk) "
                                            f"→ Sıfırlandı, tekrar ikinci teyit bekleniyor."
                                        )
                                        if slot_mgr is not None and _slot_id is not None:
                                            slot_mgr.release_slot(symbol)
                                        signal = Signal.HOLD
                                else:
                                    # İlk kez görüldü — pending'e al, bu sefer aç
                                    _wv_pending_signals[symbol] = _now_wv
                                    logger.warning(
                                        f"[WEAK VOLUME CONFIRMATION REQUIRED] {symbol} | "
                                        f"Kalite=B+ | Zayıf hacim — ilk sinyal tutuldu. "
                                        f"Sonraki {_wv_ttl//60:.0f}dk içinde tekrar gelirse açılacak."
                                    )
                                    if slot_mgr is not None and _slot_id is not None:
                                        slot_mgr.release_slot(symbol)
                                    signal = Signal.HOLD
                            else:
                                # B ve altı: doğrudan engelle
                                logger.warning(
                                    f"[WEAK VOLUME CONFIRMATION REQUIRED] {symbol} | "
                                    f"Kalite={_sig_quality} | Zayıf hacimde min kalite {_wv_min_q} "
                                    f"(skor≥85) gerekli → Giriş engellendi. Slot serbest bırakılıyor."
                                )
                                if slot_mgr is not None and _slot_id is not None:
                                    slot_mgr.release_slot(symbol)
                                signal = Signal.HOLD
                    else:
                        # Hacim onaylıysa pending'den temizle (artık beklemeye gerek yok)
                        _wv_pending_signals.pop(symbol, None)

                if signal == Signal.BUY and symbol not in trader.positions and risk_ok:
                    # ── Pozisyon Boyutu: Slot notional tek kaynak ─────────────────
                    # slot_notional verilirse position_sizer kalite-cap'ı atlar;
                    # yalnızca bakiye yetersizliğinde aşağı ölçekler.
                    size_mult = risk_mgr.position_size_multiplier()
                    sizing = pos_sizer.calculate(
                        symbol            = symbol,
                        price             = price,
                        available_balance = free_bal,
                        atr               = atr,
                        signal_quality    = _sig_quality,
                        slot_notional     = _slot_override_notional,  # ← tek kaynak
                    )

                    # Defense mode: pozisyon boyutunu küçült
                    if sizing and size_mult < 1.0:
                        orig = sizing.get("trade_value_override") or sizing.get("quantity")
                        if orig:
                            key = "trade_value_override" if "trade_value_override" in sizing else "quantity"
                            sizing[key] = orig * size_mult
                        logger.info(
                            f"Savunma modu: {symbol} pozisyon ×{size_mult:.1f} küçültüldü"
                        )

                    # Pullback stratejisinin ATR tabanlı SL/TP değerlerini kullan
                    if sizing and is_pullback and _pullback_result and _pullback_result.should_enter:
                        if _pullback_result.stop_loss and _pullback_result.stop_loss > 0:
                            sizing["stop_loss"]   = _pullback_result.stop_loss
                        if _pullback_result.take_profit and _pullback_result.take_profit > 0:
                            sizing["take_profit"] = _pullback_result.take_profit
                        logger.info(
                            f"[Pullback] {symbol} SL/TP override: "
                            f"SL=${sizing['stop_loss']:.4f} | TP=${sizing['take_profit']:.4f}"
                        )

                    # ── Large Lot Mode: Sabit SL/TP override (%1.25 / %5.0) ─────
                    # Pullback'in ATR bazlı SL/TP'sini large lot sabit değerleriyle değiştirir.
                    # ATR-based pozisyon → daha dar SL, daha geniş TP → R/R=4:1 garantisi.
                    if sizing and _large_lot_active and _large_lot_sl_pct and _large_lot_tp_pct:
                        _ll_sl_price = price * (1 - _large_lot_sl_pct)
                        _ll_tp_price = price * (1 + _large_lot_tp_pct)
                        sizing["stop_loss"]          = max(_ll_sl_price, 0.0)
                        sizing["take_profit"]        = _ll_tp_price
                        sizing["large_lot_sl_pct"]   = _large_lot_sl_pct
                        sizing["large_lot_tp_pct"]   = _large_lot_tp_pct
                        sizing["large_lot_active"]   = True
                        logger.info(
                            f"[LARGE LOT] {symbol} SL/TP override (sabit): "
                            f"SL=${_ll_sl_price:.4f} (-%{_large_lot_sl_pct*100:.2f}) | "
                            f"TP=${_ll_tp_price:.4f} (+%{_large_lot_tp_pct*100:.1f})"
                        )

                    if sizing:
                        # ── Canli mod için önceden hesapla (GİRİŞ ONAYI sonra basılacak) ──
                        _eco_ok = True  # ekonomik notional filtresi (default: izin ver)
                        if not config.PAPER_TRADING:
                            _lev           = getattr(config, "LEVERAGE", 10)
                            _reserve       = getattr(config, "SLOT_RESERVE_USDT", 200)
                            _score_display = f"{_sig_score_raw}/10" if _sig_score_raw is not None else "N/A"
                            _actual_notional = sizing.get(
                                "slot_notional_applied",
                                sizing.get("trade_value", 0) * _lev
                            )
                            _actual_margin   = _actual_notional / _lev
                            _remaining_bal   = free_bal - _actual_margin
                            _slot_notional_target = sizing.get("slot_notional", _slot_override_notional)
                            _notional_match  = (
                                abs(_actual_notional - _slot_notional_target) < 1.0
                                if _slot_notional_target else True
                            )
                            _override_warn   = (
                                "" if _notional_match else
                                f"\n  NOTIONAL SAPMA: Slot ${_slot_notional_target:.0f} → Uygulanan ${_actual_notional:.2f} (bakiye limiti)"
                            )
                            # ── Ekonomik Notional Filtresi ────────────────────────
                            _eco_min = getattr(config, "MIN_ECONOMIC_NOTIONAL", 100.0)
                            if _actual_notional < _eco_min:
                                logger.warning(
                                    f"[ECONOMIC NOTIONAL REJECTED] {symbol} → "
                                    f"Notional ${_actual_notional:.2f} < min ekonomik "
                                    f"${_eco_min:.0f} USDT. Komisyon/kâr dengesi "
                                    f"olumsuz → İşlem açılmıyor. Slot serbest bırakılıyor."
                                )
                                if slot_mgr is not None and _slot_id is not None:
                                    slot_mgr.release_slot(symbol)
                                _eco_ok = False

                        order = exe.submit_buy(
                            symbol        = symbol,
                            price         = price,
                            sizing        = sizing,
                            strategy_name = strategy.name,
                        ) if _eco_ok else None

                        if order is None and not config.PAPER_TRADING and _eco_ok:
                            # Emir reddedildi — OKX'ten güncel bakiyeyi al
                            _sync_live_balance(client, trader, db, mode, day_start_balance)
                            # Slot serbest bırak — emir başarısız oldu, tekrar denenebilsin
                            if slot_mgr is not None and _slot_id is not None:
                                slot_mgr.release_slot(symbol)
                            logger.warning(
                                f"[EXEC] {symbol} CANLI EMİR BAŞARISIZ — "
                                f"OKX reddetti (min kontrat boyutu, bakiye yetersiz veya API hatası). "
                                f"Dashboard'da pozisyon AÇILMADI."
                            )

                        if order and order.status == "filled":
                            pos = trader.positions.get(symbol)

                            # ── PATCH-3: Economic Filled Notional Filtresi (Post-Fill) ───
                            # Gerçek fill notional (qty × fill_price) eşiğin altındaysa
                            # komisyon/kâr dengesi olumsuz → pozisyon anında kapatılır.
                            if pos and not config.PAPER_TRADING:
                                _eco_fill_min = getattr(config, "MIN_ECONOMIC_FILLED_NOTIONAL", 120.0)
                                _fill_notional_real = pos.quantity * pos.entry_price
                                if _fill_notional_real < _eco_fill_min:
                                    logger.warning(
                                        f"[ECONOMIC FILLED NOTIONAL REJECTED] {symbol} → "
                                        f"Filled ${_fill_notional_real:.2f} < min ${_eco_fill_min:.0f} USDT "
                                        f"(komisyon/kâr dengesi olumsuz) → Pozisyon anında kapatılıyor"
                                    )
                                    try:
                                        exe.submit_force_close(
                                            symbol,
                                            side     = pos.side if pos else "long",
                                            quantity = pos.quantity if pos else 0.0,
                                            price    = pos.entry_price if pos else 0.0,
                                            reason   = "economic_notional_rejected",
                                        )
                                        trader.positions.pop(symbol, None)
                                        if slot_mgr is not None and _slot_id is not None:
                                            slot_mgr.release_slot(symbol)
                                    except Exception as _efn_ex:
                                        logger.warning(
                                            f"[ECONOMIC FILLED NOTIONAL REJECTED] {symbol} "
                                            f"kapatma hatası: {_efn_ex}"
                                        )
                                    pos = None  # DB yazma ve profil uygulama atlanacak

                            # Smart Exit parametrelerini ayarla
                            if pos:
                                profile = get_profile(strategy.name)
                                profile.apply_to_position(pos)

                                # ── Akıllı Zaman Bazlı Çıkış: max_bars Override ───
                                # Large lot için config değerini; küçük lot için profil değerini kullan.
                                # Profil apply_to_position ile zaten max_bars'ı set etti.
                                if _large_lot_active:
                                    _smart_base = max(
                                        profile.max_bars,
                                        getattr(config, "SMART_EXIT_LARGE_LOT_MAX_BARS", 10),
                                    )
                                    pos.max_bars = _smart_base
                                # else: profil değeri korunur (apply_to_position'dan gelir)
                                pos.is_large_lot = bool(_large_lot_active)

                                # ── Large Lot TP Profili Override ─────────────────
                                # Dengeli kâr koruma profili: TP1+%0.8(%50) → TP2+%1.8(%50) → trailing%0.5
                                # Sadece _large_lot_active=True ise çalışır; küçük lot etkilenmez.
                                if _large_lot_active:
                                    # Tüm kalite seviyeleri (B+/A/A+) için birleşik dengeli profil
                                    _ll_tp1_p    = config.LARGE_LOT_BPLUS_TP1_PCT      # +%0.8
                                    _ll_tp1_s    = config.LARGE_LOT_BPLUS_TP1_SIZE     # %50
                                    _ll_tp2_p    = config.LARGE_LOT_BPLUS_TP2_PCT      # +%1.8
                                    _ll_tp2_s    = config.LARGE_LOT_BPLUS_TP2_SIZE     # %50
                                    _ll_trail    = config.LARGE_LOT_BPLUS_TRAILING_PCT  # %0.5
                                    _ll_prof_lbl = "Dengeli TP Profili"

                                    pos.tp1_pct           = _ll_tp1_p
                                    pos.tp1_size_pct      = _ll_tp1_s
                                    pos.tp2_pct           = _ll_tp2_p
                                    pos.tp2_size_pct      = _ll_tp2_s
                                    pos.trailing_stop_pct = _ll_trail
                                    pos.break_even_pct    = 0.005  # Large lot: +%0.5'te BE aktif

                                    _ll_runner_pct  = round((1 - _ll_tp1_s - _ll_tp2_s) * 100)
                                    _ll_tp1_profit  = _large_lot_notional * _ll_tp1_p * _ll_tp1_s
                                    _ll_tp2_profit  = _large_lot_notional * _ll_tp2_p * _ll_tp2_s
                                    _ll_run_profit  = _large_lot_notional * config.LARGE_LOT_TP_PCT * (1 - _ll_tp1_s - _ll_tp2_s)
                                    _ll_max_profit  = _ll_tp1_profit + _ll_tp2_profit + _ll_run_profit
                                    logger.info(
                                        f"[LLM-TP] {symbol} ★ {_ll_prof_lbl} AKTİF → "
                                        f"TP1:+{_ll_tp1_p*100:.1f}%({int(_ll_tp1_s*100)}%) "
                                        f"TP2:+{_ll_tp2_p*100:.1f}%({int(_ll_tp2_s*100)}%) "
                                        f"Runner:{_ll_runner_pct}% Trail:{_ll_trail*100:.1f}% "
                                        f"| Kalite:{_sig_quality} Notional=${_large_lot_notional:.0f} "
                                        f"MaxKar≈${_ll_max_profit:.2f} USDT"
                                    )

                                pos.highest_price = price

                                # ── Stage2: Kâr Alma Modu (LONG) ──────────────
                                if getattr(config, "STAGE2_PROFIT_MODE", False):
                                    pos.usdt_tp1_trigger = getattr(config, "STAGE2_USDT_TRIGGER", 10.0)
                                    pos.usdt_tp1_size    = getattr(config, "STAGE2_PARTIAL_SIZE", 0.50)
                                    _s2_q_min = getattr(config, "STAGE2_RUNNER_QUALITY_MIN", "A")
                                    if _QUALITY_RANK.get(_sig_quality, 0) >= _QUALITY_RANK.get(_s2_q_min, 4):
                                        pos.tp2_pct           = getattr(config, "STAGE2_RUNNER_TP2_PCT", 0.05)
                                        pos.trailing_stop_pct = getattr(config, "STAGE2_RUNNER_TRAILING_PCT", 0.015)
                                        logger.info(
                                            f"[STAGE2 RUNNER LONG] {symbol} kalite={_sig_quality} → "
                                            f"USDT tetik=${pos.usdt_tp1_trigger:.0f} | "
                                            f"Runner TP2=+{pos.tp2_pct*100:.0f}% Trail={pos.trailing_stop_pct*100:.1f}% aktif"
                                        )
                                    else:
                                        logger.info(
                                            f"[STAGE2 LONG] {symbol} kalite={_sig_quality} → "
                                            f"USDT tetik=${pos.usdt_tp1_trigger:.0f} aktif (standart TP2={pos.tp2_pct*100:.1f}%)"
                                        )

                                # ── Pullback Strateji: Ek Çıkış Parametreleri ──
                                if is_pullback and _pullback_result and _pullback_result.should_enter:
                                    # Minimum hold: 30 dakika (1800 saniye)
                                    pos.min_hold_seconds = (_pullback_result.min_hold_minutes or 30) * 60

                                    # Break-even trigger: giriş + 0.7 × R (risk)
                                    # R = entry - stop_loss (ATR × 1.8)
                                    _r = pos.entry_price - pos.stop_loss
                                    if _r > 0:
                                        pos.break_even_trigger_price = pos.entry_price + (_r * 0.7)
                                    logger.info(
                                        f"[Pullback] {symbol} çıkış parametreleri: "
                                        f"MinHold={pos.min_hold_seconds//60}dk | "
                                        f"BE-Trigger=${pos.break_even_trigger_price:.4f} "
                                        f"(giriş+0.7R=${_r*0.7:.4f})"
                                    )
                                else:
                                    logger.info(
                                        f"[{strategy.name}] Profil uygulandı (LONG) → "
                                        f"BE:%{profile.breakeven_trigger_pct*100:.1f} "
                                        f"TP1:%{profile.partial_tp1_pct*100:.1f}({int(profile.partial_tp1_size*100)}%) "
                                        f"TP2:%{profile.partial_tp2_pct*100:.1f}({int(profile.partial_tp2_size*100)}%) "
                                        f"Trailing:%{profile.trailing_stop_pct*100:.1f} MaxBars:{profile.max_bars}"
                                    )
                            # ══ CANLI DOĞRULAMA — İŞLEM AÇILDI LOG (emir onaylandıktan sonra) ══
                            if not config.PAPER_TRADING and pos:
                                _risk_per_unit  = pos.entry_price - pos.stop_loss
                                _tp2_price      = pos.entry_price + (_risk_per_unit * 1.8 * 2) if _risk_per_unit > 0 else 0
                                _trailing_pct   = getattr(profile, "trailing_stop_pct", 0) * 100 if profile else 0
                                _be_trigger     = getattr(pos, "break_even_trigger_price", 0) or 0
                                _min_hold_dk    = (getattr(pos, "min_hold_seconds", 0) or 0) // 60
                                _max_bars       = getattr(profile, "max_bars", "N/A") if profile else "N/A"
                                _sl_pct         = abs((pos.entry_price - pos.stop_loss) / pos.entry_price * 100)
                                _tp1_pct        = (pos.take_profit - pos.entry_price) / pos.entry_price * 100
                                _tp2_pct        = (_tp2_price - pos.entry_price) / pos.entry_price * 100 if _tp2_price > 0 else 0
                                _be_pct         = (_be_trigger - pos.entry_price) / pos.entry_price * 100 if _be_trigger > 0 else 0
                                _ll_mode_str = (
                                    f"  ★ LARGE LOT MOD  : AKTİF | Notional=${_large_lot_notional or 0:,.0f} USDT | SL=%{(_large_lot_sl_pct or 0)*100:.2f} | TP=%{(_large_lot_tp_pct or 0)*100:.1f} | R/R=1:{((_large_lot_notional or 1)*(_large_lot_tp_pct or 0))/(max((_large_lot_notional or 1)*(_large_lot_sl_pct or 1), 0.001)):.1f}\n"
                                    if _large_lot_active else
                                    f"  Large Lot Modu   : Kapalı (standart slot)\n"
                                )
                                _sl_label = "Stop-Loss (LLM %1.25)" if _large_lot_active else "Stop-Loss (ATR×1.8)"
                                _tp_label = "TP1 (LLM %5.0)     " if _large_lot_active else "TP1 (RR×1.8)      "
                                logger.info(
                                    f"\n{'═'*60}\n"
                                    f"  ✅ CANLI İŞLEM GİRİŞ ONAYI — {symbol}\n"
                                    f"{'─'*60}\n"
                                    f"  Coin            : {symbol}\n"
                                    f"  Bot Türü        : {strategy.name}\n"
                                    f"  Sinyal Puanı    : {_score_display}\n"
                                    f"  Kalite Seviyesi : {_sig_quality}\n"
                                    f"  Piyasa Rejimi   : {_regime_str}\n"
                                    f"{_ll_mode_str}"
                                    f"  Seçilen Slot    : {_slot_id or 'default'}\n"
                                    f"  Slot Notional   : ${_slot_notional_target or 0:,.0f} USDT\n"
                                    f"  Uygulanan Notional: ${_actual_notional:,.2f} USDT {'✓' if _notional_match else '⚠'}\n"
                                    f"  Uygulanan Marjin: ${_actual_margin:,.2f} USDT ({_lev}x kaldıraç)\n"
                                    f"  Mevcut Bakiye   : ${free_bal:,.2f} USDT\n"
                                    f"  İşlem Sonrası   : ${_remaining_bal:,.2f} USDT (rezerv: ${_reserve:,.0f})\n"
                                    f"{'─'*60}\n"
                                    f"  Giriş Fiyatı    : ${pos.entry_price:,.4f}\n"
                                    f"  {_sl_label}: ${pos.stop_loss:,.4f} (−%{_sl_pct:.2f})\n"
                                    f"  {_tp_label}: ${pos.take_profit:,.4f} (+%{_tp1_pct:.2f})\n"
                                    f"  TP2 (tahmini)   : ${_tp2_price:,.4f} (+%{_tp2_pct:.2f})\n"
                                    f"  Miktar (coin)   : {pos.quantity:.6f}\n"
                                    f"  Min. Bekleme    : {_min_hold_dk} dakika\n"
                                    f"  BE Tetik Fiyatı : ${_be_trigger:,.4f} (+%{_be_pct:.2f}) → SL break-even'e çekilir\n"
                                    f"  Trailing Stop   : %{_trailing_pct:.1f} (BE sonrası aktifleşir)\n"
                                    f"  Max Bar Limiti  : {_max_bars} mum (aşılırsa zorla çıkış)\n"
                                    f"  OKX Emir ID     : {order.exchange_order_id or 'bekliyor'}\n"
                                    f"  Giriş Nedeni    : {_slot_reason if _slot_id else 'Slot sistemi dışı'}"
                                    f"{_override_warn}\n"
                                    f"{'═'*60}"
                                )

                            trade_id = None
                            if db and pos:
                                trade_id = db.open_trade(
                                    symbol        = symbol,
                                    price         = pos.entry_price,
                                    quantity      = pos.quantity,
                                    stop_loss     = pos.stop_loss,
                                    take_profit   = pos.take_profit,
                                    strategy_name = strategy.name,
                                    mode          = mode,
                                    fee           = order.fee,
                                )
                                db.upsert_position(
                                    symbol        = symbol,
                                    entry_price   = pos.entry_price,
                                    current_price = price,
                                    quantity      = pos.quantity,
                                    pnl           = 0.0,
                                    pnl_pct       = 0.0,
                                    stop_loss     = pos.stop_loss,
                                    take_profit   = pos.take_profit,
                                    strategy_name = strategy.name,
                                    trade_id      = trade_id,
                                    mode          = mode,
                                    side          = "long",
                                    leverage      = config.LEVERAGE,
                                )
                                db.write_order(
                                    client_order_id = order.client_order_id,
                                    symbol          = symbol,
                                    side            = "BUY",
                                    order_type      = "market",
                                    quantity        = order.filled_qty,
                                    price           = order.price,
                                    status          = "filled",
                                    filled_price    = order.filled_price,
                                    filled_qty      = order.filled_qty,
                                    fee             = order.fee,
                                    stop_loss       = pos.stop_loss,
                                    take_profit     = pos.take_profit,
                                    strategy_name   = strategy.name,
                                    mode            = mode,
                                    trade_id        = trade_id,
                                )
                                db.write_log(
                                    "info", "order",
                                    f"Pozisyon açıldı: {symbol}",
                                    f"Fiyat: ${pos.entry_price:,.4f} | "
                                    f"Miktar: {pos.quantity:.6f} | "
                                    f"ATR: ${atr:,.4f} | " if atr else "" +
                                    f"SL: ${pos.stop_loss:,.4f} | TP: ${pos.take_profit:,.4f}"
                                )
                            if trade_id:
                                trade_ids[symbol] = trade_id
                                if symbol in trader.positions:
                                    trader.positions[symbol].trade_id = trade_id
                                _open_risk_amt = (sizing or {}).get("risk_amount", 0.0)
                                risk_mgr.record_trade_open(symbol, risk_amount=_open_risk_amt)

                            # ── Trade Reporter: açılış metadata'sını sakla ──────────────
                            try:
                                _meta_lev = getattr(config, "LEVERAGE", 10)
                                _meta_notional = (
                                    locals().get("_actual_notional")
                                    or (sizing or {}).get("slot_notional_applied")
                                    or ((sizing or {}).get("trade_value", 0) * _meta_lev)
                                    or (pos.quantity * pos.entry_price if pos else 0.0)
                                )
                                _trade_meta[symbol] = {
                                    "exchange_order_id":  getattr(order, "exchange_order_id", None) if order else None,
                                    "opened_at":          getattr(pos, "entry_time", None) if pos else None,
                                    "signal_score":       _sig_score_raw,
                                    "signal_score_max":   10.0,
                                    "norm_score":         None,
                                    "quality":            _sig_quality,
                                    "slot_id":            _slot_id,
                                    "slot_notional":      locals().get("_slot_notional_target") or _slot_override_notional,
                                    "actual_notional":    _meta_notional,
                                    "actual_margin":      pos.margin if pos else 0.0,
                                    "filled_qty":         getattr(order, "filled_qty", pos.quantity if pos else 0) if order else (pos.quantity if pos else 0),
                                    "filled_price":       getattr(order, "filled_price", pos.entry_price if pos else 0) if order else (pos.entry_price if pos else 0),
                                    "regime":             _regime_str,
                                    "okx_open_confirmed": not config.PAPER_TRADING and order is not None,
                                }
                            except Exception as _meta_err:
                                logger.debug(f"[RAPOR] Meta kayıt hatası: {_meta_err}")

                elif signal == Signal.SELL and pos_side == "long":
                    pos_snap = trader.positions[symbol]

                    # Minimum hold koruması: pozisyon yeni açıldıysa SELL sinyalini yoksay
                    _pos_min_hold = getattr(pos_snap, "min_hold_seconds", 0)
                    _pos_ts       = getattr(pos_snap, "entry_timestamp_unix", 0.0)
                    _pos_age_sec  = (time.time() - _pos_ts) if _pos_ts > 0 else 9999
                    if _pos_min_hold > 0 and _pos_age_sec < _pos_min_hold:
                        _remaining = int((_pos_min_hold - _pos_age_sec) / 60)
                        logger.info(
                            f"[MinHold] {symbol} SELL sinyali yoksayıldı — "
                            f"min hold {_pos_min_hold//60}dk aktif "
                            f"(kalan ~{_remaining}dk)"
                        )
                        signal = Signal.HOLD  # Bu iterasyonda işlem yapma

                    if signal == Signal.SELL:
                        order = exe.submit_sell(
                            symbol        = symbol,
                            price         = price,
                            reason        = "SELL sinyali",
                            strategy_name = strategy.name,
                        )
                    else:
                        order = None

                    if order and order.status == "filled":
                        pnl = order.filled_price * order.filled_qty - \
                              pos_snap.quantity * pos_snap.entry_price - \
                              order.fee - pos_snap.entry_fee
                        cost    = pos_snap.quantity * pos_snap.entry_price
                        pnl_pct = (pnl / cost) * 100 if cost > 0 else 0
                        trade_id = trade_ids.pop(symbol, None)

                        if db:
                            if trade_id:
                                db.close_trade(
                                    trade_id, price, pnl, pnl_pct,
                                    "SELL sinyali", order.fee
                                )
                            db.delete_position(symbol)
                            db.write_order(
                                client_order_id = order.client_order_id,
                                symbol          = symbol,
                                side            = "SELL",
                                order_type      = "market",
                                quantity        = order.filled_qty,
                                price           = order.price,
                                status          = "filled",
                                filled_price    = order.filled_price,
                                filled_qty      = order.filled_qty,
                                fee             = order.fee,
                                strategy_name   = strategy.name,
                                mode            = mode,
                                trade_id        = trade_id,
                            )
                            db.write_log(
                                "info" if pnl >= 0 else "warning",
                                "order",
                                f"Pozisyon kapandı (SELL): {symbol}",
                                f"Çıkış: ${price:,.4f} | PnL: ${pnl:+,.2f} ({pnl_pct:+.2f}%)"
                            )
                        risk_mgr.record_trade_result(pnl, symbol=symbol)
                        if slot_mgr is not None:
                            slot_mgr.release_slot(symbol)
                        # PATCH-4: Genel yeniden giriş kilidi — config'den alınan süre
                        import time as _sell_time
                        _closed_symbols_cooldown[symbol] = _sell_time.time() + getattr(config, "SAME_COIN_REENTRY_COOLDOWN_SEC", 600)

                elif signal == Signal.SELL and symbol not in trader.positions and risk_ok:
                    # Açık pozisyon yok → SHORT aç
                    # Short için SL/TP ters: SL yukarıda, TP aşağıda
                    free_bal = getattr(trader, "available_usdt", trader.balance)

                    # ── Slot ataması (SHORT için de slot sistemi çalışır) ──────────
                    _short_slot_override_notional = None
                    _short_slot_id = None
                    _short_sig_quality = "B"
                    if short_strategy is not None and _short_result is not None:
                        _short_gate = getattr(_short_result, "score", None)
                        _short_sig_quality = SlotManager.detect_quality(
                            gate_score=_short_gate,
                            signal_score=_short_gate,
                            is_pullback=True,
                        ) if slot_mgr is not None and _short_gate is not None else "B"
                        _regime_str_short = _current_market_regime
                        if slot_mgr is not None and getattr(config, "USE_QUALITY_WEIGHTED_SLOT_STRATEGY", True):
                            _short_slot_result = slot_mgr.assign_slot(
                                symbol            = symbol,
                                quality           = _short_sig_quality,
                                regime            = _regime_str_short,
                                available_balance = free_bal,
                            )
                            if _short_slot_result is None:
                                logger.info(
                                    f"[SLOT-SHORT] {symbol} SHORT ATILDI — "
                                    f"Kalite={_short_sig_quality} Rejim={_regime_str_short}: slot yok"
                                )
                                signal = Signal.HOLD

                            else:
                                _short_slot_id, _short_slot_override_notional, _short_slot_reason = _short_slot_result
                                logger.info(
                                    f"[SLOT-SHORT] {symbol} SHORT slot atandı: "
                                    f"ID={_short_slot_id} Notional=${_short_slot_override_notional}"
                                )

                    # ── PATCH-5D: SHORT Hacim Zayıf Filtresi ──────────────────
                    # volume_ok=False olan SHORT sinyalleri min kalite gerektirince engellenir
                    if signal == Signal.SELL and _short_result is not None:
                        if not getattr(_short_result, "volume_ok", True):
                            _wvs_min_q  = getattr(config, "WEAK_VOLUME_MIN_QUALITY", "A")
                            _wvs_q_rank = _QUALITY_RANK.get(_short_sig_quality, 0)
                            _wvs_m_rank = _QUALITY_RANK.get(_wvs_min_q, 4)
                            if _wvs_q_rank < _wvs_m_rank:
                                logger.warning(
                                    f"[WEAK VOLUME BLOCKED] {symbol} SHORT | "
                                    f"Kalite={_short_sig_quality} | Zayıf hacimde min {_wvs_min_q} kalite gerekli → SHORT engellendi."
                                )
                                if slot_mgr is not None and _short_slot_id is not None:
                                    slot_mgr.release_slot(symbol)
                                signal = Signal.HOLD

                    if signal != Signal.SELL:
                        pass  # Slot yoktu, devam etme
                    else:
                        sizing = pos_sizer.calculate(
                            symbol            = symbol,
                            price             = price,
                            available_balance = free_bal,
                            atr               = atr,
                            signal_quality    = _short_sig_quality,
                            slot_notional     = _short_slot_override_notional,
                        )
                    if signal == Signal.SELL and sizing:
                        # SHORT için SL/TP — Pullback Short stratejisinden al (varsa)
                        short_sizing = dict(sizing)
                        if short_strategy is not None and _short_result is not None and _short_result.should_enter:
                            # ATR tabanlı SL/TP: strateji hesapladı, doğrudan kullan
                            if _short_result.stop_loss and _short_result.stop_loss > 0:
                                short_sizing["stop_loss"]   = _short_result.stop_loss
                            if _short_result.take_profit and _short_result.take_profit > 0:
                                short_sizing["take_profit"] = _short_result.take_profit
                            logger.info(
                                f"[Pullback Short] {symbol} SL/TP override: "
                                f"SL=${short_sizing['stop_loss']:.4f} | TP=${short_sizing['take_profit']:.4f}"
                            )
                        elif atr:
                            short_sizing["stop_loss"]   = price * (1 + config.ATR_SL_MULTIPLIER * (atr / price))
                            short_sizing["take_profit"] = price * (1 - config.ATR_TP_MULTIPLIER * (atr / price))
                        else:
                            short_sizing["stop_loss"]   = price * (1 + config.STOP_LOSS_PCT)
                            short_sizing["take_profit"] = price * (1 - config.TAKE_PROFIT_PCT)

                        # Canlı mod log
                        if not config.PAPER_TRADING:
                            _short_strategy_name = short_strategy.name if short_strategy else strategy.name
                            _short_score_str = f"{_short_result.score}/10" if _short_result else "N/A"
                            logger.info(
                                f"\n{'═'*60}\n"
                                f"  ✅ CANLI SHORT İŞLEM GİRİŞ ONAYI — {symbol}\n"
                                f"{'─'*60}\n"
                                f"  Strateji        : {_short_strategy_name}\n"
                                f"  Puan            : {_short_score_str}\n"
                                f"  Kalite          : {_short_sig_quality}\n"
                                f"  Piyasa Rejimi   : {_current_market_regime}\n"
                                f"  Seçilen Slot    : {_short_slot_id or 'default'}\n"
                                f"  Slot Notional   : ${_short_slot_override_notional or 0:,.0f} USDT\n"
                                f"  Giriş Fiyatı    : ${price:,.4f}\n"
                                f"  Stop-Loss       : ${short_sizing.get('stop_loss', 0):,.4f}\n"
                                f"  Take-Profit     : ${short_sizing.get('take_profit', 0):,.4f}\n"
                                f"{'═'*60}"
                            )

                        _short_strategy_label = short_strategy.name if short_strategy else strategy.name
                        order = exe.submit_short(
                            symbol        = symbol,
                            price         = price,
                            sizing        = short_sizing,
                            strategy_name = _short_strategy_label,
                        )

                        if order is None and not config.PAPER_TRADING:
                            # Emir reddedildi — OKX'ten güncel bakiyeyi al
                            _sync_live_balance(client, trader, db, mode, day_start_balance)
                            # Slot serbest bırak — başarısız emir slotu bloke etmesin
                            if slot_mgr is not None:
                                slot_mgr.release_slot(symbol)
                                logger.info(f"[SLOT-SHORT] {symbol} slotu serbest bırakıldı (emir başarısız)")

                        if order and order.status == "filled":
                            pos = trader.positions.get(symbol)
                            # SHORT için Smart Exit parametrelerini ayarla
                            if pos:
                                # SHORT pozisyona özel profil kullan — strategy.name "Pullback Long" olduğu için
                                # doğrudan "Pullback Short" anahtarıyla arayın.
                                profile = get_profile("Pullback Short")
                                profile.apply_to_position(pos)
                                pos.lowest_price = price
                                logger.info(
                                    f"[Pullback Short] Profil uygulandı (SHORT) → "
                                    f"BE:%{profile.breakeven_trigger_pct*100:.1f} "
                                    f"TP1:%{profile.partial_tp1_pct*100:.1f}({int(profile.partial_tp1_size*100)}%) "
                                    f"TP2:%{profile.partial_tp2_pct*100:.1f}({int(profile.partial_tp2_size*100)}%) "
                                    f"Trailing:%{profile.trailing_stop_pct*100:.1f} "
                                    f"MaxBars:{profile.max_bars} MinProfitBar:{profile.min_profit_bar} MinProfitPct:%{profile.min_profit_pct*100:.1f}"
                                )

                                # ── Stage2: Kâr Alma Modu (SHORT) ──────────────
                                if getattr(config, "STAGE2_PROFIT_MODE", False):
                                    pos.usdt_tp1_trigger = getattr(config, "STAGE2_USDT_TRIGGER", 10.0)
                                    pos.usdt_tp1_size    = getattr(config, "STAGE2_PARTIAL_SIZE", 0.50)
                                    _s2_q_min = getattr(config, "STAGE2_RUNNER_QUALITY_MIN", "A")
                                    if _QUALITY_RANK.get(_short_sig_quality, 0) >= _QUALITY_RANK.get(_s2_q_min, 4):
                                        pos.tp2_pct           = getattr(config, "STAGE2_RUNNER_TP2_PCT", 0.05)
                                        pos.trailing_stop_pct = getattr(config, "STAGE2_RUNNER_TRAILING_PCT", 0.015)
                                        logger.info(
                                            f"[STAGE2 RUNNER SHORT] {symbol} kalite={_short_sig_quality} → "
                                            f"USDT tetik=${pos.usdt_tp1_trigger:.0f} | "
                                            f"Runner TP2=+{pos.tp2_pct*100:.0f}% Trail={pos.trailing_stop_pct*100:.1f}% aktif"
                                        )
                                    else:
                                        logger.info(
                                            f"[STAGE2 SHORT] {symbol} kalite={_short_sig_quality} → "
                                            f"USDT tetik=${pos.usdt_tp1_trigger:.0f} aktif (standart TP2={pos.tp2_pct*100:.1f}%)"
                                        )

                            # Tutarlı strateji etiketi — tüm DB kayıtlarında aynı
                            _short_db_label = short_strategy.name if short_strategy else strategy.name + " (SHORT)"
                            trade_id = None
                            if db and pos:
                                trade_id = db.open_trade(
                                    symbol        = symbol,
                                    price         = pos.entry_price,
                                    quantity      = pos.quantity,
                                    stop_loss     = pos.stop_loss,
                                    take_profit   = pos.take_profit,
                                    strategy_name = _short_db_label,
                                    mode          = mode,
                                    fee           = order.fee,
                                )
                                db.upsert_position(
                                    symbol        = symbol,
                                    entry_price   = pos.entry_price,
                                    current_price = price,
                                    quantity      = pos.quantity,
                                    pnl           = 0.0,
                                    pnl_pct       = 0.0,
                                    stop_loss     = pos.stop_loss,
                                    take_profit   = pos.take_profit,
                                    strategy_name = _short_db_label,
                                    trade_id      = trade_id,
                                    mode          = mode,
                                    side          = "short",
                                    leverage      = config.LEVERAGE,
                                )
                                db.write_order(
                                    client_order_id = order.client_order_id,
                                    symbol          = symbol,
                                    side            = "SHORT",
                                    order_type      = "market",
                                    quantity        = order.filled_qty,
                                    price           = order.price,
                                    status          = "filled",
                                    filled_price    = order.filled_price,
                                    filled_qty      = order.filled_qty,
                                    fee             = order.fee,
                                    strategy_name   = _short_db_label,
                                    mode            = mode,
                                    trade_id        = trade_id,
                                )
                                db.write_log(
                                    "info", "order",
                                    f"SHORT pozisyon açıldı: {symbol}",
                                    f"Strateji: {_short_db_label} | "
                                    f"Giriş: ${pos.entry_price:,.4f} | SL: ${pos.stop_loss:,.4f} | TP: ${pos.take_profit:,.4f}"
                                )
                            if trade_id:
                                trade_ids[symbol] = trade_id
                                if symbol in trader.positions:
                                    trader.positions[symbol].trade_id = trade_id
                                # short_sizing bu noktada kesinlikle tanımlı (SELL+sizing bloğu içindeyiz)
                                _short_risk_amt = short_sizing.get("risk_amount", 0.0) if short_sizing else 0.0
                                risk_mgr.record_trade_open(symbol, risk_amount=_short_risk_amt)

            # ── 3. Açık Pozisyon Güncellemesi ──────────────────────────────────
            if db:
                prices = mde.get_all_prices()
                for symbol, pos in trader.positions.items():
                    p        = prices.get(symbol, pos.entry_price)
                    upnl     = trader.unrealized_pnl(symbol, p) or 0
                    upnl_pct = trader.unrealized_pnl_pct(symbol, p) or 0
                    db.upsert_position(
                        symbol        = symbol,
                        entry_price   = pos.entry_price,
                        current_price = p,
                        quantity      = pos.quantity,
                        pnl           = upnl,
                        pnl_pct       = upnl_pct,
                        stop_loss     = pos.stop_loss,
                        take_profit   = pos.take_profit,
                        strategy_name = strategy.name,
                        trade_id      = trade_ids.get(symbol),
                        mode          = mode,
                        candles_held  = pos.candles_held,
                        side          = getattr(pos, "side", "long"),
                        leverage      = config.LEVERAGE,
                    )

            # ── 4. Periyodik Bakiye Snapshot ───────────────────────────────────
            if iteration % 5 == 0:
                if not config.PAPER_TRADING:
                    # Canlı mod: OKX'ten gerçek bakiyeyi çek, DB'ye yaz
                    port_val = _sync_live_balance(
                        client, trader, db, mode, day_start_balance
                    )
                elif db:
                    prices    = mde.get_all_prices()
                    port_val  = trader.portfolio_value(prices)
                    total_pnl = port_val - trader.initial_balance
                    daily_pnl = port_val - day_start_balance
                    db.write_balance(port_val, trader.balance, daily_pnl, total_pnl, mode)

            # ── 5. Readiness JSON Yaz (Dashboard için) ──────────────────────────
            if _readiness_per_coin:
                try:
                    import json as _json
                    from datetime import datetime as _dt, timezone as _tz2
                    _readiness_out = {
                        "updated_at": _dt.now(_tz2.utc).isoformat(),
                        "min_score":  getattr(strategy, "min_score", 7),
                        "coins":      _readiness_per_coin,
                    }
                    with open("/tmp/bot_readiness.json", "w") as _rf:
                        _json.dump(_readiness_out, _rf, ensure_ascii=False)
                except Exception as _rw_err:
                    logger.debug(f"[READINESS] JSON yazma hatası: {_rw_err}")

            # ── 6. Ekran Çıktısı ───────────────────────────────────────────────
            print_status(trader, mde, strategy.name, risk_mgr.status)

            if once:
                break

            logger.debug(f"Sonraki döngü: {config.LOOP_INTERVAL_SECONDS}s...")
            time.sleep(config.LOOP_INTERVAL_SECONDS)

    except KeyboardInterrupt:
        logger.info("Bot durduruldu (Ctrl+C).")
        if db:
            db.set_bot_running(False)
            db.write_log("info", "system", "Bot durduruldu (Ctrl+C).")
        prices = mde.get_all_prices()
        print_report(trader, prices)

    except Exception as e:
        logger.error(f"Kritik hata: {e}", exc_info=True)
        if db:
            db.set_bot_running(False)
            db.write_log("error", "system", f"Kritik hata: {e}")
        raise

    finally:
        if db:
            db.set_bot_running(False)
            db.close()


# ═══════════════════════════════════════════════════════════════════════════════
# MULTI-BOT DÖNGÜSÜ — Momentum + Reversal + Divergence
# ═══════════════════════════════════════════════════════════════════════════════

def run_multi_bot_loop(
    client,
    mde:       "MarketDataEngine",
    trader:    PaperTrader,
    risk_mgr:  "RiskManager",
    pos_sizer: "PositionSizer",
    exe:       "ExecutionEngine",
    db,
    once:      bool = False,
):
    """
    3 botu eş zamanlı çalıştıran ana döngü.
    Her sembol için Momentum + Reversal + Divergence botları çalışır.
    En yüksek güvenli sinyal risk motorundan geçirilir.
    """
    mode = "paper" if config.PAPER_TRADING else "live"
    leverage = getattr(config, "LEVERAGE", 1)

    # Botları oluştur
    momentum_bot  = MomentumBot(
        ema_fast          = config.EMA_FAST_PERIOD,
        ema_slow          = config.EMA_SLOW_PERIOD,
        ema_trend         = config.EMA_TREND_PERIOD,
        rsi_period        = config.RSI_PERIOD,
        min_confidence    = getattr(config, "MOMENTUM_MIN_SCORE", 65.0),
        sl_atr_multiplier = config.ATR_SL_MULTIPLIER,
        tp_atr_multiplier = config.ATR_TP_MULTIPLIER,
        max_holding_candles = config.MAX_HOLDING_CANDLES,
    )
    reversal_bot  = ReversalBot(
        rsi_period        = config.RSI_PERIOD,
        rsi_oversold      = config.RSI_OVERSOLD,
        rsi_overbought    = config.RSI_OVERBOUGHT,
        min_confidence    = getattr(config, "REVERSAL_MIN_SCORE", 68.0),
        sl_atr_multiplier = config.ATR_SL_MULTIPLIER * 0.8,
        tp_atr_multiplier = config.ATR_TP_MULTIPLIER * 0.85,
        max_holding_candles = max(16, config.MAX_HOLDING_CANDLES // 2),
    )
    divergence_bot = DivergenceBot(
        rsi_period        = config.RSI_PERIOD,
        min_confidence    = getattr(config, "DIVERGENCE_MIN_SCORE", 65.0),
        sl_atr_multiplier = config.ATR_SL_MULTIPLIER * 0.9,
        tp_atr_multiplier = config.ATR_TP_MULTIPLIER * 0.93,
        max_holding_candles = max(20, config.MAX_HOLDING_CANDLES // 2),
    )
    bots = [momentum_bot, reversal_bot, divergence_bot]

    logger.info(
        f"Multi-Bot başlatıldı — "
        f"Botlar: {[b.name for b in bots]} | "
        f"Çiftler: {mde.symbols} | Mod: {mode.upper()} | Kaldıraç: {leverage}x"
    )
    # Canlı modda gerçek OKX bakiyesini başlangıç bakiyesi olarak kullan
    if not config.PAPER_TRADING:
        from exchange.okx_live_client import OKXLiveClient
        if isinstance(client, OKXLiveClient) and client.is_authenticated():
            free_bal  = client.get_usdt_balance()
            total_eq  = client.get_total_equity()
            # Kill-switch referansı için SADECE serbest bakiyeyi kullan
            # Manuel pozisyonların (PUMP vb.) kayıpları bot kill-switch'ini etkilemez
            reference = free_bal if free_bal > 0 else total_eq
            if reference > 0:
                trader.balance         = reference
                trader.initial_balance = reference
                trader.available_usdt  = free_bal   # İlk iterasyonda doğru serbest bakiye
                logger.info(
                    f"[CANLI] OKX bakiyesi yüklendi: "
                    f"Serbest=${free_bal:,.2f} | Toplam (equity)=${total_eq:,.2f} USDT"
                )

    logger.info(f"Başlangıç bakiyesi: ${trader.initial_balance:,.2f} USDT")

    if db:
        db.set_bot_running(True)
        db.sync_initial_balance(trader.initial_balance)
        db.write_log("info", "system", "Multi-Bot başlatıldı",
                     f"Botlar: MomentumBot+ReversalBot+DivergenceBot | "
                     f"Çiftler: {mde.symbols} | {leverage}x kaldıraç")
        db.write_balance(trader.initial_balance, trader.initial_balance, 0.0, 0.0, mode)

    trade_ids: Dict[str, int] = {}
    day_start_balance = trader.initial_balance
    current_day = date.today()
    risk_mgr.set_day_start_value(day_start_balance)
    iteration = 0

    try:
        while True:
            iteration += 1

            # Her döngüde DB'den mod/leverage kontrolü (UI değişikliklerini yakalar)
            if iteration % 5 == 0:
                old_paper = config.PAPER_TRADING
                load_mode_from_db(risk_mgr)   # risk_mgr parametreleri de eş zamanlı güncellenir
                if old_paper != config.PAPER_TRADING:
                    mode = "paper" if config.PAPER_TRADING else "live"
                    mode_str = "PAPER" if config.PAPER_TRADING else "🔴 LIVE"
                    logger.info(f"[MOD DEĞİŞİKLİĞİ] Trading modu değişti: {mode_str}")

                    # Execution engine'i güncelle — paper↔live geçişte kritik
                    if not config.PAPER_TRADING and client.is_authenticated():
                        exe.update_live_mode(live_mode=True, client=client)
                        _free = client.get_usdt_balance()
                        _total = client.get_total_equity()
                        _ref = _total if _total > 0 else _free
                        if _ref > 0:
                            trader.balance         = _ref
                            trader.initial_balance = _ref
                            day_start_balance      = _ref
                            risk_mgr.set_day_start_value(day_start_balance)
                            risk_mgr.reset_kill_switch()
                            logger.info(
                                f"[CANLI] Kill-switch sıfırlandı. "
                                f"Günlük başlangıç bakiyesi: ${_ref:,.2f} USDT "
                                f"(serbest=${_free:,.2f})"
                            )
                    else:
                        exe.update_live_mode(live_mode=False)

            today = date.today()
            if today != current_day:
                if not config.PAPER_TRADING:
                    _total = client.get_total_equity() if client.is_authenticated() else 0
                    day_start_balance = _total if _total > 0 else (client.get_usdt_balance() if client.is_authenticated() else trader.balance)
                else:
                    prices = mde.get_all_prices()
                    day_start_balance = trader.portfolio_value(prices)
                current_day = today
                risk_mgr.set_day_start_value(day_start_balance)

            # ── 1. Piyasa Verisi ────────────────────────────────────────────────
            mde.refresh()
            prices  = mde.get_all_prices()
            port_val = trader.portfolio_value(prices)

            # ── 1b. DB Pozisyonlarını Sahiplen ──────────────────────────────────
            # LIVE modda: Yalnızca OKX'te gerçekten var olan pozisyonları sahiplen.
            _adopt_db_positions(
                db, trader, trade_ids,
                client=client,
                live_mode=not config.PAPER_TRADING,
            )

            # ── 2. Her Sembol İçin Bot Döngüsü ────────────────────────────────
            for symbol in mde.symbols:
                price = mde.get_price(symbol)
                if not price:
                    continue

                if symbol in trader.positions:
                    trader.positions[symbol].candles_held += 1

                # ── 2a-pre. Trend Güç Değerlendirmesi (Akıllı Zaman Bazlı Çıkış) ──
                if symbol in trader.positions:
                    _pos_te2 = trader.positions[symbol]
                    if _pos_te2.max_bars > 0 and _pos_te2.candles_held >= _pos_te2.max_bars:
                        try:
                            _df_te2 = mde.get_ohlcv(symbol)
                            if _df_te2 is not None and len(_df_te2) >= 20:
                                from strategies.pullback_long import _extract_indicators as _ext_ind_te2
                                _ind_te2 = _ext_ind_te2(_df_te2)
                                if _ind_te2:
                                    _adx_te2 = getattr(config, "SMART_EXIT_ADX_STRONG_MIN", 25)
                                    _pos_te2.trend_is_strong = (
                                        _ind_te2.get("adx", 0) >= _adx_te2
                                        and _ind_te2.get("ema9", 0) > _ind_te2.get("ema21", 0) > _ind_te2.get("ema50", 0)
                                        and price > _ind_te2.get("ema50", 0)
                                    )
                        except Exception:
                            pass

                # ── 2a. Triple-Barrier Çıkış Kontrolü ──────────────────────────
                if symbol in trader.positions:
                    pos_snap = trader.positions[symbol]
                    pnl = trader.check_exits(symbol, price)
                    if pnl is not None:
                        cost    = pos_snap.margin if pos_snap.margin > 0 else pos_snap.quantity * pos_snap.entry_price
                        pnl_pct = (pnl / cost) * 100 if cost > 0 else 0
                        trade_id = trade_ids.pop(symbol, None)
                        exit_reason = getattr(pos_snap, "exit_reason", "exit") or "exit"

                        # ── CANLI MOD: OKX'e gerçek kapatma emri gönder ────────
                        okx_close_ok = True  # paper modda her zaman başarılı say
                        if not config.PAPER_TRADING:
                            okx_close_ok = exe.submit_force_close(
                                symbol        = symbol,
                                side          = pos_snap.side,
                                quantity      = pos_snap.quantity,
                                price         = price,
                                reason        = exit_reason,
                                strategy_name = pos_snap.strategy_name,
                            )
                            if okx_close_ok:
                                _sync_live_balance(client, trader, db, mode, day_start_balance)
                            else:
                                phantom_confirmed = symbol in getattr(exe, "_confirmed_phantom_symbols", set())
                                if phantom_confirmed:
                                    # OKX kesin olarak "pozisyon yok" dedi — hafızadan sil, döngüyü kır
                                    logger.warning(
                                        f"[PHANTOM-CLEAR] {symbol}: OKX bu pozisyonun var olmadığını doğruladı. "
                                        f"Hafızadan ve DB'den siliniyor."
                                    )
                                    trader.positions.pop(symbol, None)
                                    if slot_mgr is not None:
                                        slot_mgr.release_slot(symbol)
                                    if db:
                                        db.delete_position(symbol)
                                        db.write_log(
                                            "warning", "system",
                                            f"Phantom pozisyon temizlendi: {symbol}",
                                            f"OKX bu pozisyonun var olmadığını bildirdi. Otomatik silindi."
                                        )
                                else:
                                    # Geçici OKX hatası — pozisyonu geri yükle, sonraki iterasyonda tekrar dene
                                    trader.positions[symbol] = pos_snap
                                    if db:
                                        db.write_log(
                                            "error", "order",
                                            f"OKX kapatma BAŞARISIZ: {symbol}",
                                            f"Pozisyon DB'de korunuyor, manuel kontrol gerekebilir."
                                        )
                                    logger.error(
                                        f"[EXIT] {symbol} OKX kapatma başarısız — "
                                        f"pozisyon geri yüklendi, bu iterasyon atlanıyor."
                                    )

                        if okx_close_ok:
                            if db:
                                db.write_trade(
                                    symbol        = symbol,
                                    side          = "CLOSE",
                                    entry_price   = pos_snap.entry_price,
                                    exit_price    = price,
                                    quantity      = pos_snap.quantity,
                                    pnl           = pnl,
                                    pnl_pct       = pnl_pct,
                                    fee           = 0.0,
                                    strategy_name = pos_snap.strategy_name,
                                    exit_reason   = exit_reason,
                                    mode          = mode,
                                    candles_held  = pos_snap.candles_held,
                                )
                                if trade_id:
                                    db.close_trade(trade_id, price, pnl, pnl_pct, exit_reason)
                                db.delete_position(symbol)
                            risk_mgr.record_trade_result(pnl, symbol=symbol)
                            if slot_mgr is not None:
                                slot_mgr.release_slot(symbol)

                            # ── Standart Canlı İşlem Raporu (Signal Engine) ──────
                            try:
                                _r_meta   = _trade_meta.pop(symbol, {})
                                _r_ep     = pos_snap.entry_price
                                _r_sl     = pos_snap.stop_loss
                                _r_tp     = pos_snap.take_profit
                                _r_risk   = abs(_r_ep - _r_sl) if _r_sl > 0 else 0
                                _r_tp2    = None
                                _r_be     = getattr(pos_snap, "break_even_trigger_price", 0) or None
                                _r_fee    = getattr(pos_snap, "entry_fee", 0.0) or 0.0
                                _r_gross  = pnl + _r_fee
                                _r_margin = pos_snap.margin if pos_snap.margin > 0 else (pos_snap.quantity * _r_ep / getattr(config, "LEVERAGE", 10))
                                _gen_trade_report(
                                    symbol               = symbol,
                                    strategy_name        = pos_snap.strategy_name or strategy.name,
                                    side                 = pos_snap.side,
                                    trade_id             = trade_id,
                                    mode                 = mode,
                                    paper_trading        = config.PAPER_TRADING,
                                    opened_at            = _r_meta.get("opened_at"),
                                    closed_at            = __import__("datetime").datetime.now(__import__("datetime").timezone.utc),
                                    regime               = _r_meta.get("regime"),
                                    signal_score         = _r_meta.get("signal_score"),
                                    signal_score_max     = _r_meta.get("signal_score_max", 100.0),
                                    norm_score           = _r_meta.get("norm_score"),
                                    quality              = _r_meta.get("quality"),
                                    slot_id              = _r_meta.get("slot_id"),
                                    slot_notional        = _r_meta.get("slot_notional"),
                                    leverage             = getattr(config, "LEVERAGE", 10),
                                    sent_qty             = pos_snap.quantity,
                                    filled_qty           = _r_meta.get("filled_qty") or pos_snap.quantity,
                                    filled_price         = _r_meta.get("filled_price") or _r_ep,
                                    filled_notional      = _r_meta.get("actual_notional") or (pos_snap.quantity * _r_ep),
                                    filled_margin        = _r_margin,
                                    exchange_order_id    = _r_meta.get("exchange_order_id"),
                                    entry_price          = _r_ep,
                                    stop_loss            = _r_sl,
                                    take_profit          = _r_tp,
                                    tp2_price            = _r_tp2,
                                    break_even_trigger   = _r_be,
                                    trailing_stop_pct    = getattr(pos_snap, "trailing_stop_pct", 0) or None,
                                    min_profit_bar       = getattr(pos_snap, "min_profit_bar", 0) or None,
                                    max_bars             = getattr(pos_snap, "max_bars", 0) or None,
                                    exit_price           = price,
                                    exit_reason          = exit_reason,
                                    gross_pnl            = _r_gross,
                                    commission           = _r_fee,
                                    net_pnl              = pnl,
                                    pnl_pct              = pnl_pct,
                                    candles_held         = pos_snap.candles_held,
                                    okx_open_confirmed   = _r_meta.get("okx_open_confirmed", not config.PAPER_TRADING),
                                    okx_close_confirmed  = okx_close_ok and not config.PAPER_TRADING,
                                    db_recorded          = db is not None and trade_id is not None,
                                    on_trade_closed_ran  = False,
                                    cooldown_set         = False,
                                    risk_mgr_updated     = True,
                                )
                            except Exception as _rpt_err:
                                logger.warning(f"[RAPOR] Signal Engine rapor hatası: {_rpt_err}")

                # ── 2b. Risk Kontrolü (pozisyon açık değilse) ──────────────────
                if symbol in trader.positions:
                    continue

                risk_ok, risk_reason = risk_mgr.check(
                    symbol          = symbol,
                    current_balance = trader.balance,
                    initial_balance = trader.initial_balance,
                    open_positions  = trader.positions,
                    portfolio_value = port_val,
                )
                if not risk_ok:
                    logger.debug(f"{symbol}: Risk reddi — {risk_reason}")
                    continue

                # ── 2c. OHLCV Verisi Al ────────────────────────────────────────
                df = mde.get_ohlcv(symbol)
                if df is None or len(df) < 60:
                    continue

                # ── 2d. Her Botu Çalıştır, Sinyalleri Topla ──────────────────
                signals = []
                for bot in bots:
                    try:
                        sig = bot.generate_signal(symbol, df, price)
                        if sig.is_actionable(bot.min_confidence):
                            signals.append(sig)
                            logger.info(
                                f"[{bot.name}] {symbol} {sig.side} | "
                                f"Güven: {sig.confidence:.1f} | "
                                f"Nedenler: {', '.join(sig.reasons[:2])}"
                            )
                    except Exception as e:
                        logger.warning(f"[{bot.name}] {symbol} hata: {e}")

                if not signals:
                    continue

                # ── 2e. En İyi Sinyali Seç (en yüksek güven) ─────────────────
                best = max(signals, key=lambda s: s.confidence)

                # ── 2e2. BTC Rejim Filtresi (altcoin LONG için) ───────────────
                if best.side == "BUY" and symbol != "BTCUSDT":
                    btc_df = mde.get_ohlcv("BTCUSDT")
                    if btc_df is not None:
                        regime_ok, regime_reason = risk_mgr.check_btc_regime(
                            btc_df, symbol, best.side
                        )
                        if not regime_ok:
                            logger.info(f"[BTC REJİM] {symbol} atlandı: {regime_reason}")
                            continue

                # ── 2e3. Hacim Filtresi ────────────────────────────────────────
                # OHLCV son mumun hacmini kullan (yaklaşık kontrol)
                vol_usdt = float(df["volume"].iloc[-1]) * float(df["close"].iloc[-1])
                vol_ok, vol_reason = risk_mgr.check_volume_filter(symbol, vol_usdt)
                if not vol_ok:
                    logger.debug(f"[HAÇİM] {symbol} atlandı: {vol_reason}")
                    continue

                # ── 2e4. Serbest Bakiye Kontrolü (Canlı mod) ──────────────────
                # trader.available_usdt = OKX gerçek serbest USDT (kaynaktan sync edildi)
                # Eğer serbest USDT yetersizse (marjin başka pozisyonda kilitli) emir
                # açmayı deneme — OKX zaten 51008 ile reddedecek.
                MIN_FREE_USDT = 3.0   # Minimum emir için gereken serbest USDT
                free = getattr(trader, "available_usdt", trader.balance)
                if free < MIN_FREE_USDT:
                    logger.debug(
                        f"[CANLI] {symbol}: Serbest bakiye ${free:.2f} < ${MIN_FREE_USDT:.0f} — "
                        f"emir atlandı (tüm bakiye pozisyonlarda kilitli olabilir)"
                    )
                    continue

                # ── 2f. Boyutlandırma ──────────────────────────────────────────
                size_mult = risk_mgr.position_size_multiplier()
                sizing = pos_sizer.calculate(
                    symbol            = symbol,
                    price             = price,
                    available_balance = free,   # Serbest USDT — toplam equity değil
                    atr               = best.atr if best.atr > 0 else None,
                )
                if not sizing:
                    continue

                if size_mult < 1.0:
                    sizing["quantity"] = sizing.get("quantity", 0) * size_mult
                    logger.info(f"Savunma modu: {symbol} pozisyon ×{size_mult:.1f} küçültüldü")

                # Botun SL/TP değerleri geçerliyse kullan
                if best.stop_loss > 0:
                    sizing["stop_loss"] = best.stop_loss
                if best.take_profit > 0:
                    sizing["take_profit"] = best.take_profit

                # ── 2g. Emri Gönder ────────────────────────────────────────────
                if best.side == "BUY":
                    order = exe.submit_buy(
                        symbol        = symbol,
                        price         = price,
                        sizing        = sizing,
                        strategy_name = best.bot_name,
                    )
                elif best.side == "SELL":
                    order = exe.submit_short(
                        symbol        = symbol,
                        price         = price,
                        sizing        = sizing,
                        strategy_name = best.bot_name,
                    )
                else:
                    continue

                if order and order.status == "filled":
                    pos = trader.positions.get(symbol)
                    if pos:
                        profile = get_profile(best.bot_name)
                        profile.apply_to_position(pos)
                        pos.highest_price     = price if best.side == "BUY" else 0
                        pos.lowest_price      = price if best.side == "SELL" else 9e18
                        pos.max_holding_candles = best.max_holding_candles
                        logger.info(
                            f"[{best.bot_name}] Profil uygulandı ({'LONG' if best.side == 'BUY' else 'SHORT'}) → "
                            f"Kaldıraç:{profile.leverage}x  BE:%{profile.breakeven_trigger_pct*100:.1f} "
                            f"TP1:%{profile.partial_tp1_pct*100:.1f}({int(profile.partial_tp1_size*100)}%) "
                            f"TP2:%{profile.partial_tp2_pct*100:.1f}({int(profile.partial_tp2_size*100)}%) "
                            f"Trailing:%{profile.trailing_stop_pct*100:.1f} MaxBars:{profile.max_bars}"
                        )

                    trade_id = None
                    if db and pos:
                        trade_id = db.open_trade(
                            symbol        = symbol,
                            price         = pos.entry_price,
                            quantity      = pos.quantity,
                            stop_loss     = pos.stop_loss,
                            take_profit   = pos.take_profit,
                            strategy_name = best.bot_name,
                            mode          = mode,
                            fee           = order.fee,
                        )
                        if trade_id:
                            trade_ids[symbol] = trade_id
                            if symbol in trader.positions:
                                trader.positions[symbol].trade_id = trade_id
                        db.upsert_position(
                            symbol        = symbol,
                            entry_price   = pos.entry_price,
                            current_price = price,
                            quantity      = pos.quantity,
                            pnl           = 0.0,
                            pnl_pct       = 0.0,
                            stop_loss     = pos.stop_loss,
                            take_profit   = pos.take_profit,
                            strategy_name = best.bot_name,
                            trade_id      = trade_id,
                            mode          = mode,
                            side          = getattr(best, "side", "long").lower(),
                            leverage      = leverage,
                        )
                        db.write_log(
                            "info", "order",
                            f"[{best.bot_name}] {symbol} {best.side} pozisyon açıldı",
                            f"Güven: {best.confidence:.1f} | "
                            f"Giriş: ${pos.entry_price:,.4f} | "
                            f"SL: ${pos.stop_loss:,.4f} | TP: ${pos.take_profit:,.4f} | "
                            f"{leverage}x kaldıraç"
                        )

                    # ── Trade Reporter: Signal Engine açılış metadata'sı ──────────
                    if pos and order and order.status == "filled":
                        try:
                            _se_notional = pos.quantity * pos.entry_price
                            _trade_meta[symbol] = {
                                "exchange_order_id":  getattr(order, "exchange_order_id", None),
                                "opened_at":          getattr(pos, "entry_time", None),
                                "signal_score":       getattr(best, "confidence", None),
                                "signal_score_max":   100.0,
                                "norm_score":         getattr(best, "confidence", None),
                                "quality":            None,
                                "slot_id":            None,
                                "slot_notional":      None,
                                "actual_notional":    _se_notional,
                                "actual_margin":      pos.margin if pos else 0.0,
                                "filled_qty":         getattr(order, "filled_qty", pos.quantity),
                                "filled_price":       getattr(order, "filled_price", pos.entry_price),
                                "regime":             None,
                                "okx_open_confirmed": not config.PAPER_TRADING and order is not None,
                            }
                        except Exception as _meta_err:
                            logger.debug(f"[RAPOR] Signal Engine meta kayıt hatası: {_meta_err}")

                    # ── Canlı mod: işlem açıldıktan hemen sonra bakiyeyi güncelle ──
                    if not config.PAPER_TRADING:
                        _sync_live_balance(client, trader, db, mode, day_start_balance)
                        logger.info(
                            f"[CANLI] {symbol} işlemi sonrası bakiye güncellendi: "
                            f"${trader.available_usdt:,.2f} USDT serbest"
                        )
                    # Bu döngüde tek işlem aç — marjin yeterliliği için döngüyü kır
                    break

                elif order is None and not config.PAPER_TRADING:
                    # ── Emir reddedildi (51008 veya başka OKX hatası) ──────────
                    # Gerçek bakiyeyi hemen senkronize et — eski değer sorun çıkarabilir
                    logger.warning(
                        f"[CANLI] {symbol} emri başarısız — bakiye senkronize ediliyor…"
                    )
                    _sync_live_balance(client, trader, db, mode, day_start_balance)
                    if trader.available_usdt < MIN_FREE_USDT:
                        logger.warning(
                            f"[CANLI] Yetersiz bakiye (${trader.available_usdt:.2f}) — "
                            f"bu döngüde daha fazla emir gönderilmiyor."
                        )
                        break

            # ── 3. Açık Pozisyon DB Güncelle ────────────────────────────────────
            if db:
                for sym, pos in list(trader.positions.items()):
                    px = prices.get(sym, 0)
                    if px:
                        upnl     = trader.unrealized_pnl(sym, px) or 0
                        upnl_pct = trader.unrealized_pnl_pct(sym, px) or 0
                        db.upsert_position(
                            symbol        = sym,
                            entry_price   = pos.entry_price,
                            current_price = px,
                            quantity      = pos.quantity,
                            pnl           = upnl,
                            pnl_pct       = upnl_pct,
                            stop_loss     = pos.stop_loss,
                            take_profit   = pos.take_profit,
                            strategy_name = pos.strategy_name,
                            trade_id      = trade_ids.get(sym),
                            mode          = mode,
                            side          = getattr(pos, "side", "long"),
                            leverage      = leverage,
                        )

            # ── 4. Bakiye Snapshot ────────────────────────────────────────────
            if iteration % 5 == 0:
                if not config.PAPER_TRADING:
                    # Canlı mod: OKX'ten gerçek bakiyeyi çek, DB'ye yaz
                    port_val = _sync_live_balance(
                        client, trader, db, mode, day_start_balance
                    )
                elif db:
                    prices    = mde.get_all_prices()
                    port_val  = trader.portfolio_value(prices)
                    total_pnl = port_val - trader.initial_balance
                    daily_pnl = port_val - day_start_balance
                    db.write_balance(port_val, trader.balance, daily_pnl, total_pnl, mode)

            # ── 5. Ekran Çıktısı ──────────────────────────────────────────────
            print_status(trader, mde, "Multi-Bot (Momentum+Reversal+Divergence)", risk_mgr.status)

            if once:
                break

            time.sleep(config.LOOP_INTERVAL_SECONDS)

    except KeyboardInterrupt:
        logger.info("Multi-Bot durduruldu.")
        if db:
            db.set_bot_running(False)
        prices = mde.get_all_prices()
        print_report(trader, prices)

    except Exception as e:
        logger.error(f"Multi-Bot kritik hata: {e}", exc_info=True)
        if db:
            db.set_bot_running(False)
        raise

    finally:
        if db:
            db.set_bot_running(False)
            db.close()


# ═══════════════════════════════════════════════════════════════════════════════
# GİRİŞ NOKTASI
# ═══════════════════════════════════════════════════════════════════════════════

_pnl_stop_event = threading.Event()

def _realtime_pnl_loop(trader, client, db, interval: int = 5):
    """
    Arka plan thread'i — her {interval} saniyede bir açık pozisyonların
    anlık P&L değerini hesaplayıp DB'ye yazar.
    Ana loop 60 saniyelik uyku yapsa bile dashboard gerçek zamanlı güncellenir.
    """
    logger.debug(f"[PNL-THREAD] Gerçek zamanlı P&L güncelleyici başlatıldı (her {interval}s)")
    while not _pnl_stop_event.is_set():
        try:
            positions = getattr(trader, "positions", {})
            if positions and db:
                for symbol, pos in list(positions.items()):
                    try:
                        # ── HAYALET KORUMA ────────────────────────────────────────
                        # Canlı modda: OKX sync en az bir kez çalıştıysa ve bu sembol
                        # OKX'te yoksa DB'ye yazmayı atla. Aksi hâlde API server'ın
                        # sildiği kaydı her 5s'de yeniden oluşturan "hayalet döngüsü"
                        # oluşur (upsert ↔ delete çatışması).
                        if (
                            not config.PAPER_TRADING
                            and _okx_sync_done
                            and symbol not in _okx_live_symbols
                        ):
                            logger.debug(
                                f"[PNL-THREAD] {symbol} OKX sync'te yok → DB yazımı atlandı "
                                f"(hayalet döngüsü önlendi)"
                            )
                            continue

                        # Anlık fiyat
                        price = None
                        if hasattr(client, "get_price"):
                            price = client.get_price(symbol)
                        elif hasattr(client, "get_ticker"):
                            t = client.get_ticker(symbol)
                            price = t.get("last") if t else None

                        if price is None or price <= 0:
                            continue

                        # P&L hesapla
                        upnl     = trader.unrealized_pnl(symbol, price) or 0.0
                        upnl_pct = trader.unrealized_pnl_pct(symbol, price) or 0.0
                        qty      = float(getattr(pos, "quantity", 0))
                        entry    = float(getattr(pos, "entry_price", 0))
                        sl       = float(getattr(pos, "stop_loss", 0) or 0)
                        tp       = float(getattr(pos, "take_profit", 0) or 0)
                        trade_id = getattr(pos, "trade_id", None)
                        mode     = "live" if not config.PAPER_TRADING else "paper"
                        _pos_strategy = getattr(pos, "strategy_name", None) or "Pullback Long"

                        db.upsert_position(
                            symbol        = symbol,
                            entry_price   = entry,
                            current_price = price,
                            quantity      = qty,
                            pnl           = upnl,
                            pnl_pct       = upnl_pct,
                            stop_loss     = sl,
                            take_profit   = tp,
                            mode          = mode,
                            strategy_name = _pos_strategy,
                            trade_id      = trade_id,
                            side          = getattr(pos, "side", "long"),
                            leverage      = config.LEVERAGE,
                        )
                    except Exception as e:
                        logger.debug(f"[PNL-THREAD] {symbol} P&L güncellenemedi: {e}")
        except Exception as e:
            logger.debug(f"[PNL-THREAD] Döngü hatası: {e}")

        _pnl_stop_event.wait(timeout=interval)

    logger.debug("[PNL-THREAD] P&L güncelleyici durduruldu.")


def main():
    parser = argparse.ArgumentParser(description="Kripto Trading Bot v3")
    parser.add_argument(
        "--strategy",
        default=config.ACTIVE_STRATEGY,
        choices=["signal_engine", "pullback", "ema_crossover", "ma_crossover",
                 "rsi", "macd", "bollinger", "combined", "multi_bot"],
        help="Kullanılacak strateji (multi_bot: 3 bot eş zamanlı)"
    )
    parser.add_argument("--once",        action="store_true", help="Tek döngü çalıştır")
    parser.add_argument("--no-db",       action="store_true", help="DB entegrasyonunu devre dışı bırak")
    parser.add_argument("--report",      action="store_true", help="Performans raporu göster")
    parser.add_argument("--backtest",    action="store_true", help="Backtest çalıştır")
    parser.add_argument("--walkforward", action="store_true", help="Walk-forward test çalıştır")
    args = parser.parse_args()

    print_banner()

    # ── Motori Kur ─────────────────────────────────────────────────────────────
    client   = create_client()
    strategy = None if args.strategy == "multi_bot" else build_strategy(args.strategy)

    # Trading modu ve leverage: DB'den oku, config.py'yi güncelle
    load_mode_from_db()
    logger.info(
        f"Mod: {'PAPER' if config.PAPER_TRADING else '🔴 LIVE'} | "
        f"Kaldıraç: {config.LEVERAGE}x | Borsa: {config.EXCHANGE.upper()}"
    )

    # Coin listesi: DB'den oku, yoksa config.py'ye düş
    trading_pairs = load_trading_pairs_from_db()
    logger.info(f"İzleme listesi: {trading_pairs}")

    trader = PaperTrader(
        initial_balance      = config.INITIAL_BALANCE_USDT,
        trade_amount_pct     = config.TRADE_AMOUNT_PCT,
        stop_loss_pct        = config.STOP_LOSS_PCT,
        take_profit_pct      = config.TAKE_PROFIT_PCT,
        fee_rate             = config.FEE_RATE,
        slippage_pct         = config.SLIPPAGE_PCT,
        max_holding_candles  = config.MAX_HOLDING_CANDLES,
        leverage             = getattr(config, "LEVERAGE", 1),
    )

    mde = MarketDataEngine(
        client      = client,
        symbols     = trading_pairs,
        timeframe   = config.KLINE_INTERVAL,
        ohlcv_limit = config.KLINE_LIMIT,
    )

    risk_mgr = RiskManager(
        max_open_positions   = config.MAX_OPEN_POSITIONS,
        daily_max_loss_pct   = config.DAILY_MAX_LOSS_PCT,
        max_consecutive_loss = config.MAX_CONSECUTIVE_LOSS,
        kill_switch          = config.KILL_SWITCH,
        max_drawdown_pct     = getattr(config, "MAX_DRAWDOWN_PCT",     0.15),
        drawdown_warn_pct    = getattr(config, "DRAWDOWN_WARN_PCT",    0.08),
        defense_loss_count   = getattr(config, "DEFENSE_LOSS_COUNT",   3),
        defense_size_factor  = getattr(config, "DEFENSE_SIZE_FACTOR",  0.5),
    )
    # v2: config'den günlük sembol sınırını wire et
    risk_mgr.max_daily_trades_per_symbol = getattr(
        config, "MAX_DAILY_TRADES_PER_SYMBOL", 2
    )
    # v3: Toplam açık risk limiti
    risk_mgr.max_total_open_risk_pct = getattr(
        config, "MAX_TOTAL_OPEN_RISK_PCT", 0.02
    )

    # ─── Canlı mod: PositionSizer oluşturulmadan önce gerçek OKX bakiyesini yükle ─
    # Bu olmadan _init_bal=$10000 (varsayılan) olur → yanlış trade_pct seçilir.
    if not config.PAPER_TRADING:
        from exchange.okx_live_client import OKXLiveClient
        if isinstance(client, OKXLiveClient) and client.is_authenticated():
            _okx_free = client.get_usdt_balance()
            _okx_eq   = client.get_total_equity()
            _okx_ref  = _okx_eq if _okx_eq > 0 else _okx_free
            if _okx_ref > 0:
                trader.balance         = _okx_ref
                trader.initial_balance = _okx_ref
                trader.available_usdt  = _okx_free
                logger.info(
                    f"[CANLI] main() OKX bakiyesi: "
                    f"Serbest=${_okx_free:,.2f} | Equity=${_okx_ref:,.2f} USDT"
                )

    # ─── Pozisyon Boyutlandırma Parametreleri ────────────────────────────────
    _init_bal   = trader.initial_balance  # Gerçek OKX equity veya paper bakiye
    _config_lev = getattr(config, "LEVERAGE", 1)
    _leverage   = _config_lev

    # Adaptif minimum işlem değeri (OKX lot boyutu uyumu)
    if _init_bal < 2.0:
        _min_trade = 0.05
    elif _init_bal < 10.0:
        _min_trade = 0.50
    else:
        _min_trade = 1.0

    # ─── UI Ayarından Pozisyon Boyutu Hesapla ────────────────────────────────
    # Öncelik: DB → config → akıllı varsayılan
    _amount_type = getattr(config, "TRADE_AMOUNT_TYPE", "auto")
    _amount_val  = getattr(config, "TRADE_AMOUNT", 0.0)
    _max_pos     = max(1, config.MAX_OPEN_POSITIONS)

    if _amount_type == "auto" or _amount_val <= 0:
        # Otomatik: bakiyeyi eşit böl + %10 güvenlik tamponu
        _trade_pct = (1.0 / _max_pos) * 0.90
        _sizing_label = f"Otomatik ({_max_pos} pozisyon)"

    elif _amount_type == "fixed":
        # Sabit USDT: bakiyeye oranla dönüştür (canlı moda uygun)
        _trade_pct = min(_amount_val / _init_bal, 0.95) if _init_bal > 0 else 0.10
        _sizing_label = f"Sabit ${_amount_val:.0f} USDT"

    elif _amount_type == "percent":
        # Bakiyenin yüzdesi
        _trade_pct = min(_amount_val / 100.0, 0.95)
        _sizing_label = f"Yüzde %{_amount_val:.0f}"

    else:
        # Güvenli varsayılan
        _trade_pct = 0.33
        _sizing_label = "Varsayılan (%33)"

    # Paper mod küçük hesap koruması
    if config.PAPER_TRADING and _init_bal < 20.0:
        _trade_pct = max(_trade_pct, 0.90)
        _min_trade = 1.0

    _per_trade_usdt = _init_bal * _trade_pct
    logger.info(
        f"[POZİSYON BOYUTU] Mod: {_sizing_label} | "
        f"Trade pct: %{_trade_pct*100:.1f} | "
        f"İşlem başı marjin: ~${_per_trade_usdt:.2f} | "
        f"Notional: ~${_per_trade_usdt * _leverage:.2f} ({_leverage}x) | "
        f"Bakiye: ${_init_bal:.2f}"
    )

    pos_sizer = PositionSizer(
        mode              = config.POSITION_SIZING_MODE,
        risk_per_trade    = config.RISK_PER_TRADE_PCT,
        trade_amount_pct  = _trade_pct,
        atr_sl_multiplier = config.ATR_SL_MULTIPLIER,
        atr_tp_multiplier = config.ATR_TP_MULTIPLIER,
        stop_loss_pct     = config.STOP_LOSS_PCT,
        take_profit_pct   = config.TAKE_PROFIT_PCT,
        fee_rate          = config.FEE_RATE,
        slippage_pct      = config.SLIPPAGE_PCT,
        min_trade_value   = _min_trade,
        leverage          = _leverage,
        # Risk bazlı notional limitleri (v3)
        min_notional      = getattr(config, "POSITION_MIN_USDT", 75.0),
        max_notional      = getattr(config, "POSITION_MAX_USDT", 150.0),
    )

    # ─── Kalite Ağırlıklı 5 Slot Motoru ──────────────────────────────────
    slot_mgr = SlotManager()
    logger.info(
        f"[SLOT] 5-slot motoru başlatıldı | "
        f"Feature: {'AKTİF' if getattr(config, 'USE_QUALITY_WEIGHTED_SLOT_STRATEGY', True) else 'PASİF'}"
    )

    exe = ExecutionEngine(
        paper_trader = trader,
        live_mode    = not config.PAPER_TRADING,
        leverage     = _leverage,
    )

    # Live trading modunda: gerçek OKX client'ı execution engine'e bağla
    if not config.PAPER_TRADING:
        from exchange.okx_live_client import OKXLiveClient
        if isinstance(client, OKXLiveClient) and client.is_authenticated():
            exe.set_live_client(client)
            logger.info("Live trading: OKX bağlayıcısı execution engine'e bağlandı.")

            # Cross-margin kaldıraç başlat (tüm semboller için)
            _live_leverage = getattr(config, "LEVERAGE", 10)
            client.initialize_margin_trading(trading_pairs, _live_leverage)
            logger.info(f"Cross-margin {_live_leverage}x kaldıraç ayarlandı.")

            # ── Kaldıraç Tutarlılık Doğrulaması (startup) ─────────────────────
            _env_lev_raw = os.environ.get("LEVERAGE", "10")
            _env_lev     = int(_env_lev_raw) if _env_lev_raw.isdigit() else 10
            _cfg_lev     = getattr(config, "LEVERAGE", 10)
            _okx_lev     = getattr(client, "_target_leverage", None)
            _exe_lev     = _live_leverage
            _lev_match   = (_cfg_lev == _exe_lev) and (_okx_lev is None or _okx_lev == _cfg_lev)
            logger.info(
                f"\n{'═'*62}\n"
                f"  KALDIRAÇ DOĞRULAMA — Startup\n"
                f"{'─'*62}\n"
                f"  Ortam degiskeni (LEVERAGE env) : {_env_lev}x\n"
                f"  Config runtime (config.LEVERAGE): {_cfg_lev}x\n"
                f"  OKX client hedef (_target_lev)  : {_okx_lev}x\n"
                f"  Execution engine leverage        : {_exe_lev}x\n"
                f"{'─'*62}\n"
                f"  SONUC: {'TUTARLI — tum katmanlar ayni kaldiraci kullaniyor' if _lev_match else 'UYUMSUZLUK — lutfen config.py ve OKX paneli kontrol edin!'}\n"
                f"{'═'*62}"
            )
            if not _lev_match:
                logger.warning(
                    f"[KALDIRAÇ UYARISI] Degerler tutarsiz: "
                    f"env={_env_lev}x | cfg={_cfg_lev}x | okx={_okx_lev}x | exe={_exe_lev}x. "
                    f"config.py LEVERAGE degerini veya ortam degiskenini guncelleyin."
                )

            # ── LIVE TEST MODU Uyarisi ─────────────────────────────────────────
            _live_test = getattr(config, "LIVE_TEST_MODE", False)
            if _live_test:
                _test_slot  = getattr(config, "SLOT_CONFIG", [{}])
                _test_notional = _test_slot[0].get("notional", 75) if _test_slot else 75
                _test_slots    = len(_test_slot)
                logger.info(
                    f"\n{'═'*62}\n"
                    f"  LIVE TEST MODU AKTiF\n"
                    f"{'─'*62}\n"
                    f"  Max acik pozisyon : {getattr(config, 'MAX_OPEN_POSITIONS', 1)}\n"
                    f"  Aktif slot sayisi : {_test_slots} (Slot 1 only)\n"
                    f"  Slot 1 notional  : {_test_notional} USDT (10x = ${_test_notional/10:.1f} margin)\n"
                    f"  Bu modu kapamak icin: config.py -> LIVE_TEST_MODE = False\n"
                    f"{'═'*62}"
                )

            # ── FORCE MAX SLOT TEST MODE Uyarisi ──────────────────────────────
            if getattr(config, "FORCE_MAX_SLOT_TEST_MODE", False):
                _fms_slots = getattr(config, "SLOT_CONFIG", [])
                _fms_max_n = max((s["notional"] for s in _fms_slots), default=0)
                logger.info(
                    f"\n{'═'*62}\n"
                    f"  FORCE MAX SLOT TEST MODE AKTiF\n"
                    f"{'─'*62}\n"
                    f"  Slot filtreleri  : AKTIF (kalite/rejim/reserve kontrol edilir)\n"
                    f"  Notional override: Atanan slot yerine max=${_fms_max_n} USDT kullanilir\n"
                    f"  Kapatmak icin    : config.py -> FORCE_MAX_SLOT_TEST_MODE = False\n"
                    f"{'═'*62}"
                )

            # ── Funding / Trading hesap senkron kontrolü ──────────────────────
            try:
                global _funding_usdt
                sync_info = client.check_balance_sync()
                _funding_usdt = sync_info.get("funding_usdt", 0.0)
                if sync_info["status"] == "funding_only":
                    logger.warning(
                        "[HESAP SYNC] ⚠️  Para Funding hesabında! "
                        f"Funding: ${sync_info['funding_usdt']:,.2f} USDT — "
                        "OKX uygulamasında Varlıklar → Transfer → Funding'den Trading'e aktarın."
                    )
            except Exception as _sync_err:
                logger.debug(f"[HESAP SYNC] Kontrol hatası: {_sync_err}")

            # Gerçek hesap bakiyesini kullan
            real_balance = client.get_usdt_balance()
            if real_balance > 0:
                trader.balance = real_balance
                trader.initial_balance = real_balance
                logger.info(f"Gerçek bakiye yüklendi: ${real_balance:,.2f} USDT")
                # PositionSizer min_trade'i gerçek bakiyeye göre güncelle
                if real_balance < 2.0:
                    pos_sizer.min_trade_value = 0.05
                elif real_balance < 10.0:
                    pos_sizer.min_trade_value = 0.50
                else:
                    pos_sizer.min_trade_value = 1.0
                logger.info(
                    f"[CANLI] PositionSizer min_trade güncellendi: "
                    f"${pos_sizer.min_trade_value:.2f} (bakiye: ${real_balance:.2f})"
                )
        else:
            logger.warning(
                "PAPER_TRADING=false ama OKX bağlantısı kurulamadı. "
                "Güvenlik için paper trading moduna geçildi."
            )
            config.PAPER_TRADING = True

    db = None if args.no_db else create_db_writer()
    if db:
        logger.info("Web paneli entegrasyonu aktif — veriler anlık senkronize edilecek.")
        # Arka plan P&L thread'i — her 5 saniyede bir açık pozisyonlar güncellenir
        _pnl_stop_event.clear()
        pnl_thread = threading.Thread(
            target   = _realtime_pnl_loop,
            args     = (trader, client, db, 5),
            daemon   = True,
            name     = "RealtimePnLUpdater",
        )
        pnl_thread.start()
        logger.info("[PNL-THREAD] Gerçek zamanlı P&L güncelleyici başlatıldı (her 5s)")
    else:
        logger.info("DB entegrasyonu devre dışı — yalnızca terminal çıktısı.")

    # ── Backtest ───────────────────────────────────────────────────────────────
    if args.backtest:
        from backtest.backtester import Backtester
        logger.info("Backtest başlatılıyor...")
        bt = Backtester(
            strategy          = strategy,
            symbols           = trading_pairs,
            timeframe         = config.KLINE_INTERVAL,
            initial_balance   = config.BACKTEST_INITIAL_BALANCE,
            fee_rate          = config.BACKTEST_FEE_RATE,
            slippage          = config.BACKTEST_SLIPPAGE,
            atr_sl_multiplier = config.ATR_SL_MULTIPLIER,
            atr_tp_multiplier = config.ATR_TP_MULTIPLIER,
            max_holding_candles = config.MAX_HOLDING_CANDLES,
        )
        bt.run(client)
        bt.print_results()
        return

    # ── Walk-Forward Test ──────────────────────────────────────────────────────
    if args.walkforward:
        from backtest.walk_forward import WalkForwardTester
        from backtest.backtester import Backtester
        from backtest.strategy_scorer import StrategyScorer, TradeResult
        logger.info("Walk-Forward Test başlatılıyor...")
        wf = WalkForwardTester(
            n_splits    = getattr(config, "WALK_FORWARD_SPLITS", 5),
            scorer      = StrategyScorer(
                min_trades = getattr(config, "BACKTEST_MIN_TRADES", 20)
            ),
        )
        mde.refresh()
        for sym in trading_pairs:
            df = mde.get_ohlcv(sym)
            if df is None or len(df) < 200:
                logger.warning(f"{sym}: Walk-forward için yetersiz veri")
                continue

            def _run_bt(df_slice):
                """Backtest callback: df_slice → List[TradeResult]"""
                bt = Backtester(
                    strategy     = strategy,
                    symbols      = [sym],
                    timeframe    = config.KLINE_INTERVAL,
                    initial_balance = config.BACKTEST_INITIAL_BALANCE,
                    fee_rate     = config.BACKTEST_FEE_RATE,
                    slippage     = config.BACKTEST_SLIPPAGE,
                    atr_sl_multiplier = config.ATR_SL_MULTIPLIER,
                    atr_tp_multiplier = config.ATR_TP_MULTIPLIER,
                    max_holding_candles = config.MAX_HOLDING_CANDLES,
                )
                bt_trades = bt.run_on_df(df_slice, sym)
                return [
                    TradeResult(
                        pnl=t.get("pnl", 0),
                        pnl_pct=t.get("pnl_pct", 0),
                        bars_held=t.get("bars_held", 0),
                        exit_reason=t.get("exit_reason", ""),
                    )
                    for t in (bt_trades or [])
                ]

            result = wf.run(
                df=df, strategy_name=strategy.name, symbol=sym,
                run_backtest=_run_bt,
                initial_balance=config.BACKTEST_INITIAL_BALANCE,
            )
            print(f"\n{result.summary()}")
        return

    # ── Rapor Modu ─────────────────────────────────────────────────────────────
    if args.report:
        mde.refresh()
        prices = mde.get_all_prices()
        print_report(trader, prices)
        return

    # ── Ana Döngü ──────────────────────────────────────────────────────────────
    if args.strategy == "multi_bot":
        run_multi_bot_loop(
            client    = client,
            mde       = mde,
            trader    = trader,
            risk_mgr  = risk_mgr,
            pos_sizer = pos_sizer,
            exe       = exe,
            db        = db,
            once      = args.once,
        )
    else:
        run_loop(
            client    = client,
            mde       = mde,
            trader    = trader,
            strategy  = strategy,
            risk_mgr  = risk_mgr,
            pos_sizer = pos_sizer,
            exe       = exe,
            db        = db,
            slot_mgr  = slot_mgr,
            once      = args.once,
        )


if __name__ == "__main__":
    main()
